import { apiClient } from "./client";

export type NegotiationListRow = {
  id: number;
  appraisal_request_id: number;
  system_offer: string | number;
  customer_expected_price: string | number | null;
  current_dealer_offer: string | number;
  max_authorized_offer: string | number;
  increment_amount: string | number;
  auto_negotiation_enabled: boolean;
  status: string;
  result: string | null;
  customer_name: string;
  brand: string;
  model: string;
  calculated_offer?: string | number | null;
};

export type NegotiationHistoryRow = {
  id: number;
  sender_type: string;
  message_type: string;
  offered_price: string | number | null;
  note: string | null;
  created_at: string;
};

export type NegotiationDetail = NegotiationListRow & {
  year?: number;
  requires_manager_approval?: boolean;
  history: NegotiationHistoryRow[];
};

export type NegotiationActionResult = {
  id?: number;
  negotiationId?: number;
  customerExpectedPrice?: number;
  currentDealerOffer?: number;
  status: string;
  requiresManagerReview?: boolean;
  resultMessage?: string;
};

export async function listNegotiations() {
  const response = await apiClient.get<{
    success: boolean;
    data: NegotiationListRow[];
  }>("/negotiations");

  return response.data.data;
}

export async function getNegotiation(id: number) {
  const response = await apiClient.get<{
    success: boolean;
    data: NegotiationDetail;
  }>(`/negotiations/${id}`);

  return response.data.data;
}

export async function createNegotiation(appraisalRequestId: number) {
  const response = await apiClient.post<{
    success: boolean;
    data: { negotiationId: number };
  }>("/negotiations", { appraisalRequestId });

  return response.data.data;
}

export async function submitCustomerExpectation(id: number, expectedPrice: number) {
  const response = await apiClient.post<{
    success: boolean;
    data: NegotiationActionResult;
  }>(`/negotiations/${id}/customer-expectation`, { expectedPrice });

  return response.data.data;
}

export async function acceptNegotiation(id: number) {
  const response = await apiClient.post<{ success: boolean; data: NegotiationActionResult }>(`/negotiations/${id}/accept`);
  return response.data.data;
}

export async function rejectNegotiation(id: number, note?: string) {
  const response = await apiClient.post<{ success: boolean; data: NegotiationActionResult }>(`/negotiations/${id}/reject`, { note });
  return response.data.data;
}

export async function approveNegotiationByManager(id: number, note?: string) {
  const response = await apiClient.post<{ success: boolean; data: NegotiationActionResult }>(
    `/negotiations/${id}/manager-approve`,
    { note }
  );
  return response.data.data;
}

export async function requestMeeting(id: number) {
  const response = await apiClient.post<{ success: boolean; data: NegotiationActionResult }>(`/negotiations/${id}/request-meeting`);
  return response.data.data;
}

export async function updateNegotiationSettings(
  id: number,
  payload: {
    maxAuthorizedOffer?: number;
    incrementAmount?: number;
    autoNegotiationEnabled?: boolean;
  }
) {
  const response = await apiClient.patch<{ success: boolean; data: NegotiationListRow }>(`/negotiations/${id}/settings`, payload);
  return response.data.data;
}
