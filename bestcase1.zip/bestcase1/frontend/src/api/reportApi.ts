import { apiClient } from "./client";

export type ReportFilters = {
  brand?: string;
  serviceType?: string;
  dateFrom?: string;
  dateTo?: string;
};

export type SummaryReport = {
  totalSalesCount: number;
  totalSalesRevenue: number;
  totalAcquisitionExpense: number;
  totalRevenue: number;
  totalServiceRevenue: number;
  averageProfit: number;
  serviceOccupancyRate: number;
  mostActiveTechnicianName: string;
  mostActiveTechnicianJobs: number;
  activeNegotiations: number;
  pendingApprovals: number;
};

export type SalesReportRow = {
  id: string;
  brand: string;
  model: string;
  year: number;
  list_price: string | number | null;
  purchase_price?: string | number | null;
  report_price: string | number;
  status: string;
  transaction_type: string;
};

export type ServiceReportRow = {
  id: string;
  customer_name: string;
  brand: string;
  model: string;
  service_type: string;
  status: string;
};

export async function getSummaryReport(filters: ReportFilters = {}) {
  const response = await apiClient.get<{ success: boolean; data: SummaryReport }>("/reports/summary", {
    params: {
      brand: filters.brand || undefined,
      serviceType: filters.serviceType || undefined,
      dateFrom: filters.dateFrom || undefined,
      dateTo: filters.dateTo || undefined
    }
  });
  return response.data.data;
}

export async function getSalesReport(filters: ReportFilters = {}) {
  const response = await apiClient.get<{ success: boolean; data: SalesReportRow[] }>("/reports/sales", {
    params: {
      brand: filters.brand || undefined,
      dateFrom: filters.dateFrom || undefined,
      dateTo: filters.dateTo || undefined
    }
  });
  return response.data.data;
}

export async function getServiceReport(filters: ReportFilters = {}) {
  const response = await apiClient.get<{ success: boolean; data: ServiceReportRow[] }>("/reports/service", {
    params: {
      brand: filters.brand || undefined,
      serviceType: filters.serviceType || undefined,
      dateFrom: filters.dateFrom || undefined,
      dateTo: filters.dateTo || undefined
    }
  });
  return response.data.data;
}

export async function downloadSummaryCsv(filters: ReportFilters = {}) {
  const response = await apiClient.get("/reports/export/csv", {
    params: {
      brand: filters.brand || undefined,
      serviceType: filters.serviceType || undefined,
      dateFrom: filters.dateFrom || undefined,
      dateTo: filters.dateTo || undefined
    },
    responseType: "blob"
  });

  return response.data as Blob;
}

export async function downloadSummaryExcel(filters: ReportFilters = {}) {
  const response = await apiClient.get("/reports/export/excel", {
    params: {
      brand: filters.brand || undefined,
      serviceType: filters.serviceType || undefined,
      dateFrom: filters.dateFrom || undefined,
      dateTo: filters.dateTo || undefined
    },
    responseType: "blob"
  });

  return response.data as Blob;
}
