import { apiClient } from "./client";

export async function getDashboardMetrics(path: string) {
  const response = await apiClient.get<{ success: boolean; data: Record<string, number> }>(`/dashboard/${path}`);
  return response.data.data;
}
