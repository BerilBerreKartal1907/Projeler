import axios from "axios";

export const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL ?? "http://localhost:4000/api/v1"
});

apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem("smart_appraisal_token");

  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  return config;
});

apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    // Backend 401 dönerse lokal token temizlenir; pasifleştirilen kullanıcı eski oturumla devam edemez.
    if (error.response?.status === 401) {
      localStorage.removeItem("smart_appraisal_token");
    }

    return Promise.reject(error);
  }
);
