import { apiClient } from "./client";

export type AdminUserRow = {
  id: number;
  full_name: string;
  email: string;
  phone: string | null;
  is_active: boolean;
  role_id: number;
  role: string;
};

export type RoleRow = {
  id: number;
  name: string;
};

export type RolePermissionRow = {
  role: string;
  permissions: string[];
  can_view: boolean;
  can_create: boolean;
  can_update: boolean;
  can_delete: boolean;
  can_approve: boolean;
};

export type SystemParameterRow = {
  id: number;
  key: string;
  value: string;
  description: string | null;
};

export type AuditLogRow = {
  id: number;
  user_name?: string | null;
  action: string;
  entity_type: string;
  entity_id: string;
  ip_address: string | null;
  created_at: string;
};

export async function listUsersAdmin() {
  const response = await apiClient.get<{ success: boolean; data: AdminUserRow[] }>("/users");
  return response.data.data;
}

export async function createUserAdmin(payload: {
  fullName: string;
  email: string;
  password: string;
  phone?: string;
  roleId: number;
  isActive?: boolean;
}) {
  const response = await apiClient.post<{ success: boolean; data: AdminUserRow }>("/users", payload);
  return response.data.data;
}

export async function updateUserAdmin(id: number, payload: {
  fullName?: string;
  phone?: string | null;
  roleId?: number;
  isActive?: boolean;
}) {
  const response = await apiClient.put<{ success: boolean; data: AdminUserRow }>(`/users/${id}`, payload);
  return response.data.data;
}

export async function listRolesAdmin() {
  const response = await apiClient.get<{ success: boolean; data: RoleRow[] }>("/roles");
  return response.data.data;
}

export async function listRolePermissions() {
  const response = await apiClient.get<{ success: boolean; data: RolePermissionRow[] }>("/roles/permissions");
  return response.data.data;
}

export async function listSystemParameters() {
  const response = await apiClient.get<{ success: boolean; data: SystemParameterRow[] }>("/system-parameters");
  return response.data.data;
}

export async function updateSystemParameter(key: string, payload: { value: string; description?: string }) {
  const response = await apiClient.put<{ success: boolean; data: SystemParameterRow }>(`/system-parameters/${key}`, payload);
  return response.data.data;
}

export async function listAuditLogs() {
  const response = await apiClient.get<{ success: boolean; data: AuditLogRow[] }>("/audit-logs");
  return response.data.data;
}
