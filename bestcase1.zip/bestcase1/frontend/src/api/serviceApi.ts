import { apiClient } from "./client";

export type VehicleOption = {
  id: number;
  brand: string;
  model: string;
  plate: string | null;
  vin: string;
  list_price?: string | number | null;
};

export type CapacityResult = {
  serviceType: string;
  date: string;
  capacity: number;
  used: number;
  remaining: number;
  available: boolean;
};

export type AvailabilitySlot = {
  time: string;
  available: boolean;
  source: "free" | "busy" | "booked";
};

export type ServiceAppointmentRow = {
  id: number;
  service_type: string;
  appointment_datetime: string;
  estimated_price: string | number | null;
  status: string;
  complaint_description: string | null;
  customer_name: string;
  brand: string;
  model: string;
  plate: string | null;
  technician_name?: string | null;
  technician_id?: string | number | null;
};

export type ServiceTechnicianRow = {
  id: number;
  full_name: string;
  email: string;
  phone: string | null;
};

export type ServiceOperationRow = {
  id: number;
  operation_name: string;
  operation_type: string;
  part_price: string | number;
  labor_price: string | number;
  total_price: string | number;
  is_critical_safety: boolean;
  customer_approval_status: string;
  manager_review_status: string;
  note: string | null;
};

export type CriticalCaseRow = {
  id: number;
  operation_name: string;
  total_price: string | number;
  customer_approval_status: string;
  manager_review_status: string;
  appointment_id: number;
  customer_name: string;
  brand: string;
  model: string;
};

export type TechnicianPerformanceRow = {
  id: string;
  full_name: string;
  assigned_jobs: number;
  completed_jobs: number;
  total_revenue: number;
};

export async function listVehicles() {
  const response = await apiClient.get<{ success: boolean; data: VehicleOption[] }>("/vehicles");
  return response.data.data;
}

export async function checkServiceCapacity(serviceType: string, date: string) {
  const response = await apiClient.get<{ success: boolean; data: CapacityResult }>("/service/capacity/check", {
    params: { serviceType, date }
  });
  return response.data.data;
}

export async function getAvailability(serviceType: string, date: string) {
  const response = await apiClient.get<{ success: boolean; data: { date: string; serviceType: string; slots: AvailabilitySlot[] } }>("/service/availability", {
    params: { serviceType, date }
  });
  return response.data.data;
}

export async function createServiceAppointment(payload: {
  vehicleId: number;
  serviceType: string;
  appointmentDatetime: string;
  complaintDescription?: string;
}) {
  const response = await apiClient.post<{ success: boolean; data: { appointmentId: number } }>("/service/appointments", payload);
  return response.data.data;
}

export async function listAppointments() {
  const response = await apiClient.get<{ success: boolean; data: ServiceAppointmentRow[] }>("/service/appointments");
  return response.data.data;
}

export async function listServiceTechnicians() {
  const response = await apiClient.get<{ success: boolean; data: ServiceTechnicianRow[] }>("/service/technicians");
  return response.data.data;
}

export async function assignTechnician(appointmentId: number, technicianId: number) {
  const response = await apiClient.patch<{ success: boolean; data: { id: string; status: string; assigned_technician_id: string } }>(
    `/service/appointments/${appointmentId}/assign-technician`,
    { technicianId }
  );
  return response.data.data;
}

export async function rescheduleAppointment(appointmentId: number, appointmentDatetime: string) {
  const response = await apiClient.patch<{ success: boolean; data: { id: string; appointment_datetime: string; status: string } }>(
    `/service/appointments/${appointmentId}/reschedule`,
    { appointmentDatetime }
  );
  return response.data.data;
}

export async function cancelAppointment(appointmentId: number) {
  const response = await apiClient.post<{ success: boolean; data: { id: number; status: string } }>(
    `/service/appointments/${appointmentId}/cancel`
  );
  return response.data.data;
}

export async function listOperations(appointmentId: number) {
  const response = await apiClient.get<{ success: boolean; data: ServiceOperationRow[] }>(
    `/service/appointments/${appointmentId}/operations`
  );
  return response.data.data;
}

export async function createOperation(appointmentId: number, payload: {
  operationName: string;
  operationType: string;
  partPrice?: number;
  laborPrice?: number;
  isCriticalSafety?: boolean;
  note?: string;
}) {
  const response = await apiClient.post<{ success: boolean; data: { id: number; operation_name: string; total_price: number; is_critical_safety: boolean } }>(
    `/service/appointments/${appointmentId}/operations`,
    payload
  );
  return response.data.data;
}

export async function approveOperation(operationId: number) {
  const response = await apiClient.post<{ success: boolean; data: { id: number; customer_approval_status: string; is_critical_safety: boolean } }>(
    `/service/operations/${operationId}/customer-approve`
  );
  return response.data.data;
}

export async function rejectOperation(operationId: number) {
  const response = await apiClient.post<{ success: boolean; data: { id: number; customer_approval_status: string; manager_review_status: string; is_critical_safety: boolean; warning: string | null } }>(
    `/service/operations/${operationId}/customer-reject`
  );
  return response.data.data;
}

export async function listCriticalCases() {
  const response = await apiClient.get<{ success: boolean; data: CriticalCaseRow[] }>("/service/critical-cases");
  return response.data.data;
}

export async function getTechnicianPerformance() {
  const response = await apiClient.get<{ success: boolean; data: TechnicianPerformanceRow[] }>("/service/technician-performance");
  return response.data.data;
}

export async function reviewCriticalOperation(operationId: number, decision: string, note: string) {
  const response = await apiClient.post<{ success: boolean; data: { id: string; manager_review_status: string } }>(`/service/operations/${operationId}/review`, {
    decision,
    note
  });
  return response.data.data;
}

export async function completeApprovedOperations(appointmentId: number) {
  const response = await apiClient.post<{ success: boolean; data: { appointmentId: number; status: string } }>(
    `/service/appointments/${appointmentId}/complete-approved-operations`
  );
  return response.data.data;
}
