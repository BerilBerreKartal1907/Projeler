import { apiClient } from "./client";

export type CreditCalculationRow = {
  id?: number;
  financed_amount: string | number;
  monthly_payment: string | number;
  total_payment?: string | number;
  total_interest: string | number;
};

export async function createCreditCalculation(payload: {
  vehicleId?: number;
  vehiclePrice: number;
  downPayment: number;
  maturityMonths: number;
  monthlyInterestRate: number;
}) {
  const response = await apiClient.post<{ success: boolean; data: CreditCalculationRow }>("/credit-calculations", payload);
  return response.data.data;
}

export async function listCreditCalculations() {
  const response = await apiClient.get<{ success: boolean; data: CreditCalculationRow[] }>("/credit-calculations");
  return response.data.data;
}
