import { apiClient } from "./client";

export type AppraisalListRow = {
  id: number;
  status: string;
  damage_score: number;
  damage_percentage: string;
  calculated_offer: string | null;
  requires_manager_approval: boolean;
  approval_reason?: string | null;
  customer_name: string;
  brand: string;
  model: string;
  year: number;
  mileage: number;
};

export type AppraisalDamageDetailRow = {
  id: number;
  vehicle_part: string;
  damage_type: string;
  damage_point: number;
  note: string | null;
  created_at: string;
};

export type AppraisalDetail = {
  id: number;
  customer_id: number;
  vehicle_id: number;
  status: string;
  damage_score: number;
  damage_percentage: string;
  tramer_value: string | null;
  calculated_offer: string | null;
  requires_manager_approval: boolean;
  approval_reason: string | null;
  manager_id: number | null;
  manager_decision: string | null;
  manager_note: string | null;
  expected_selling_price: string | null;
  declared_tramer_amount: string | null;
  customer_name: string;
  customer_email: string;
  plate: string | null;
  vin: string;
  brand: string;
  model: string;
  year: number;
  mileage: number;
  category: string;
  market_value: string | null;
  accident_record: boolean;
  owner_count: number | null;
  heavy_damage: boolean;
  customs_problem: boolean;
  damage_history_text: string | null;
  damageDetails: AppraisalDamageDetailRow[];
};

export async function listAppraisals() {
  const response = await apiClient.get<{
    success: boolean;
    data: AppraisalListRow[];
  }>("/appraisals");

  return response.data.data;
}

export async function getAppraisalDetail(id: number) {
  const response = await apiClient.get<{
    success: boolean;
    data: AppraisalDetail;
  }>(`/appraisals/${id}`);

  return response.data.data;
}

export async function approveAppraisal(id: number, note: string) {
  const response = await apiClient.post(`/appraisals/${id}/approve`, { note });
  return response.data;
}

export async function rejectAppraisal(id: number, note: string) {
  const response = await apiClient.post(`/appraisals/${id}/reject`, { note });
  return response.data;
}

export async function reviseAppraisalPrice(id: number, revisedPrice: number, note: string) {
  const response = await apiClient.post(`/appraisals/${id}/revise-price`, { revisedPrice, note });
  return response.data;
}
