import { apiClient } from "./client";

export type CustomerProfile = {
  id: number;
  user_id: number;
  full_name: string;
  email: string;
  phone: string | null;
  address: string | null;
  city: string | null;
};

export async function getMyCustomerProfile() {
  const response = await apiClient.get<{ success: boolean; data: CustomerProfile }>("/customers/me/profile");
  return response.data.data;
}

export async function updateMyCustomerProfile(payload: {
  fullName?: string;
  phone?: string;
  address?: string;
  city?: string;
}) {
  const response = await apiClient.put<{ success: boolean; data: CustomerProfile }>("/customers/me/profile", payload);
  return response.data.data;
}
