import { apiClient } from "./client";

export type NotificationRow = {
  id: number;
  title: string;
  message: string;
  type: string;
  is_read: boolean;
  created_at: string;
};

export async function listNotifications() {
  const response = await apiClient.get<{ success: boolean; data: NotificationRow[] }>("/notifications");
  return response.data.data;
}
