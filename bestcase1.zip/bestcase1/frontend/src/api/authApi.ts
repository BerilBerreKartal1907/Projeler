import { apiClient } from "./client";
import type { AppRole } from "../routes/roleMenus";

export type AuthUser = {
  id: number;
  fullName: string;
  email: string;
  phone?: string | null;
  isActive?: boolean;
  role: AppRole;
};

export async function loginRequest(email: string, password: string) {
  const response = await apiClient.post<{
    success: boolean;
    data: {
      token: string;
      user: AuthUser;
    };
  }>("/auth/login", { email, password });

  return response.data.data;
}

export async function registerRequest(payload: {
  fullName: string;
  email: string;
  password: string;
  phone: string;
  district: string;
  city: string;
}) {
  const response = await apiClient.post<{
    success: boolean;
    data: {
      id: number;
      email: string;
      fullName: string;
    };
    message: string;
  }>("/auth/register", payload);

  return response.data;
}

export async function meRequest() {
  const response = await apiClient.get<{
    success: boolean;
    data: AuthUser;
  }>("/auth/me");

  return response.data.data;
}

export async function forgotPasswordRequest(phone: string) {
  const response = await apiClient.post<{
    success: boolean;
    data: {
      phone: string;
      maskedPhone: string;
      resetToken: string | null;
      expiresInMinutes: number;
    };
  }>("/auth/forgot-password", { phone });

  return response.data.data;
}

export async function resetPasswordRequest(payload: {
  token: string;
  smsCode: string;
  newPassword: string;
  confirmPassword: string;
}) {
  const response = await apiClient.post<{ success: boolean; data: null; message: string }>("/auth/reset-password", payload);
  return response.data;
}
