import { apiClient } from "./client";

export type AppraisalCreatePayload = {
  brand: string;
  model: string;
  package: string;
  year: number;
  mileage: number;
  plate?: string;
  category: string;
  expectedSellingPrice?: number;
  declaredTramerAmount?: number;
};

export type DamageEntry = {
  vehiclePart: string;
  damageType: "original" | "painted" | "local_painted" | "replaced" | "damaged";
  note?: string;
};

export async function getAppraisalCooldownStatus() {
  const response = await apiClient.get<{
    success: boolean;
    data: {
      canCreate: boolean;
      remainingMs: number;
      message: string;
    };
  }>("/appraisals/cooldown/status");

  return response.data.data;
}

export async function listCustomerAppraisals() {
  const response = await apiClient.get<{
    success: boolean;
    data: Array<{
      id: number;
      status: string;
      requires_manager_approval: boolean;
      brand: string;
      model: string;
      year: number;
      mileage: number;
    }>;
  }>("/appraisals");

  return response.data.data;
}

export async function createAppraisalRequest(payload: AppraisalCreatePayload) {
  const response = await apiClient.post<{
    success: boolean;
    data: {
      appraisalId: number;
      vehicleId: number;
    };
  }>("/appraisals", payload);

  return response.data.data;
}

export async function saveDamageDetails(appraisalId: number, damages: DamageEntry[]) {
  const response = await apiClient.post<{
    success: boolean;
    data: {
      appraisalId: number;
      damageScore: number;
      damagePercentage: number;
      tramerValue: number;
      calculatedOffer: number;
      requiresManagerApproval: boolean;
      approvalReasons: string[];
      suggestedAction: string;
      appliedDiscounts: string[];
    };
  }>(`/appraisals/${appraisalId}/damage-details`, { damages });

  return response.data.data;
}

export async function getPreliminaryOffer(appraisalId: number) {
  const response = await apiClient.get<{
    success: boolean;
    data: {
      id: number;
      status: string;
      damage_score: number;
      damage_percentage: string;
      tramer_value: string;
      calculated_offer: string;
      requires_manager_approval: boolean;
      approval_reason: string | null;
      expected_selling_price: string | null;
      applied_discounts: string[];
      pricing_explanation: string;
      declared_tramer_amount?: string | null;
      accident_record: boolean;
      owner_count: number;
      heavy_damage: boolean;
      customs_problem: boolean;
      damage_history_text: string | null;
      suggested_min_price: number;
      suggested_max_price: number;
    };
  }>(`/appraisals/${appraisalId}/preliminary-offer`);

  return response.data.data;
}

export async function updateExpectedPrice(appraisalId: number, expectedSellingPrice: number) {
  const response = await apiClient.patch<{
    success: boolean;
    data: {
      id: number;
      status: string;
      damage_score: number;
      damage_percentage: string;
      tramer_value: string;
      calculated_offer: string;
      requires_manager_approval: boolean;
      approval_reason: string | null;
      expected_selling_price: string | null;
      declared_tramer_amount?: string | null;
      accident_record: boolean;
      owner_count: number;
      heavy_damage: boolean;
      customs_problem: boolean;
      damage_history_text: string | null;
      applied_discounts: string[];
      pricing_explanation: string;
      suggested_min_price: number;
      suggested_max_price: number;
    };
  }>(`/appraisals/${appraisalId}/expected-price`, { expectedSellingPrice });

  return response.data.data;
}
