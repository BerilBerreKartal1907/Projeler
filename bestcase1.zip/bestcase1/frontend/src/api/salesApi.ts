import { apiClient } from "./client";

export type SalesListingRow = {
  id: number;
  vehicle_id: number;
  customer_id: number | null;
  price: string | number;
  damage_score: number | null;
  status: string;
  brand: string;
  model: string;
  year: number;
  package: string | null;
  color: string | null;
};

export type SalesListingCandidateRow = {
  id: number;
  brand: string;
  model: string;
  year: number;
  plate: string | null;
  vin: string;
  list_price?: string | number | null;
  calculated_offer: string | number | null;
  damage_score: number;
  appraisal_status: string;
  customer_name: string;
};

export async function listSalesListings() {
  const response = await apiClient.get<{ success: boolean; data: SalesListingRow[] }>("/sales-listings");
  return response.data.data;
}

export async function listSalesListingCandidates() {
  const response = await apiClient.get<{ success: boolean; data: SalesListingCandidateRow[] }>("/sales-listings/candidates");
  return response.data.data;
}

export async function createSalesListing(payload: {
  vehicleId: number;
  price: number;
  damageScore?: number;
  status?: string;
}) {
  const response = await apiClient.post<{ success: boolean; data: SalesListingRow }>("/sales-listings", payload);
  return response.data.data;
}

export async function markSalesListingSold(id: number) {
  const response = await apiClient.post<{ success: boolean; data: SalesListingRow }>(`/sales-listings/${id}/mark-sold`);
  return response.data.data;
}

export async function cancelSalesListing(id: number) {
  const response = await apiClient.post<{ success: boolean; data: SalesListingRow }>(`/sales-listings/${id}/cancel`);
  return response.data.data;
}
