import { useEffect, useState } from "react";

import { getDashboardMetrics } from "../../api/dashboardApi";
import { StatCard } from "../../components/common/StatCard";
import { getErrorMessage } from "../../utils/http";

export function AdminDashboard() {
  const [metrics, setMetrics] = useState({
    totalUsers: 0,
    activeCustomers: 0,
    activeStaff: 0,
    systemLogs: 0,
    pendingUserActions: 0
  });
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getDashboardMetrics("admin")
      .then((dashboardResponse) => {
        setMetrics(dashboardResponse as typeof metrics);
      })
      .catch((requestError) => setError(getErrorMessage(requestError, "Admin paneli verileri alınamadı.")));
  }, []);

  return (
    <section className="dashboard-page">
      <div className="hero-panel">
        <div>
          <p className="eyebrow">Genel Durum</p>
          <h1>Akıllı bayi operasyonları için tek merkez</h1>
          <p>
            Ekspertiz süreçleri, servis kapasitesi, finansman hesaplamaları ve yönetim onayları canlı verilerle burada
            izlenecek.
          </p>
        </div>
        <div className="hero-badge">Canlı KPI Altyapısı Aktif</div>
      </div>
      {error ? <p className="form-error">{error}</p> : null}

      <div className="stats-grid">
        <StatCard label="Toplam Kullanıcı" value={String(metrics.totalUsers)} />
        <StatCard label="Aktif Müşteri" value={String(metrics.activeCustomers)} tone="warning" />
        <StatCard label="Aktif Personel" value={String(metrics.activeStaff)} tone="success" />
        <StatCard label="Sistem Logları" value={String(metrics.systemLogs)} tone="danger" />
        <StatCard label="Bekleyen Kullanıcı Aksiyonu" value={String(metrics.pendingUserActions)} />
      </div>
    </section>
  );
}
