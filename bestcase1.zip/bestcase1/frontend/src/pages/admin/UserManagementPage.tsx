import { useEffect, useState } from "react";

import {
  createUserAdmin,
  listRolesAdmin,
  listUsersAdmin,
  updateUserAdmin,
  type AdminUserRow,
  type RoleRow
} from "../../api/adminApi";
import { getErrorMessage } from "../../utils/http";
import { roleLabels } from "../../routes/roleMenus";
import { PHONE_COUNTRIES, buildPhoneNumber, splitPhoneNumber } from "../../utils/phone";

export function UserManagementPage() {
  const [rows, setRows] = useState<AdminUserRow[]>([]);
  const [roles, setRoles] = useState<RoleRow[]>([]);
  const [editingUserId, setEditingUserId] = useState<number | null>(null);
  const [form, setForm] = useState<{
    fullName: string;
    email: string;
    password: string;
    countryCode: string;
    localNumber: string;
    roleId: string;
    isActive: boolean;
  }>({
    fullName: "",
    email: "",
    password: "",
    countryCode: PHONE_COUNTRIES[0].code,
    localNumber: "",
    roleId: "",
    isActive: true
  });
  const [editForm, setEditForm] = useState<{
    fullName: string;
    countryCode: string;
    localNumber: string;
    roleId: string;
    isActive: boolean;
  }>({
    fullName: "",
    countryCode: PHONE_COUNTRIES[0].code,
    localNumber: "",
    roleId: "",
    isActive: true
  });
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    const [userRows, roleRows] = await Promise.all([listUsersAdmin(), listRolesAdmin()]);
    setRows(userRows);
    setRoles(roleRows);
  }

  useEffect(() => {
    refresh().catch((requestError) => setError(getErrorMessage(requestError, "Kullanıcı verileri alınamadı.")));
    const intervalId = window.setInterval(() => {
      refresh().catch(() => undefined);
    }, 15000);

    return () => window.clearInterval(intervalId);
  }, []);

  const assignableRoles = roles.filter((role) => role.name !== "customer");

  async function handleCreate(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setMessage(null);

    try {
      await createUserAdmin({
        fullName: form.fullName,
        email: form.email,
        password: form.password,
        phone: buildPhoneNumber(form.countryCode, form.localNumber),
        roleId: Number(form.roleId),
        isActive: form.isActive
      });
      setForm({
        fullName: "",
        email: "",
        password: "",
        countryCode: PHONE_COUNTRIES[0].code,
        localNumber: "",
        roleId: "",
        isActive: true
      });
      setMessage("Kullanıcı oluşturuldu.");
      await refresh();
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Kullanıcı oluşturulamadı."));
    }
  }

  async function toggleActive(row: AdminUserRow) {
    try {
      await updateUserAdmin(Number(row.id), { isActive: !row.is_active });
      setMessage("Kullanıcı durumu güncellendi.");
      setError(null);
      await refresh();
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Kullanıcı durumu değiştirilemedi."));
    }
  }

  function startEdit(row: AdminUserRow) {
    const phoneParts = splitPhoneNumber(row.phone);
    setEditingUserId(Number(row.id));
    setEditForm({
      fullName: row.full_name ?? "",
      countryCode: phoneParts.countryCode,
      localNumber: phoneParts.localNumber,
      roleId: String(row.role_id ?? ""),
      isActive: Boolean(row.is_active)
    });
  }

  async function handleSaveEdit() {
    if (!editingUserId) {
      return;
    }

    try {
      await updateUserAdmin(editingUserId, {
        fullName: editForm.fullName,
        phone: buildPhoneNumber(editForm.countryCode, editForm.localNumber) || null,
        roleId: Number(editForm.roleId),
        isActive: editForm.isActive
      });
      setMessage("Kullanıcı bilgileri güncellendi.");
      setError(null);
      setEditingUserId(null);
      await refresh();
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Kullanıcı güncellenemedi."));
    }
  }

  return (
    <section className="dashboard-page">
      <section className="panel form-panel">
        <div className="panel-heading">
          <div>
            <h3>Yeni Kullanıcı</h3>
            <p className="section-subtitle">Admin kullanıcı oluşturabilir ve rol atayabilir</p>
          </div>
        </div>
        <form className="appraisal-form-grid" onSubmit={handleCreate}>
          <label><span>Ad Soyad</span><input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} required /></label>
          <label><span>E-posta</span><input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required /></label>
          <label><span>Şifre</span><input value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required /></label>
          <label>
            <span>Telefon</span>
            <div className="phone-field">
              <select value={form.countryCode} onChange={(e) => setForm({ ...form, countryCode: e.target.value })}>
                {PHONE_COUNTRIES.map((country) => <option key={country.code} value={country.code}>{country.label}</option>)}
              </select>
              <input value={form.localNumber} onChange={(e) => setForm({ ...form, localNumber: e.target.value.replace(/[^\d]/g, "") })} />
            </div>
          </label>
          <label>
            <span>Rol</span>
            <select value={form.roleId} onChange={(e) => setForm({ ...form, roleId: e.target.value })} required>
              <option value="">Rol seçin</option>
              {assignableRoles.map((role) => <option key={role.id} value={role.id}>{roleLabels[role.name as keyof typeof roleLabels] ?? role.name}</option>)}
            </select>
          </label>
          <label className="checkbox-row checkbox-row--label-first">
            <span>Aktif</span>
            <input
              type="checkbox"
              checked={form.isActive}
              onChange={(e) => setForm({ ...form, isActive: e.target.checked })}
            />
          </label>
          <div className="form-actions"><button className="primary-button" type="submit">Kullanıcı Oluştur</button></div>
        </form>
        {error ? <p className="form-error">{error}</p> : null}
        {message ? <p className="form-success">{message}</p> : null}
      </section>

      <section className="panel">
        <div className="panel-heading">
          <div>
            <h3>Kullanıcı Yönetimi</h3>
            <p className="section-subtitle">Sistemdeki tüm kullanıcılar ve roller</p>
          </div>
        </div>
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Ad Soyad</th>
                <th>E-posta</th>
                <th>Telefon</th>
                <th>Rol</th>
                <th>Aktif</th>
                <th>Aksiyon</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  <td>
                    {editingUserId === Number(row.id) ? (
                      <input
                        value={editForm.fullName}
                        onChange={(event) => setEditForm((current) => ({ ...current, fullName: event.target.value }))}
                      />
                    ) : row.full_name}
                  </td>
                  <td>{row.email}</td>
                  <td>
                    {editingUserId === Number(row.id) ? (
                      <div className="phone-field phone-field--compact">
                        <select
                          value={editForm.countryCode}
                          onChange={(event) => setEditForm((current) => ({ ...current, countryCode: event.target.value }))}
                        >
                          {PHONE_COUNTRIES.map((country) => <option key={country.code} value={country.code}>{country.code}</option>)}
                        </select>
                        <input
                          value={editForm.localNumber}
                          onChange={(event) => setEditForm((current) => ({ ...current, localNumber: event.target.value.replace(/[^\d]/g, "") }))}
                        />
                      </div>
                    ) : (row.phone ?? "-")}
                  </td>
                  <td>
                    {editingUserId === Number(row.id) ? (
                      <select
                        value={editForm.roleId}
                        onChange={(event) => setEditForm((current) => ({ ...current, roleId: event.target.value }))}
                      >
                        <option value="">Rol seçin</option>
                        {roles.map((role) => <option key={role.id} value={role.id}>{roleLabels[role.name as keyof typeof roleLabels] ?? role.name}</option>)}
                      </select>
                    ) : (roleLabels[row.role as keyof typeof roleLabels] ?? row.role)}
                  </td>
                  <td>
                    {editingUserId === Number(row.id) ? (
                      <label className="checkbox-row">
                        <span>{editForm.isActive ? "Evet" : "Hayır"}</span>
                        <input
                          type="checkbox"
                          checked={editForm.isActive}
                          onChange={(event) => setEditForm((current) => ({ ...current, isActive: event.target.checked }))}
                        />
                      </label>
                    ) : (row.is_active ? "Evet" : "Hayır")}
                  </td>
                  <td>
                    <div className="action-grid action-grid--tight">
                      {editingUserId === Number(row.id) ? (
                        <>
                          <button className="primary-button" type="button" onClick={handleSaveEdit}>Kaydet</button>
                          <button className="ghost-button" type="button" onClick={() => setEditingUserId(null)}>İptal</button>
                        </>
                      ) : (
                        <>
                          <button className="ghost-button" type="button" onClick={() => startEdit(row)}>Düzenle</button>
                          <button className="ghost-button" type="button" onClick={() => toggleActive(row)}>
                            {row.is_active ? "Pasifleştir" : "Aktifleştir"}
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
