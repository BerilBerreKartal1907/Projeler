import { useEffect, useState } from "react";

import { listAuditLogs, type AuditLogRow } from "../../api/adminApi";
import { auditActionLabels, auditEntityLabels } from "../../utils/adminLabels";
import { getErrorMessage } from "../../utils/http";

export function AuditLogsPage() {
  const [rows, setRows] = useState<AuditLogRow[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    listAuditLogs()
      .then(setRows)
      .catch((requestError) => setError(getErrorMessage(requestError, "Denetim logları alınamadı.")));
  }, []);

  return (
    <section className="dashboard-page">
      <section className="panel">
        <div className="panel-heading">
          <div>
            <h3>Denetim Logları</h3>
            <p className="section-subtitle">Sistemde yapılan önemli işlemler ve değişiklik kayıtları</p>
          </div>
        </div>
        {error ? <p className="form-error">{error}</p> : null}
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Kullanıcı</th>
                <th>İşlem</th>
                <th>Kayıt Tipi</th>
                <th>Kayıt No</th>
                <th>Tarih</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  <td>{row.user_name ?? "-"}</td>
                  <td>{auditActionLabels[row.action] ?? row.action}</td>
                  <td>{auditEntityLabels[row.entity_type] ?? row.entity_type}</td>
                  <td>{row.entity_id}</td>
                  <td>{new Date(row.created_at).toLocaleString("tr-TR")}</td>
                </tr>
              ))}
              {!rows.length ? (
                <tr>
                  <td colSpan={5}>Henüz denetim kaydı bulunmuyor.</td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
