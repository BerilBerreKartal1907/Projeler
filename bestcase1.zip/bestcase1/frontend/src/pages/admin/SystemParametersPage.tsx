import { useEffect, useState } from "react";

import {
  listSystemParameters,
  updateSystemParameter,
  type SystemParameterRow
} from "../../api/adminApi";
import { getParameterLabel } from "../../utils/adminLabels";
import { getErrorMessage } from "../../utils/http";

export function SystemParametersPage() {
  const [rows, setRows] = useState<SystemParameterRow[]>([]);
  const [editingKey, setEditingKey] = useState<string | null>(null);
  const [editForm, setEditForm] = useState({
    value: "",
    description: ""
  });
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    const data = await listSystemParameters();
    setRows(data);
  }

  useEffect(() => {
    refresh().catch((requestError) => setError(getErrorMessage(requestError, "Parametreler alınamadı.")));
  }, []);

  function startEdit(row: SystemParameterRow) {
    const label = getParameterLabel(row.key);
    setEditingKey(row.key);
    setEditForm({
      value: row.value ?? "",
      description: row.description && !/maintenance|accident repair|modification|check-up/i.test(row.description)
        ? row.description
        : label.help
    });
  }

  async function handleSave(key: string) {
    try {
      await updateSystemParameter(key, editForm);
      setMessage("Sistem parametresi güncellendi.");
      setError(null);
      setEditingKey(null);
      await refresh();
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Parametre güncellenemedi."));
    }
  }

  return (
    <section className="dashboard-page">
      <section className="panel">
        <div className="panel-heading">
          <div>
            <h3>Sistem Parametreleri</h3>
            <p className="section-subtitle">
              Teklif hesaplama, servis kapasitesi ve onay eşiklerini etkileyen yönetilebilir değerler
            </p>
          </div>
        </div>
        <p className="info-note">
          Buradaki değerleri değiştirdiğinizde ilgili ekranlardaki hesaplama veya randevu kuralları yeni değere göre
          çalışır. Açıklama alanı kullanıcıya dönük not olarak tutulur.
        </p>
        {error ? <p className="form-error">{error}</p> : null}
        {message ? <p className="form-success">{message}</p> : null}
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Parametre</th>
                <th>Neyi Etkiler?</th>
                <th>Değer</th>
                <th>Açıklama</th>
                <th>Aksiyon</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => {
                const label = getParameterLabel(row.key);
                return (
                <tr key={row.id}>
                  <td>
                    <strong>{label.title}</strong>
                    <span className="muted-block">{row.key}</span>
                  </td>
                  <td className="reason-cell">{label.help}</td>
                  <td>
                    {editingKey === row.key ? (
                      <input
                        value={editForm.value}
                        onChange={(event) => setEditForm((current) => ({ ...current, value: event.target.value }))}
                      />
                    ) : `${row.value}${label.unit ? ` ${label.unit}` : ""}`}
                  </td>
                  <td>
                    {editingKey === row.key ? (
                      <input
                        value={editForm.description}
                        onChange={(event) => setEditForm((current) => ({ ...current, description: event.target.value }))}
                      />
                    ) : label.help}
                  </td>
                  <td>
                    <div className="action-grid action-grid--tight">
                      {editingKey === row.key ? (
                        <>
                          <button className="primary-button" type="button" onClick={() => handleSave(row.key)}>
                            Kaydet
                          </button>
                          <button className="ghost-button" type="button" onClick={() => setEditingKey(null)}>
                            İptal
                          </button>
                        </>
                      ) : (
                        <button className="ghost-button" type="button" onClick={() => startEdit(row)}>
                          Düzenle
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
