import { useEffect, useState } from "react";

import { listRolePermissions, type RolePermissionRow } from "../../api/adminApi";
import { getErrorMessage } from "../../utils/http";
import {
  getRoleLabel,
  permissionColumnLabels,
  permissionLabels,
  rolePurposeLabels
} from "../../utils/adminLabels";
import type { AppRole } from "../../routes/roleMenus";

export function RoleManagementPage() {
  const [rows, setRows] = useState<RolePermissionRow[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    listRolePermissions()
      .then(setRows)
      .catch((requestError) => setError(getErrorMessage(requestError, "Rol yetkileri alınamadı.")));
  }, []);

  return (
    <section className="dashboard-page">
      <section className="panel">
        <div className="panel-heading">
          <div>
            <h3>Rol Yönetimi</h3>
            <p className="section-subtitle">
              Bu ekran bilgilendirme amaçlıdır; rollerin hangi ekranlarda hangi işlemleri yapabildiğini gösterir.
            </p>
          </div>
        </div>
        <p className="info-note">
          Rol değişiklikleri kullanıcı yönetimindeki rol alanından yapılır. Bu tabloda yetki setleri okunur, doğrudan
          düzenlenmez.
        </p>
        {error ? <p className="form-error">{error}</p> : null}
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Rol</th>
                <th>Amaç</th>
                <th>{permissionColumnLabels.can_view}</th>
                <th>{permissionColumnLabels.can_create}</th>
                <th>{permissionColumnLabels.can_update}</th>
                <th>{permissionColumnLabels.can_delete}</th>
                <th>{permissionColumnLabels.can_approve}</th>
                <th>Yetki Özeti</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.role}>
                  <td><strong>{getRoleLabel(row.role)}</strong></td>
                  <td className="reason-cell">{rolePurposeLabels[row.role as AppRole] ?? "-"}</td>
                  <td>{row.can_view ? "Evet" : "Hayır"}</td>
                  <td>{row.can_create ? "Evet" : "Hayır"}</td>
                  <td>{row.can_update ? "Evet" : "Hayır"}</td>
                  <td>{row.can_delete ? "Evet" : "Hayır"}</td>
                  <td>{row.can_approve ? "Evet" : "Hayır"}</td>
                  <td>{row.permissions.map((permission) => permissionLabels[permission] ?? permission).join(", ")}</td>
                </tr>
              ))}
              {!rows.length ? (
                <tr>
                  <td colSpan={8}>Gösterilecek rol yetkisi bulunmuyor.</td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
