import { useEffect, useState } from "react";

import {
  acceptNegotiation,
  createNegotiation,
  getNegotiation,
  listNegotiations,
  rejectNegotiation,
  requestMeeting,
  submitCustomerExpectation
} from "../../api/negotiationApi";
import { getLatestAppraisalId } from "../../utils/appraisalDraft";
import { formatIntegerInput, parseIntegerInput } from "../../utils/format";
import { getErrorMessage } from "../../utils/http";

type NegotiationDetail = Awaited<ReturnType<typeof getNegotiation>>;
type NegotiationHistoryItem = NegotiationDetail["history"][number];

function getNegotiationStatusLabel(status: string) {
  switch (status) {
    case "open":
      return "Pazarlık başlatıldı";
    case "auto_negotiating":
      return "Teklif bekleniyor";
    case "pending_manager_review":
      return "Yönetici incelemesinde";
    case "accepted":
      return "Anlaşma sağlandı";
    case "rejected":
      return "Pazarlık sonlandırıldı";
    case "cancelled":
      return "Pazarlık iptal edildi";
    default:
      return "Pazarlık güncelleniyor";
  }
}

function getHistoryLabel(item: NegotiationHistoryItem) {
  if (item.message_type === "initial_offer") return "Sistem ilk teklifi oluşturdu";
  if (item.message_type === "customer_expectation") return "Müşteri yeni beklenti fiyatı gönderdi";
  if (item.message_type === "counter_offer") return "Bayi yeni karşı teklif sundu";
  if (item.message_type === "accepted_offer") return "Teklif uygun bulundu";
  if (item.message_type === "meeting_requested") return "Toplantı talebi oluşturuldu";
  if (item.message_type === "rejected_offer") return "Teklif reddedildi";
  return "Pazarlık kaydı güncellendi";
}

export function NegotiationPage() {
  const [negotiationId, setNegotiationId] = useState<number | null>(null);
  const [detail, setDetail] = useState<NegotiationDetail | null>(null);
  const [expectedPrice, setExpectedPrice] = useState("");
  const [pageError, setPageError] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ type: "error" | "success"; message: string } | null>(null);

  function showFeedback(type: "error" | "success", message: string) {
    setFeedback({ type, message });
    window.setTimeout(() => {
      setFeedback((current) => (current?.message === message ? null : current));
    }, 2600);
  }

  async function refresh(id: number) {
    const data = await getNegotiation(id);
    setDetail(data);
    setNegotiationId(id);
  }

  useEffect(() => {
    async function bootstrapNegotiation() {
      try {
        const existingRows = await listNegotiations();
        const activeStatuses = new Set(["open", "auto_negotiating", "pending_manager_review", "accepted"]);
        const existingActive = existingRows.find((row) => activeStatuses.has(String(row.status)));

        if (existingActive) {
          await refresh(existingActive.id);
          return;
        }

        const appraisalId = getLatestAppraisalId();
        if (!appraisalId) {
          setPageError("Pazarlık başlatmak için önce bir ekspertiz kaydı oluşturun.");
          return;
        }

        const result = await createNegotiation(appraisalId);
        await refresh(result.negotiationId);
      } catch {
        setPageError("Pazarlık kaydı alınamadı.");
      }
    }

    bootstrapNegotiation();
  }, []);

  async function handleExpectation() {
    if (!negotiationId || !expectedPrice) return;
    try {
      setPageError(null);
      await submitCustomerExpectation(negotiationId, parseIntegerInput(expectedPrice));
      showFeedback("success", "Beklenti fiyatınız gönderildi.");
      await refresh(negotiationId);
    } catch (requestError) {
      showFeedback("error", getErrorMessage(requestError, "Beklenti fiyatı gönderilemedi."));
    }
  }

  async function handleAccept() {
    if (!negotiationId) return;
    await acceptNegotiation(negotiationId);
    showFeedback("success", "Teklif kabul edildi.");
    refresh(negotiationId);
  }

  async function handleReject() {
    if (!negotiationId) return;
    await rejectNegotiation(negotiationId);
    showFeedback("success", "Pazarlık sonlandırıldı.");
    refresh(negotiationId);
  }

  async function handleMeeting() {
    if (!negotiationId) return;
    await requestMeeting(negotiationId);
    showFeedback("success", "Toplantı talebiniz iletildi.");
    refresh(negotiationId);
  }

  if (pageError) return <div className="page-state">{pageError}</div>;
  if (!detail) return <div className="page-state">Pazarlık hazırlanıyor...</div>;

  const customerExpectations = detail.history.filter((item) => item.message_type === "customer_expectation" && item.offered_price);
  const firstExpectedPrice = customerExpectations[0]?.offered_price ?? null;
  const currentExpectedPrice = detail.customer_expected_price ?? customerExpectations.at(-1)?.offered_price ?? null;
  const isClosed = ["accepted", "rejected", "cancelled"].includes(String(detail.status));

  return (
    <section className="dashboard-page">
      {feedback ? (
        <div className={`floating-feedback floating-feedback--${feedback.type}`}>
          {feedback.message}
        </div>
      ) : null}
      <div className="content-grid">
        <section className="panel">
          <div className="panel-heading panel-heading--stacked">
            <div>
              <h3>Pazarlık Ekranı</h3>
              <p className="section-subtitle">Müşteri beklenti fiyatı girerek karşı teklif alabilir.</p>
            </div>
          </div>
          <div className="offer-summary">
            <div>
              <span>Güncel bayi teklifi</span>
              <strong>₺{Number(detail.current_dealer_offer).toLocaleString("tr-TR")}</strong>
            </div>
            <div>
              <span>İlk beklentiniz</span>
              <strong>{firstExpectedPrice ? `₺${Number(firstExpectedPrice).toLocaleString("tr-TR")}` : "-"}</strong>
            </div>
            <div>
              <span>Güncel beklentiniz</span>
              <strong>{currentExpectedPrice ? `₺${Number(currentExpectedPrice).toLocaleString("tr-TR")}` : "-"}</strong>
            </div>
            <div>
              <span>Durum</span>
              <strong>{getNegotiationStatusLabel(String(detail.status))}</strong>
            </div>
          </div>
          {detail.status === "accepted" ? (
            <div className="decision-banner decision-banner--success" style={{ marginTop: 16 }}>
              <strong>Anlaşma sağlandı</strong>
              <span>Bayi ekibimiz kısa süre içinde sizinle iletişime geçerek sürecin devamını paylaşacaktır.</span>
            </div>
          ) : null}
          {detail.status === "rejected" ? (
            <div className="decision-banner decision-banner--warning" style={{ marginTop: 16 }}>
              <strong>Pazarlık sonlandırıldı</strong>
              <span>Bu pazarlık kaydı kapandı. Yeni değerlendirme için bir sonraki ekspertiz hakkınızı beklemeniz gerekir.</span>
            </div>
          ) : null}
        </section>

        <section className="panel">
          <div className="panel-heading panel-heading--stacked">
            <div>
              <h3>Beklenti Gir</h3>
              <p className="section-subtitle">Sistem, verdiğiniz fiyatı değerlendirip size daha düşük ama makul bir bayi teklifi sunar. Çok yüksek talepler ise yöneticinin incelemesine gider.</p>
            </div>
          </div>
          {isClosed ? (
            <div className="decision-banner decision-banner--success" style={{ marginBottom: 16 }}>
              <strong>Bu pazarlık tamamlandı</strong>
              <span>Yeni teklif gönderimi kapatıldı.</span>
            </div>
          ) : null}
          <div className="action-grid">
            <input
              className="inline-input"
              inputMode="numeric"
              placeholder="Beklenen fiyat"
              value={expectedPrice}
              onChange={(e) => setExpectedPrice(formatIntegerInput(e.target.value))}
              disabled={isClosed}
            />
            <button className="primary-button" type="button" onClick={handleExpectation} disabled={isClosed}>
              Beklenti Gönder
            </button>
            <button className="ghost-button" type="button" onClick={handleAccept} disabled={isClosed}>
              Teklifi Kabul Et
            </button>
            <button className="danger-button" type="button" onClick={handleReject} disabled={isClosed}>
              Reddet
            </button>
            <button className="ghost-button" type="button" onClick={handleMeeting} disabled={isClosed}>
              Toplantı İste
            </button>
          </div>
        </section>
      </div>

      <section className="panel">
        <div className="panel-heading panel-heading--stacked">
          <div>
            <h3>Karşı Teklif Geçmişi</h3>
            <p className="section-subtitle">Sistem ve müşteri etkileşimleri</p>
          </div>
        </div>
        <ul className="timeline-list">
          {detail.history.map((item: NegotiationHistoryItem) => (
            <li key={item.id}>
              {getHistoryLabel(item)}
              {item.offered_price ? ` / ₺${Number(item.offered_price).toLocaleString("tr-TR")}` : ""}
              {item.note ? ` - ${item.note}` : ""}
            </li>
          ))}
        </ul>
      </section>
    </section>
  );
}
