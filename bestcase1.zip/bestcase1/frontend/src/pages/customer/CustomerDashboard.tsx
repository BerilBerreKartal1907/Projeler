import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import { getDashboardMetrics } from "../../api/dashboardApi";
import { listNotifications } from "../../api/notificationApi";
import { PageSection } from "../../components/common/PageSection";
import { StatCard } from "../../components/common/StatCard";
import { getErrorMessage } from "../../utils/http";

export function CustomerDashboard() {
  const navigate = useNavigate();
  const [metrics, setMetrics] = useState({
    activeAppraisal: 0,
    pendingPreliminaryOffer: 0,
    activeNegotiation: 0,
    upcomingAppointment: 0,
    pendingApproval: 0,
    latestCreditMonthlyPayment: 0,
    unreadNotifications: 0
  });
  const [notifications, setNotifications] = useState<Array<{ id: number; title: string; message: string }>>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([getDashboardMetrics("customer"), listNotifications()])
      .then(([dashboardResponse, notificationRows]) => {
        setMetrics(dashboardResponse as typeof metrics);
        setNotifications(notificationRows.slice(0, 3));
      })
      .catch((requestError) => setError(getErrorMessage(requestError, "Müşteri paneli verileri alınamadı.")));
  }, []);

  return (
    <section className="dashboard-page">
      <div className="stats-grid">
        <StatCard label="Aktif Ekspertiz" value={String(metrics.activeAppraisal)} />
        <StatCard label="Hazır Ön Teklif" value={String(metrics.pendingPreliminaryOffer)} tone="success" />
        <StatCard label="Bekleyen Onay" value={String(metrics.pendingApproval)} tone="warning" />
        <StatCard label="Aktif Pazarlık" value={String(metrics.activeNegotiation)} tone="success" />
        <StatCard label="Yaklaşan Servis" value={String(metrics.upcomingAppointment)} />
        <StatCard
          label="Son Finansman Taksiti"
          value={metrics.latestCreditMonthlyPayment ? `₺${Number(metrics.latestCreditMonthlyPayment).toLocaleString("tr-TR")}` : "-"}
        />
        <StatCard label="Okunmamış Bildirim" value={String(metrics.unreadNotifications)} />
      </div>
      {error ? <p className="form-error">{error}</p> : null}

      {metrics.pendingPreliminaryOffer > 0 ? (
        <PageSection title="Ön teklif hazır" subtitle="Ekspertiz kaydınız için oluşturulan ön değerlendirme pazarlık ekranında görüntülenebilir.">
          <div className="decision-banner decision-banner--success">
            <strong>Ön teklifinizi şimdi inceleyebilir ve isterseniz pazarlığa başlayabilirsiniz.</strong>
            <span>Sistem teklifi, araç bilgileri ve hasar durumuna göre oluşturuldu. Ayrıntıları pazarlık ekranında görebilirsiniz.</span>
          </div>
          <div className="action-grid" style={{ marginTop: 16 }}>
            <button className="primary-button" onClick={() => navigate("/customer/negotiation")}>
              Ön Teklifi Gör ve Pazarlığa Geç
            </button>
          </div>
        </PageSection>
      ) : null}

      <div className="content-grid">
        <PageSection title="Hızlı İşlemler" subtitle="Müşteri için en kritik adımlar">
          <div className="action-grid">
            <button className="primary-button" onClick={() => navigate("/customer/appraisal/new")}>
              Araç Ekspertizi Başlat
            </button>
            <button className="ghost-button" onClick={() => navigate("/customer/service")}>
              Servis Randevusu Al
            </button>
            <button className="ghost-button" onClick={() => navigate("/customer/negotiation")}>
              Pazarlık Ekranı
            </button>
            <button className="ghost-button" onClick={() => navigate("/customer/financing")}>
              Finansman Hesapla
            </button>
          </div>
        </PageSection>
        <PageSection title="Bildirimler" subtitle="Son güncellemeler">
          <ul className="timeline-list">
            {notifications.length ? notifications.map((item) => (
              <li key={item.id}>
                <strong>{item.title}:</strong> {item.message}
              </li>
            )) : <li>Henüz bildirim bulunmuyor.</li>}
          </ul>
        </PageSection>
      </div>
    </section>
  );
}
