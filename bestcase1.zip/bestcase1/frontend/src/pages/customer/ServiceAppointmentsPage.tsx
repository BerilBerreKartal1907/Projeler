import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import { listAppointments, type ServiceAppointmentRow } from "../../api/serviceApi";
import { getErrorMessage } from "../../utils/http";
import { getServiceStatusLabel, serviceTypeLabels } from "../../utils/labels";

export function ServiceAppointmentsPage() {
  const [appointments, setAppointments] = useState<ServiceAppointmentRow[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    listAppointments()
      .then(setAppointments)
      .catch((requestError) => setError(getErrorMessage(requestError, "Randevular alınamadı.")));
  }, []);

  return (
    <section className="dashboard-page">
      <section className="panel">
        <div className="panel-heading panel-heading--stacked">
          <div>
            <h3>Servis Randevularım</h3>
            <p className="section-subtitle">Oluşturduğunuz servis randevularını buradan takip edebilirsiniz.</p>
          </div>
        </div>
        {error ? <p className="form-error">{error}</p> : null}
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Araç</th>
                <th>Servis tipi</th>
                <th>Tarih</th>
                <th>Durum</th>
                <th>Aksiyon</th>
              </tr>
            </thead>
            <tbody>
              {appointments.map((appointment) => (
                <tr key={appointment.id}>
                  <td>{appointment.brand} {appointment.model}</td>
                  <td>{serviceTypeLabels[appointment.service_type] ?? appointment.service_type}</td>
                  <td>{new Date(appointment.appointment_datetime).toLocaleString("tr-TR")}</td>
                  <td>{getServiceStatusLabel(appointment.status)}</td>
                  <td>
                    {appointment.status === "waiting_customer_approval" ? (
                      <Link className="ghost-button" to="/customer/checkup-approval">
                        İşlemleri Onayla
                      </Link>
                    ) : (
                      <span>Takip ediliyor</span>
                    )}
                  </td>
                </tr>
              ))}
              {!appointments.length ? (
                <tr>
                  <td colSpan={5}>Henüz servis randevunuz bulunmuyor.</td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
