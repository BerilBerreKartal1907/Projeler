import { useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import { saveDamageDetails, type DamageEntry } from "../../api/appraisalApi";
import { damageTypeLabels, vehiclePartLabels } from "../../utils/labels";

const vehicleParts = [
  "hood",
  "roof",
  "front_bumper",
  "rear_bumper",
  "right_front_door",
  "right_rear_door",
  "left_front_door",
  "left_rear_door",
  "trunk",
  "right_fender",
  "left_fender",
  "engine",
  "tires"
] as const;

const damageTypePoints: Record<DamageEntry["damageType"], number> = {
  original: 0,
  painted: 2,
  local_painted: 5,
  replaced: 3,
  damaged: 10
};

export function DamageMarkingPage() {
  const navigate = useNavigate();
  const { appraisalId } = useParams();
  const [damages, setDamages] = useState<Record<string, DamageEntry["damageType"]>>(
    Object.fromEntries(vehicleParts.map((part) => [part, "original"]))
  );
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const damageScore = useMemo(
    () => Object.values(damages).reduce((sum, type) => sum + damageTypePoints[type], 0),
    [damages]
  );
  const damagePercentage = ((damageScore / (vehicleParts.length * 10)) * 100).toFixed(2);

  async function handleSubmit() {
    if (!appraisalId) {
      setError("Ekspertiz kaydı bulunamadı.");
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const payload = vehicleParts.map((part) => ({
        vehiclePart: part,
        damageType: damages[part],
        note: notes[part] || undefined
      }));

      await saveDamageDetails(Number(appraisalId), payload);
      navigate(`/customer/appraisal/${appraisalId}/offer`);
    } catch {
      setError("Hasar bilgileri kaydedilemedi.");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <section className="dashboard-page">
      <section className="panel form-panel">
        <div className="panel-heading">
          <div>
            <h3>Hasar İşaretleme</h3>
            <p className="section-subtitle">Bu alan müşteri ön beyanıdır, resmi ekspertiz raporu değildir.</p>
          </div>
          <div className="offer-metrics">
            <span>Puan: {damageScore}</span>
            <strong>Hasar: %{damagePercentage}</strong>
          </div>
        </div>

        <div className="damage-grid">
          {vehicleParts.map((part) => (
            <article key={part} className="damage-card">
              <h4>{vehiclePartLabels[part] ?? part}</h4>
              <select
                value={damages[part]}
                onChange={(e) =>
                  setDamages((current) => ({
                    ...current,
                    [part]: e.target.value as DamageEntry["damageType"]
                  }))
                }
              >
                <option value="original">{damageTypeLabels.original}</option>
                <option value="painted">{damageTypeLabels.painted}</option>
                <option value="local_painted">{damageTypeLabels.local_painted}</option>
                <option value="replaced">{damageTypeLabels.replaced}</option>
                <option value="damaged">{damageTypeLabels.damaged}</option>
              </select>
              <input
                placeholder="Not"
                value={notes[part] ?? ""}
                onChange={(e) =>
                  setNotes((current) => ({
                    ...current,
                    [part]: e.target.value
                  }))
                }
              />
            </article>
          ))}
        </div>

        {error ? <p className="form-error">{error}</p> : null}

        <div className="form-actions">
          <button className="primary-button" type="button" onClick={handleSubmit} disabled={isSubmitting}>
            {isSubmitting ? "Hesaplanıyor..." : "Ön Teklifi Hesapla"}
          </button>
        </div>
      </section>
    </section>
  );
}
