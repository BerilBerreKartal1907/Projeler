import { useEffect, useState } from "react";

import {
  createCreditCalculation,
  listCreditCalculations,
  type CreditCalculationRow
} from "../../api/financeApi";
import { financingBanks, financingMaturityOptions, getFinancingRate } from "../../utils/labels";
import { formatCurrency, formatIntegerInput, parseIntegerInput } from "../../utils/format";
import { getErrorMessage } from "../../utils/http";

export function FinancingCalculatorPage() {
  const [latest, setLatest] = useState<CreditCalculationRow | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [form, setForm] = useState<{
    amount: string;
    bankCode: string;
    maturityMonths: string;
    monthlyInterestRate: string;
  }>({
    amount: "",
    bankCode: financingBanks[0].code,
    maturityMonths: "12",
    monthlyInterestRate: String(getFinancingRate(financingBanks[0].code, 12))
  });

  useEffect(() => {
    listCreditCalculations()
      .then((creditRows) => {
        setLatest(creditRows[0] ?? null);
      })
      .catch((requestError) => setError(getErrorMessage(requestError, "Finansman verileri alınamadı.")));
  }, []);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setMessage(null);

    try {
      const amount = parseIntegerInput(form.amount);
      const maturityMonths = Number(form.maturityMonths);
      const monthlyInterestRate = Number(form.monthlyInterestRate);

      if (amount <= 0) {
        setError("Tutar pozitif bir değer olmalıdır.");
        return;
      }

      if (maturityMonths <= 0) {
        setError("Vade suresi secilmelidir.");
        return;
      }

      if (monthlyInterestRate < 0) {
        setError("Faiz orani negatif olamaz.");
        return;
      }

      const result = await createCreditCalculation({
        vehiclePrice: amount,
        downPayment: 0,
        maturityMonths,
        monthlyInterestRate
      });
      setLatest(result);
      setMessage("Finansman simülasyonu hesaplandı.");
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Finansman hesaplaması yapılamadı."));
    }
  }

  return (
    <section className="dashboard-page">
      <div className="content-grid">
        <section className="panel form-panel">
          <div className="panel-heading panel-heading--stacked">
            <div>
              <h3>Finansman Hesaplama</h3>
              <p className="section-subtitle">Bu ekran kredi başvurusu değil, yalnızca kredi geri ödeme simülasyonudur.</p>
            </div>
          </div>
          <form className="appraisal-form-grid" onSubmit={handleSubmit}>
            <label>
              <span>Banka</span>
              <select
                value={form.bankCode}
                onChange={(e) => {
                  const bank = financingBanks.find((item) => item.code === e.target.value) ?? financingBanks[0];
                  setForm((current) => ({
                    ...current,
                    bankCode: bank.code,
                    monthlyInterestRate: String(getFinancingRate(bank.code, Number(current.maturityMonths)))
                  }));
                }}
              >
                {financingBanks.map((bank) => (
                  <option key={bank.code} value={bank.code}>{bank.name}</option>
                ))}
              </select>
            </label>
            <label>
              <span>Kredi tutarı</span>
              <input inputMode="numeric" value={form.amount} onChange={(e) => setForm({ ...form, amount: formatIntegerInput(e.target.value) })} required />
            </label>
            <label>
              <span>Vade (ay)</span>
              <select
                value={form.maturityMonths}
                onChange={(e) => {
                  const months = Number(e.target.value);
                  setForm((current) => ({
                    ...current,
                    maturityMonths: e.target.value,
                    monthlyInterestRate: String(getFinancingRate(current.bankCode, months))
                  }));
                }}
                required
              >
                {financingMaturityOptions.map((month) => (
                  <option key={month} value={month}>{month} ay</option>
                ))}
              </select>
            </label>
            <label>
              <span>Aylık faiz oranı</span>
              <input type="number" min="0" step="0.01" value={form.monthlyInterestRate} onChange={(e) => setForm({ ...form, monthlyInterestRate: e.target.value })} required />
            </label>
            <div className="form-actions">
              <button className="primary-button" type="submit">Hesapla</button>
            </div>
            {error ? <p className="form-error form-error--wide">{error}</p> : null}
            {message ? <p className="form-success form-error--wide">{message}</p> : null}
          </form>
        </section>

        <section className="panel">
          <div className="panel-heading panel-heading--stacked">
            <div>
              <h3>Son Hesaplama</h3>
              <p className="section-subtitle">Kaydedilen en güncel finansman sonucu</p>
            </div>
          </div>
          {latest ? (
            <div className="offer-summary">
              <div><span>Tutar</span><strong>{formatCurrency(latest.financed_amount)}</strong></div>
              <div><span>Aylık ödeme</span><strong>{formatCurrency(latest.monthly_payment)}</strong></div>
              <div><span>Toplam geri ödeme</span><strong>{formatCurrency(latest.total_payment ?? 0)}</strong></div>
              <div><span>Toplam faiz</span><strong>{formatCurrency(latest.total_interest)}</strong></div>
            </div>
          ) : <p className="section-subtitle">Henüz hesaplama yapılmadı.</p>}
        </section>
      </div>
    </section>
  );
}
