import { useEffect, useState } from "react";

import { listNotifications } from "../../api/notificationApi";
import { getErrorMessage } from "../../utils/http";

type NotificationRow = {
  id: number;
  title: string;
  message: string;
  created_at?: string;
};

export function NotificationsPage() {
  const [rows, setRows] = useState<NotificationRow[]>([]);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    const data = await listNotifications();
    setRows(data);
  }

  useEffect(() => {
    refresh().catch((requestError) => setError(getErrorMessage(requestError, "Bildirimler alınamadı.")));
  }, []);

  return (
    <section className="dashboard-page">
      <section className="panel">
        <div className="panel-heading">
          <div>
            <h3>Bildirimler</h3>
            <p className="section-subtitle">Sistemin sizin için oluşturduğu güncel bilgilendirmeler</p>
          </div>
        </div>
        {error ? <p className="form-error">{error}</p> : null}
        <div className="notification-list">
          {rows.map((row) => (
            <article key={row.id} className="notification-card">
              <strong>{row.title}</strong>
              <p>{row.message}</p>
              {row.created_at ? <span>{new Date(row.created_at).toLocaleString("tr-TR")}</span> : null}
            </article>
          ))}
          {!rows.length ? <p className="section-subtitle">Henüz bildiriminiz bulunmuyor.</p> : null}
        </div>
      </section>
    </section>
  );
}
