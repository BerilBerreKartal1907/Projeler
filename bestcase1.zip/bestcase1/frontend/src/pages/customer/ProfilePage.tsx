import { useEffect, useState } from "react";

import { getMyCustomerProfile, updateMyCustomerProfile } from "../../api/customerApi";
import { COUNTRY_CITIES } from "../../utils/geo";
import { getErrorMessage } from "../../utils/http";
import { PHONE_COUNTRIES, buildPhoneNumber, splitPhoneNumber } from "../../utils/phone";

export function ProfilePage() {
  const [form, setForm] = useState<{
    fullName: string;
    countryCode: string;
    localNumber: string;
    address: string;
    city: string;
  }>({
    fullName: "",
    countryCode: PHONE_COUNTRIES[0].code,
    localNumber: "",
    address: "",
    city: ""
  });
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getMyCustomerProfile()
      .then((profile) =>
        {
          const phone = splitPhoneNumber(profile.phone);
          return setForm({
            fullName: profile.full_name ?? "",
            countryCode: phone.countryCode,
            localNumber: phone.localNumber,
            address: profile.address ?? "",
            city: profile.city ?? ""
          });
        }
      )
      .catch((requestError) => setError(getErrorMessage(requestError, "Profil bilgileri alınamadı.")));
  }, []);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setMessage(null);

    try {
      await updateMyCustomerProfile({
        fullName: form.fullName,
        phone: buildPhoneNumber(form.countryCode, form.localNumber),
        address: form.address,
        city: form.city
      });
      setMessage("Profil güncellendi.");
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Profil güncellenemedi."));
    }
  }

  return (
    <section className="dashboard-page">
      <section className="panel form-panel">
        <div className="panel-heading panel-heading--stacked">
          <div>
            <h3>Profil</h3>
            <p className="section-subtitle">Müşteri iletişim bilgileri ve adres alanları</p>
          </div>
        </div>

        <form className="appraisal-form-grid" onSubmit={handleSubmit}>
          <label>
            <span>Ad Soyad</span>
            <input value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
          </label>
          <label>
            <span>Telefon</span>
            <div className="phone-field">
              <select value={form.countryCode} onChange={(e) => setForm({ ...form, countryCode: e.target.value, city: "" })}>
                {PHONE_COUNTRIES.map((country) => (
                  <option key={country.code} value={country.code}>{country.label}</option>
                ))}
              </select>
              <input value={form.localNumber} onChange={(e) => setForm({ ...form, localNumber: e.target.value.replace(/[^\d]/g, "") })} />
            </div>
          </label>
          <label className="form-span-2">
            <span>Adres</span>
            <input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
          </label>
          <label>
            <span>Şehir</span>
            <select value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })}>
              <option value="">Şehir seçin</option>
              {(COUNTRY_CITIES[form.countryCode] ?? []).map((city) => (
                <option key={city} value={city}>{city}</option>
              ))}
            </select>
          </label>
          {error ? <p className="form-error form-error--wide">{error}</p> : null}
          {message ? <p className="form-success form-error--wide">{message}</p> : null}
          <div className="form-actions">
            <button className="primary-button" type="submit">Kaydet</button>
          </div>
        </form>
      </section>
    </section>
  );
}
