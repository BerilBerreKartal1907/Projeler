import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import DatePicker, { registerLocale } from "react-datepicker";
import { format } from "date-fns/format";
import { tr } from "date-fns/locale/tr";

import {
  createServiceAppointment,
  getAvailability,
  listVehicles,
  type AvailabilitySlot,
  type VehicleOption
} from "../../api/serviceApi";
import { getErrorMessage } from "../../utils/http";
import { serviceTypeLabels } from "../../utils/labels";
import "react-datepicker/dist/react-datepicker.css";

registerLocale("tr", tr);

export function ServiceAppointmentPage() {
  const [vehicles, setVehicles] = useState<VehicleOption[]>([]);
  const [form, setForm] = useState({
    vehicleId: "",
    serviceType: "",
    appointmentDate: "",
    appointmentTime: "",
    complaintDescription: ""
  });
  const [slots, setSlots] = useState<AvailabilitySlot[]>([]);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    listVehicles()
      .then((vehicleRows) => {
        setVehicles(vehicleRows);
      })
      .catch(() => setError("Araç listesi alınamadı."));
  }, []);

  useEffect(() => {
    if (!form.appointmentDate) {
      setSlots([]);
      return;
    }

    if (!form.serviceType) {
      setSlots([]);
      return;
    }

    getAvailability(form.serviceType, form.appointmentDate)
      .then((response) => {
        setSlots(response.slots);
      })
      .catch(() => setError("Uygun servis saatleri alınamadı."));
  }, [form.appointmentDate, form.serviceType]);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setMessage(null);

    try {
      if (!form.appointmentDate || !form.appointmentTime) {
        setError("Lütfen önce tarih ve saat seçin.");
        return;
      }

      const appointmentDatetime = `${form.appointmentDate}T${form.appointmentTime}:00`;
      const appointmentDate = new Date(appointmentDatetime);
      if (Number.isNaN(appointmentDate.getTime()) || appointmentDate <= new Date()) {
        setError("Randevu tarihi şu andan ileri bir zaman olmalıdır.");
        return;
      }

      const selectedSlot = slots.find((slot) => slot.time === form.appointmentTime);
      if (!selectedSlot?.available) {
        setError("Seçtiğiniz saat artık dolu görünüyor. Lütfen başka bir saat seçin.");
        return;
      }

      await createServiceAppointment({
        vehicleId: Number(form.vehicleId),
        serviceType: form.serviceType,
        appointmentDatetime,
        complaintDescription: form.complaintDescription
      });

      setMessage("Servis randevusu oluşturuldu.");
      setForm({
        vehicleId: "",
        serviceType: "",
        appointmentDate: "",
        appointmentTime: "",
        complaintDescription: ""
      });
      setSlots([]);
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Servis randevusu oluşturulamadı."));
    }
  }

  return (
    <section className="dashboard-page">
      <section className="panel form-panel">
        <div className="panel-heading panel-heading--stacked">
          <div>
            <h3>Servis Randevusu</h3>
            <p className="section-subtitle">Kapasite uygunluğuna göre randevu oluşturun.</p>
          </div>
        </div>

        <form className="appraisal-form-grid" onSubmit={handleSubmit}>
          <label>
            <span>Araç</span>
            <select value={form.vehicleId} onChange={(e) => setForm({ ...form, vehicleId: e.target.value })} required>
              <option value="">Araç seçin</option>
              {vehicles.map((vehicle) => (
                <option key={vehicle.id} value={vehicle.id}>
                  {vehicle.brand} {vehicle.model}{vehicle.plate ? ` - ${vehicle.plate}` : ""}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>Servis tipi</span>
            <select value={form.serviceType} onChange={(e) => setForm({ ...form, serviceType: e.target.value, appointmentTime: "" })} required>
              <option value="">Seçiniz</option>
              <option value="maintenance">{serviceTypeLabels.maintenance}</option>
              <option value="check_up">{serviceTypeLabels.check_up}</option>
              <option value="accident_repair">{serviceTypeLabels.accident_repair}</option>
              <option value="modification">{serviceTypeLabels.modification}</option>
            </select>
          </label>
          <label>
            <span>Tarih</span>
            <DatePicker
              locale="tr"
              selected={form.appointmentDate ? new Date(`${form.appointmentDate}T12:00:00`) : null}
              onChange={(value: Date | null) =>
                setForm((current) => ({
                  ...current,
                  appointmentDate: value ? format(value, "yyyy-MM-dd") : "",
                  appointmentTime: ""
                }))
              }
              minDate={new Date()}
              dateFormat="dd.MM.yyyy"
              placeholderText="Tarih seçin"
              className="date-input date-input--large date-input--picker"
              calendarClassName="service-datepicker"
              required
            />
          </label>
          <div className="form-span-2 slot-panel">
            <span className="slot-panel__title">Uygun Saatler</span>
            <p className="section-subtitle">Yeşil saatler boş, kırmızı saatler doludur. Seçtiğiniz saat kaydedildiğinde otomatik dolu olur.</p>
            <div className="slot-grid">
              {slots.map((slot) => (
                <button
                  key={slot.time}
                  className={`slot-chip ${slot.available ? "slot-chip--free" : "slot-chip--busy"} ${form.appointmentTime === slot.time ? "slot-chip--selected" : ""}`}
                  type="button"
                  disabled={!slot.available}
                  onClick={() => setForm((current) => ({ ...current, appointmentTime: slot.time }))}
                >
                  {slot.time}
                </button>
              ))}
              {!slots.length ? <p className="section-subtitle">Önce tarih seçin, sonra uygun saatler burada görünsün.</p> : null}
            </div>
          </div>
          <label className="form-span-2">
            <span>Açıklama</span>
            <input
              value={form.complaintDescription}
              onChange={(e) => setForm({ ...form, complaintDescription: e.target.value })}
            />
          </label>

          {error ? <p className="form-error form-error--wide">{error}</p> : null}
          {message ? <p className="form-success form-error--wide">{message}</p> : null}

          <div className="form-actions">
            <Link className="ghost-button" to="/customer/service/appointments">Randevularımı Gör</Link>
            <button className="primary-button" type="submit">Randevu Oluştur</button>
          </div>
        </form>
      </section>
    </section>
  );
}
