import { useEffect, useState } from "react";

import {
  approveOperation,
  listAppointments,
  listOperations,
  rejectOperation,
  type ServiceOperationRow
} from "../../api/serviceApi";
import { getManagerReviewStatusLabel, getOperationApprovalStatusLabel } from "../../utils/labels";

export function CheckupApprovalPage() {
  const [appointmentId, setAppointmentId] = useState<number | null>(null);
  const [operations, setOperations] = useState<ServiceOperationRow[]>([]);
  const [error, setError] = useState<string | null>(null);

  async function refresh(targetAppointmentId: number) {
    const rows = await listOperations(targetAppointmentId);
    setOperations(rows);
    setAppointmentId(targetAppointmentId);
  }

  useEffect(() => {
    listAppointments()
      .then((appointments) => {
        const appointment = appointments.find((item) => item.status === "waiting_customer_approval");
        if (appointment) {
          refresh(appointment.id);
        }
      })
      .catch(() => setError("Operasyon listesi alınamadı."));
  }, []);

  async function handleApprove(id: number) {
    await approveOperation(id);
    if (appointmentId) refresh(appointmentId);
  }

  async function handleReject(id: number) {
    const result = await rejectOperation(id);
    if (result.warning) {
      setError(result.warning);
    }
    if (appointmentId) refresh(appointmentId);
  }

  if (error && !operations.length) return <div className="page-state">{error}</div>;

  return (
    <section className="dashboard-page">
      <section className="panel">
        <div className="panel-heading">
          <div>
            <h3>Check-up Onayı</h3>
            <p className="section-subtitle">Müşteri yalnızca kendi operasyonlarını onaylar veya reddeder.</p>
          </div>
        </div>
        {error ? <p className="form-error">{error}</p> : null}
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>İşlem</th>
                <th>Parça</th>
                <th>İşçilik</th>
                <th>Toplam</th>
                <th>Kritik mi?</th>
                <th>Durum</th>
                <th>Yönetici</th>
                <th>Onay</th>
              </tr>
            </thead>
            <tbody>
              {operations.map((operation) => (
                <tr key={operation.id}>
                  <td>{operation.operation_name}</td>
                  <td>₺{Number(operation.part_price).toLocaleString("tr-TR")}</td>
                  <td>₺{Number(operation.labor_price).toLocaleString("tr-TR")}</td>
                  <td>₺{Number(operation.total_price).toLocaleString("tr-TR")}</td>
                  <td>{operation.is_critical_safety ? "Evet" : "Hayır"}</td>
                  <td>{getOperationApprovalStatusLabel(operation.customer_approval_status)}</td>
                  <td>{getManagerReviewStatusLabel(operation.manager_review_status)}</td>
                  <td>
                    <div className="action-grid action-grid--tight">
                      <button className="primary-button" type="button" onClick={() => handleApprove(operation.id)} disabled={operation.customer_approval_status !== "pending"}>Onayla</button>
                      <button className="danger-button" type="button" onClick={() => handleReject(operation.id)} disabled={operation.customer_approval_status !== "pending"}>Reddet</button>
                    </div>
                  </td>
                </tr>
              ))}
              {!operations.length ? (
                <tr>
                  <td colSpan={8}>Müşteri onayı bekleyen servis operasyonu bulunmuyor.</td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
