import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useParams } from "react-router-dom";

import { getPreliminaryOffer, updateExpectedPrice } from "../../api/appraisalApi";
import { formatCurrency, formatIntegerInput, formatNumber, parseIntegerInput } from "../../utils/format";
import { getErrorMessage } from "../../utils/http";

type OfferState = Awaited<ReturnType<typeof getPreliminaryOffer>>;

export function PreliminaryOfferPage() {
  const { appraisalId } = useParams();
  const navigate = useNavigate();
  const [offer, setOffer] = useState<OfferState | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [expectedPriceInput, setExpectedPriceInput] = useState("");
  const [isSavingExpectedPrice, setIsSavingExpectedPrice] = useState(false);

  useEffect(() => {
    if (!appraisalId) {
      return;
    }

    getPreliminaryOffer(Number(appraisalId))
      .then((data) => {
        setOffer(data);
        setExpectedPriceInput(data.expected_selling_price ? Number(data.expected_selling_price).toLocaleString("tr-TR") : "");
      })
      .catch(() => setError("Ön teklif bilgisi alınamadı."));
  }, [appraisalId]);

  if (error) {
    return <div className="page-state">{error}</div>;
  }

  if (!offer) {
    return <div className="page-state">Ön teklif hazırlanıyor...</div>;
  }

  const visibleDiscounts = offer.applied_discounts.filter((item) => !item.toLowerCase().includes("minimum kar"));

  async function handleExpectedPriceSave() {
    if (!appraisalId) return;

    try {
      setIsSavingExpectedPrice(true);
      setError(null);
      const updated = await updateExpectedPrice(Number(appraisalId), parseIntegerInput(expectedPriceInput));
      setOffer(updated);
      setExpectedPriceInput(updated.expected_selling_price ? Number(updated.expected_selling_price).toLocaleString("tr-TR") : "");
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Beklenen fiyat kaydedilemedi."));
    } finally {
      setIsSavingExpectedPrice(false);
    }
  }

  return (
    <section className="dashboard-page">
      <div className="content-grid">
        <section className="panel">
          <div className="panel-heading panel-heading--stacked">
            <div>
              <h3>Ön Alım Teklifi</h3>
              <p className="section-subtitle">Bu ekran nihai teklif değil, sistem tarafından oluşturulan ön değerlendirmedir.</p>
            </div>
          </div>

          <div className="offer-summary">
            <div>
              <span>Müşteri beklentisi</span>
              <strong>{formatCurrency((offer as { expected_selling_price?: string | null }).expected_selling_price ?? null)}</strong>
            </div>
            <div>
              <span>Hasar yüzdesi</span>
              <strong>%{formatNumber(offer.damage_percentage, 2)}</strong>
            </div>
            <div>
              <span>Sistemin ön teklifi</span>
              <strong>{formatCurrency(offer.calculated_offer)}</strong>
            </div>
            {"declared_tramer_amount" in offer && Number(offer.declared_tramer_amount ?? 0) > 0 ? (
              <div>
                <span>Beyan edilen Tramer tutarı</span>
                <strong>{formatCurrency(Number(offer.declared_tramer_amount))}</strong>
              </div>
            ) : null}
          </div>
        </section>

        <section className="panel">
          <div className="panel-heading panel-heading--stacked">
            <div>
              <h3>Araç Geçmiş Özeti</h3>
              <p className="section-subtitle">Araç için oluşan değerlendirme özeti aşağıda gösterilir.</p>
            </div>
          </div>
          <ul className="timeline-list">
            <li>Kaza kaydı: {offer.accident_record ? "Var" : "Yok"}</li>
            <li>Ağır hasar: {offer.heavy_damage ? "Var" : "Yok"}</li>
            <li>Gümrük problemi: {offer.customs_problem ? "Var" : "Yok"}</li>
          </ul>
        </section>
      </div>

      <section className="panel">
        <div className="panel-heading panel-heading--stacked">
          <div>
            <h3>{offer.expected_selling_price ? "Beklenen Fiyat ve Açıklama" : "Beklenen Fiyatınızı Girin"}</h3>
            {!offer.expected_selling_price ? (
              <p className="section-subtitle">Beklediğiniz satış fiyatını girerek ön teklif akışına devam edebilirsiniz.</p>
            ) : (
              <p className="section-subtitle">Araç değerlendirmesinin güncel durumu aşağıda paylaşılır.</p>
            )}
          </div>
        </div>
        {!offer.expected_selling_price ? (
          <div className="action-grid" style={{ marginBottom: 20 }}>
            <input
              className="inline-input"
              inputMode="numeric"
              placeholder="Beklenen fiyat"
              value={expectedPriceInput}
              onChange={(e) => setExpectedPriceInput(formatIntegerInput(e.target.value))}
            />
            <button className="primary-button" type="button" onClick={handleExpectedPriceSave} disabled={isSavingExpectedPrice || !expectedPriceInput}>
              {isSavingExpectedPrice ? "Kaydediliyor..." : "Beklenen Fiyatı Kaydet"}
            </button>
          </div>
        ) : null}
        <div className="panel-heading panel-heading--stacked" style={{ paddingTop: 0 }}>
          <div>
            <h3>Açıklama</h3>
            <p className="section-subtitle">Araç değerlendirmesinin güncel durumu aşağıda paylaşılır.</p>
          </div>
        </div>
        <div className={`decision-banner ${offer.requires_manager_approval ? "decision-banner--warning" : "decision-banner--success"}`}>
          <strong>{offer.requires_manager_approval ? "Yönetici onayı gerekiyor" : "Ön teklif hazır"}</strong>
          <span>{offer.approval_reason || "Teklif müşteriye sunulabilir."}</span>
        </div>
        {!offer.requires_manager_approval ? (
          <div className="action-grid" style={{ marginTop: 16 }}>
            <button className="primary-button" type="button" onClick={() => navigate("/customer/negotiation")}>
              Pazarlık Ekranına Geç
            </button>
          </div>
        ) : null}
      </section>

      <section className="panel">
        <div className="panel-heading panel-heading--stacked">
          <div>
            <h3>Fiyat Nasıl Hesaplandı?</h3>
            <p className="section-subtitle">Ön alım teklifi; piyasa değeri, müşteri beklentisi, hasar durumu ve beyan edilen Tramer tutarı dikkate alınarak hesaplanır.</p>
          </div>
        </div>
        <ul className="timeline-list">
          {visibleDiscounts.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </section>
    </section>
  );
}
