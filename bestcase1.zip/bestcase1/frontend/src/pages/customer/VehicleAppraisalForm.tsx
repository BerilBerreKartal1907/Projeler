import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import { createAppraisalRequest, getAppraisalCooldownStatus, listCustomerAppraisals } from "../../api/appraisalApi";
import { setLatestAppraisalId } from "../../utils/appraisalDraft";
import { formatIntegerInput, parseIntegerInput } from "../../utils/format";
import { getErrorMessage } from "../../utils/http";
import { VEHICLE_CATALOG } from "../../utils/vehicleCatalog";

export function VehicleAppraisalForm() {
  const navigate = useNavigate();
  const currentYear = new Date().getFullYear();
  const brands = Object.keys(VEHICLE_CATALOG);
  const [form, setForm] = useState({
    brand: "Kia",
    model: "Sportage",
    package: "Premium Paket",
    year: String(currentYear),
    mileage: "",
    plate: "",
    category: VEHICLE_CATALOG.Kia.category,
    declaredTramerAmount: ""
  });
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isBootstrapping, setIsBootstrapping] = useState(true);
  const [cooldown, setCooldown] = useState<{ canCreate: boolean; remainingMs: number; message: string } | null>(null);

  useEffect(() => {
    async function bootstrap() {
      try {
        const [cooldownStatus, appraisals] = await Promise.all([
          getAppraisalCooldownStatus(),
          listCustomerAppraisals()
        ]);

        setCooldown(cooldownStatus);

        if (!cooldownStatus.canCreate && appraisals.length > 0) {
          const latestAppraisal = appraisals[0];
          setLatestAppraisalId(latestAppraisal.id);

          if (latestAppraisal.status === "draft") {
            navigate(`/customer/appraisal/${latestAppraisal.id}/damage`, { replace: true });
            return;
          }

          navigate(`/customer/appraisal/${latestAppraisal.id}/offer`, { replace: true });
          return;
        }
      } catch {
        // Form yine de kullanılabilir kalsın.
      } finally {
        setIsBootstrapping(false);
      }
    }

    bootstrap();
  }, [navigate]);

  useEffect(() => {
    if (!cooldown || cooldown.canCreate || cooldown.remainingMs <= 0) {
      return;
    }

    const interval = window.setInterval(() => {
      setCooldown((current) => {
        if (!current) return current;
        const nextRemainingMs = Math.max(0, current.remainingMs - 1000);
        if (nextRemainingMs <= 0) {
          return { canCreate: true, remainingMs: 0, message: "" };
        }

        const totalMinutes = Math.max(0, Math.ceil(nextRemainingMs / 60000));
        const days = Math.floor(totalMinutes / (60 * 24));
        const hours = Math.floor((totalMinutes % (60 * 24)) / 60);
        const minutes = totalMinutes % 60;

        return {
          canCreate: false,
          remainingMs: nextRemainingMs,
          message: `Haftada bir ekspertiz ve pazarlık yapabilirsiniz. Kalan süre: ${days} gün ${hours} saat ${minutes} dakika.`
        };
      });
    }, 1000);

    return () => window.clearInterval(interval);
  }, [cooldown]);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      if (cooldown && !cooldown.canCreate) {
        setError(cooldown.message);
        return;
      }

      const year = Number(form.year);
      const mileage = parseIntegerInput(form.mileage);
      const declaredTramerAmount = parseIntegerInput(form.declaredTramerAmount);

      if (year < 1980 || year > currentYear + 1) {
        setError(`Araç yılı 1980 ile ${currentYear + 1} arasında olmalıdır.`);
        return;
      }

      if (mileage < 0) {
        setError("Kilometre değeri negatif olamaz.");
        return;
      }

      const result = await createAppraisalRequest({
        brand: form.brand,
        model: form.model,
        package: form.package,
        year,
        mileage,
        plate: form.plate || undefined,
        category: form.category,
        declaredTramerAmount: form.declaredTramerAmount ? declaredTramerAmount : undefined
      });

      setLatestAppraisalId(result.appraisalId);
      navigate(`/customer/appraisal/${result.appraisalId}/damage`);
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Ekspertiz başlatılırken bir hata oluştu."));
    } finally {
      setIsSubmitting(false);
    }
  }

  if (isBootstrapping) {
    return <div className="page-state">Ekspertiz kaydınız kontrol ediliyor...</div>;
  }

  return (
    <section className="dashboard-page">
      <section className="panel form-panel">
        <div className="panel-heading panel-heading--stacked">
          <div>
            <h3>Araç Ekspertizi Başlat</h3>
            <p className="section-subtitle">Araç bilgilerini girin, ardından hasar işaretleme ekranına geçin.</p>
          </div>
        </div>

        {cooldown && !cooldown.canCreate ? (
          <div className="decision-banner decision-banner--warning" style={{ marginBottom: 20 }}>
            <strong>Bu hafta yeni ekspertiz başlatılamaz</strong>
            <span>{cooldown.message}</span>
          </div>
        ) : null}

        <form className="appraisal-form-grid" onSubmit={handleSubmit}>
          <label>
            <span>Marka</span>
            <select
              value={form.brand}
              onChange={(e) => {
                const nextBrand = e.target.value;
                const firstModel = VEHICLE_CATALOG[nextBrand].models[0];
                setForm((current) => ({
                  ...current,
                  brand: nextBrand,
                  model: firstModel,
                  category: VEHICLE_CATALOG[nextBrand].category
                }));
              }}
            >
              {brands.map((brand) => <option key={brand} value={brand}>{brand}</option>)}
            </select>
          </label>
          <label>
            <span>Model</span>
            <select value={form.model} onChange={(e) => setForm({ ...form, model: e.target.value })}>
              {VEHICLE_CATALOG[form.brand].models.map((model) => <option key={model} value={model}>{model}</option>)}
            </select>
          </label>
          <label>
            <span>Paket</span>
            <select value={form.package} onChange={(e) => setForm({ ...form, package: e.target.value })}>
              <option value="Premium Paket">Premium Paket</option>
              <option value="Medium Paket">Medium Paket</option>
              <option value="Economy Paket">Economy Paket</option>
            </select>
          </label>
          <label>
            <span>Yıl</span>
            <input
              inputMode="numeric"
              value={form.year}
              onChange={(e) => setForm({ ...form, year: e.target.value.replace(/\D/g, "").slice(0, 4) })}
              placeholder="Örn. 2023"
              required
            />
          </label>
          <label>
            <span>Kilometre</span>
            <input
              inputMode="numeric"
              value={form.mileage}
              onChange={(e) => setForm({ ...form, mileage: formatIntegerInput(e.target.value) })}
              required
            />
          </label>
          <label>
            <span>Plaka</span>
            <input value={form.plate} onChange={(e) => setForm({ ...form, plate: e.target.value })} />
          </label>
          <label>
            <span>Kategori</span>
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
              <option value="sedan">Sedan</option>
              <option value="hatchback">Hatchback</option>
              <option value="suv">SUV</option>
              <option value="pickup">Pickup</option>
            </select>
          </label>
          <label>
            <span>Tramer Tutarı</span>
            <input
              inputMode="numeric"
              value={form.declaredTramerAmount}
              onChange={(e) => setForm({ ...form, declaredTramerAmount: formatIntegerInput(e.target.value) })}
            />
          </label>

          {error ? <p className="form-error form-error--wide">{error}</p> : null}

          <div className="form-actions">
            <button className="primary-button" type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Oluşturuluyor..." : "Devam Et"}
            </button>
          </div>
        </form>
      </section>
    </section>
  );
}
