import { useEffect, useState } from "react";

import {
  downloadSummaryExcel,
  downloadSummaryCsv,
  getSalesReport,
  getServiceReport,
  getSummaryReport,
  type SalesReportRow,
  type ServiceReportRow,
  type SummaryReport,
  type ReportFilters
} from "../../api/reportApi";
import { getErrorMessage } from "../../utils/http";
import { getServiceStatusLabel, getServiceTypeLabel } from "../../utils/labels";
import { VEHICLE_CATALOG } from "../../utils/vehicleCatalog";

export function ReportsPage() {
  const brands = Object.keys(VEHICLE_CATALOG);
  const [summary, setSummary] = useState<SummaryReport | null>(null);
  const [sales, setSales] = useState<SalesReportRow[]>([]);
  const [service, setService] = useState<ServiceReportRow[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState<ReportFilters>({
    brand: "",
    serviceType: "",
    dateFrom: "",
    dateTo: ""
  });

  async function loadReports(activeFilters: ReportFilters) {
    setError(null);

    try {
      const [summaryResponse, salesResponse, serviceResponse] = await Promise.all([
        getSummaryReport(activeFilters),
        getSalesReport(activeFilters),
        getServiceReport(activeFilters)
      ]);
      setSummary(summaryResponse);
      setSales(salesResponse);
      setService(serviceResponse);
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Rapor verileri alınamadı."));
    }
  }

  useEffect(() => {
    void loadReports(filters);
  }, []);

  function getVehicleStatusLabel(status: string) {
    const statusMap: Record<string, string> = {
      active: "Aktif",
      in_appraisal: "Ekspertizde",
      for_sale: "Satışta",
      sold: "Satıldı",
      acquired: "Bayi tarafından alındı",
      in_service: "Serviste",
      cancelled: "İptal edildi",
      under_review: "İncelemede"
    };

    return statusMap[status] ?? status;
  }

  function handleFilterSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    void loadReports(filters);
  }

  function handleClearFilters() {
    const clearedFilters = {
      brand: "",
      serviceType: "",
      dateFrom: "",
      dateTo: ""
    };
    setFilters(clearedFilters);
    void loadReports(clearedFilters);
  }

  async function handleExport() {
    try {
      const blob = await downloadSummaryCsv(filters);
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "smart-appraisal-summary.csv";
      link.click();
      URL.revokeObjectURL(url);
    } catch (requestError) {
      setError(getErrorMessage(requestError, "CSV dışa aktarma başarısız oldu."));
    }
  }

  async function handleExcelExport() {
    try {
      const blob = await downloadSummaryExcel(filters);
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "smart-appraisal-summary.xlsx";
      link.click();
      URL.revokeObjectURL(url);
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Excel dışa aktarma başarısız oldu."));
    }
  }

  return (
    <section className="dashboard-page">
      <div className="stats-grid">
        <div className="stat-card">
          <span>Toplam Satış Adedi</span>
          <strong>{Number(summary?.totalSalesCount ?? 0)}</strong>
        </div>
        <div className="stat-card stat-card--success">
          <span>Toplam Satış Geliri</span>
          <strong>₺{Number(summary?.totalSalesRevenue ?? 0).toLocaleString("tr-TR")}</strong>
        </div>
        <div className="stat-card stat-card--danger">
          <span>Bayi Alım Gideri</span>
          <strong>-₺{Number(summary?.totalAcquisitionExpense ?? 0).toLocaleString("tr-TR")}</strong>
        </div>
        <div className="stat-card">
          <span>Toplam Gelir</span>
          <strong>₺{Number(summary?.totalRevenue ?? 0).toLocaleString("tr-TR")}</strong>
        </div>
        <div className="stat-card stat-card--success">
          <span>Servis Geliri</span>
          <strong>₺{Number(summary?.totalServiceRevenue ?? 0).toLocaleString("tr-TR")}</strong>
        </div>
        <div className="stat-card stat-card--warning">
          <span>Ortalama Kâr</span>
          <strong>₺{Number(summary?.averageProfit ?? 0).toLocaleString("tr-TR")}</strong>
        </div>
        <div className="stat-card">
          <span>Servis Doluluk</span>
          <strong>%{Number(summary?.serviceOccupancyRate ?? 0).toLocaleString("tr-TR")}</strong>
        </div>
        <div className="stat-card stat-card--warning">
          <span>Aktif Pazarlık</span>
          <strong>{Number(summary?.activeNegotiations ?? 0)}</strong>
        </div>
        <div className="stat-card stat-card--danger">
          <span>Bekleyen Onay</span>
          <strong>{Number(summary?.pendingApprovals ?? 0)}</strong>
        </div>
      </div>

      <section className="panel">
        <div className="panel-heading panel-heading--stacked">
          <div>
            <h3>Öne Çıkan Teknik Ekip Özeti</h3>
            <p className="section-subtitle">Seçili filtrelere göre en aktif teknisyen</p>
          </div>
        </div>
        <div className="offer-summary">
          <div>
            <span>Teknisyen</span>
            <strong>{summary?.mostActiveTechnicianName ?? "-"}</strong>
          </div>
          <div>
            <span>Tamamlanan İş</span>
            <strong>{Number(summary?.mostActiveTechnicianJobs ?? 0)}</strong>
          </div>
        </div>
      </section>

      <section className="panel form-panel">
        <div className="panel-heading panel-heading--stacked">
          <div>
            <h3>Raporlar</h3>
            <p className="section-subtitle">Önce filtreleyin, ardından satış ve servis raporlarını aynı kapsamda inceleyip dışa aktarın.</p>
          </div>
        </div>
        {error ? <p className="form-error">{error}</p> : null}

        <div className="panel-heading panel-heading--stacked" style={{ paddingTop: 0 }}>
          <div>
            <h3>Filtreleme</h3>
            <p className="section-subtitle">Marka filtresi satış ve servis kayıtlarını birlikte daraltır. Servis tipi yalnızca servis verisini etkiler. Tarih aralığı tüm rapora uygulanır.</p>
          </div>
        </div>
        <form className="appraisal-form-grid" onSubmit={handleFilterSubmit}>
          <label>
            <span>Marka</span>
            <select
              value={filters.brand ?? ""}
              onChange={(event) => setFilters((current) => ({ ...current, brand: event.target.value }))}
            >
              <option value="">Tüm markalar</option>
              {brands.map((brand) => (
                <option key={brand} value={brand}>{brand}</option>
              ))}
            </select>
          </label>
          <label>
            <span>Servis tipi</span>
            <select
              value={filters.serviceType ?? ""}
              onChange={(event) => setFilters((current) => ({ ...current, serviceType: event.target.value }))}
            >
              <option value="">Tümü</option>
              <option value="maintenance">Periyodik bakım</option>
              <option value="check_up">Check-up</option>
              <option value="accident_repair">Hasar onarımı</option>
              <option value="modification">Modifikasyon</option>
            </select>
          </label>
          <label>
            <span>Tarih başlangıcı</span>
            <input
              type="date"
              value={filters.dateFrom ?? ""}
              onChange={(event) => setFilters((current) => ({ ...current, dateFrom: event.target.value }))}
            />
          </label>
          <label>
            <span>Tarih bitişi</span>
            <input
              type="date"
              value={filters.dateTo ?? ""}
              onChange={(event) => setFilters((current) => ({ ...current, dateTo: event.target.value }))}
            />
          </label>
          <div className="form-actions">
            <button className="primary-button" type="submit">
              Filtreleri Uygula
            </button>
            <button className="ghost-button" type="button" onClick={handleClearFilters}>
              Filtreleri Temizle
            </button>
          </div>
        </form>

        <div className="panel-heading" style={{ marginTop: 24 }}>
          <h3>Satış Raporu</h3>
          <span>Canlı veri</span>
        </div>
        <div className="table-wrap report-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>İşlem</th>
                <th>Araç</th>
                <th>Yıl</th>
                <th>Tutar</th>
                <th>Durum</th>
              </tr>
            </thead>
            <tbody>
              {sales.map((row) => (
                <tr key={row.id}>
                  <td>{row.transaction_type}</td>
                  <td>{row.brand} {row.model}</td>
                  <td>{row.year}</td>
                  <td>₺{Number(row.report_price ?? 0).toLocaleString("tr-TR")}</td>
                  <td>{getVehicleStatusLabel(row.status)}</td>
                </tr>
              ))}
              {!sales.length ? (
                <tr>
                  <td colSpan={5}>
                    Gösterilecek satış verisi bulunmuyor.
                    {(filters.brand || filters.dateFrom || filters.dateTo) ? " Filtreleri temizleyip tekrar deneyin." : ""}
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>

        <div className="panel-heading" style={{ marginTop: 24 }}>
          <h3>Servis Raporu</h3>
          <span>Canlı veri</span>
        </div>
        <div className="table-wrap report-table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Müşteri</th>
                <th>Araç</th>
                <th>Servis Tipi</th>
                <th>Durum</th>
              </tr>
            </thead>
            <tbody>
              {service.map((row) => (
                <tr key={row.id}>
                  <td>{row.customer_name}</td>
                  <td>{row.brand} {row.model}</td>
                  <td>{getServiceTypeLabel(row.service_type)}</td>
                  <td>{getServiceStatusLabel(row.status)}</td>
                </tr>
              ))}
              {!service.length ? (
                <tr>
                  <td colSpan={4}>
                    Gösterilecek servis verisi bulunmuyor.
                    {(filters.brand || filters.serviceType || filters.dateFrom || filters.dateTo) ? " Filtreleri temizleyip tekrar deneyin." : ""}
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>

        <div className="panel-heading" style={{ marginTop: 24 }}>
          <div>
            <h3>Dışa Aktarma</h3>
            <p className="section-subtitle">Ekranda gördüğünüz filtrelenmiş özet, satış ve servis verilerini dışa aktarın.</p>
          </div>
          <button className="primary-button" type="button" onClick={handleExport}>
            CSV Dışa Aktar
          </button>
          <button className="ghost-button" type="button" onClick={handleExcelExport}>
            Excel Dışa Aktar
          </button>
        </div>
      </section>
    </section>
  );
}
