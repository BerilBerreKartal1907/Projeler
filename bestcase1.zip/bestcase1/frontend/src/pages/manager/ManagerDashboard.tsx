import { useEffect, useState } from "react";

import { getDashboardMetrics } from "../../api/dashboardApi";
import { PageSection } from "../../components/common/PageSection";
import { StatCard } from "../../components/common/StatCard";
import { getErrorMessage } from "../../utils/http";

export function ManagerDashboard() {
  const [metrics, setMetrics] = useState({
    pendingAppraisalApprovals: 0,
    pendingNegotiations: 0,
    totalSalesRevenue: 0,
    criticalSafetyCases: 0,
    averageProfit: 0,
    serviceOccupancy: 0
  });
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getDashboardMetrics("manager")
      .then((data) => setMetrics(data as typeof metrics))
      .catch((requestError) => setError(getErrorMessage(requestError, "Yönetici paneli verileri alınamadı.")));
  }, []);

  return (
    <section className="dashboard-page">
      <div className="hero-panel">
        <div>
          <p className="eyebrow">Yönetim Özeti</p>
          <h1>Fiyat, risk ve kapasite aynı ekranda</h1>
          <p>Ekspertiz onayları, pazarlık limitleri ve servis güvenlik vakaları tek bakışta yönetilir.</p>
        </div>
        <div className="hero-badge">Kural Motoru Aktif</div>
      </div>
      {error ? <p className="form-error">{error}</p> : null}

      <div className="stats-grid">
        <StatCard label="Bekleyen Ekspertiz Onayı" value={String(metrics.pendingAppraisalApprovals)} tone="warning" />
        <StatCard label="Bekleyen Pazarlık" value={String(metrics.pendingNegotiations)} />
        <StatCard label="Toplam Satış Geliri" value={`₺${Number(metrics.totalSalesRevenue).toLocaleString("tr-TR")}`} tone="success" />
        <StatCard label="Ortalama Kâr" value={`₺${Number(metrics.averageProfit).toLocaleString("tr-TR")}`} />
        <StatCard label="Servis Doluluk" value={`%${Number(metrics.serviceOccupancy).toLocaleString("tr-TR")}`} />
        <StatCard label="Kritik Güvenlik" value={String(metrics.criticalSafetyCases)} tone="danger" />
      </div>

      <div className="content-grid">
        <PageSection title="Onay Gerekçeleri" subtitle="Kural tabanlı yönlendirme nedenleri">
          <ul className="timeline-list">
            <li>200.000 km üzeri 2 araç otomatik olarak yönetime taşındı.</li>
            <li>TRAMER kaza kaydı bulunan 3 talepte ek iskonto uygulandı.</li>
            <li>Müşteri beklentisi ile teklif farkı %20 üstüne çıkan 2 pazarlık durduruldu.</li>
          </ul>
        </PageSection>
      </div>
    </section>
  );
}
