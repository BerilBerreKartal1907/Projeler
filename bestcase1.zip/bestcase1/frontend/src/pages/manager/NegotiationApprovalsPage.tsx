import { useEffect, useState } from "react";

import {
  approveNegotiationByManager,
  listNegotiations,
  rejectNegotiation,
  updateNegotiationSettings,
  type NegotiationListRow
} from "../../api/negotiationApi";
import { getErrorMessage } from "../../utils/http";

export function NegotiationApprovalsPage() {
  const [rows, setRows] = useState<NegotiationListRow[]>([]);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    try {
      setError(null);
      const data = await listNegotiations();
      setRows(data.filter((row) => row.status === "pending_manager_review"));
    } catch (requestError) {
      setRows([]);
      setError(getErrorMessage(requestError, "Yönetici incelemesi gereken pazarlıklar alınamadı."));
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  async function raiseLimit(row: NegotiationListRow) {
    try {
      setError(null);
      await updateNegotiationSettings(row.id, {
        maxAuthorizedOffer: Number(row.max_authorized_offer) + 20000,
        incrementAmount: Number(row.increment_amount),
        autoNegotiationEnabled: true
      });
      await refresh();
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Pazarlık limiti artırılırken bir sorun oluştu."));
    }
  }

  async function approveNegotiation(id: number) {
    try {
      setError(null);
      await approveNegotiationByManager(id, "Yetkili yönetici pazarlığı onayladı.");
      await refresh();
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Pazarlık onaylanırken bir sorun oluştu."));
    }
  }

  async function cancelNegotiation(id: number) {
    try {
      setError(null);
      await rejectNegotiation(id, "Yetkili yönetici pazarlığı iptal etti.");
      await refresh();
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Pazarlık iptal edilirken bir sorun oluştu."));
    }
  }

  return (
    <section className="dashboard-page">
      <section className="panel">
        <div className="panel-heading">
          <div>
            <h3>Pazarlık Onayları</h3>
            <p className="section-subtitle">Üst limit aşan kayıtlar için yönetici karar ekranı</p>
          </div>
        </div>
        {error ? <p className="form-error">{error}</p> : null}
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Müşteri</th>
                <th>Araç</th>
                <th>Müşteri Beklentisi</th>
                <th>Max Yetki</th>
                <th>Artış</th>
                <th>Aksiyon</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  <td>{row.customer_name}</td>
                  <td>{row.brand} {row.model}</td>
                  <td>{row.customer_expected_price ? `₺${Number(row.customer_expected_price).toLocaleString("tr-TR")}` : "-"}</td>
                  <td>₺{Number(row.max_authorized_offer).toLocaleString("tr-TR")}</td>
                  <td>₺{Number(row.increment_amount).toLocaleString("tr-TR")}</td>
                  <td>
                    <div className="table-actions">
                      <button className="primary-button" type="button" onClick={() => approveNegotiation(row.id)}>
                        Onayla
                      </button>
                      <button className="primary-button" type="button" onClick={() => raiseLimit(row)}>
                        Limiti Artır
                      </button>
                      <button className="danger-button" type="button" onClick={() => cancelNegotiation(row.id)}>
                        İptal Et
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {rows.length === 0 ? (
                <tr>
                  <td colSpan={6}>Bekleyen pazarlık onayı bulunmuyor.</td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
