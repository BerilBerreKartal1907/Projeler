import { useEffect, useState } from "react";

import {
  approveAppraisal,
  listAppraisals,
  rejectAppraisal,
  reviseAppraisalPrice
} from "../../api/appraisalManagementApi";
import { getAppraisalStatusLabel } from "../../utils/labels";

type AppraisalRow = Awaited<ReturnType<typeof listAppraisals>>[number];

export function AppraisalApprovalsPage() {
  const [rows, setRows] = useState<AppraisalRow[]>([]);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    try {
      const items = await listAppraisals();
      setRows(items.filter((row) => row.requires_manager_approval));
    } catch {
      setError("Onay bekleyen ekspertizler alınamadı.");
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  async function handleApprove(id: number) {
    await approveAppraisal(id, "Yönetici onayı verildi.");
    refresh();
  }

  async function handleReject(id: number) {
    await rejectAppraisal(id, "Teklif riskli bulundu.");
    refresh();
  }

  async function handleRevise(id: number, currentValue: string | null) {
    const current = currentValue ? Number(currentValue) : 0;
    await reviseAppraisalPrice(id, current + 15000, "Fiyat yönetici tarafından revize edildi.");
    refresh();
  }

  if (error) {
    return <div className="page-state">{error}</div>;
  }

  return (
    <section className="dashboard-page">
      <section className="panel">
        <div className="panel-heading">
          <div>
            <h3>Ekspertiz Onayları</h3>
            <p className="section-subtitle">Kurala takılan talepler için yönetici aksiyon ekranı</p>
          </div>
        </div>

        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Müşteri</th>
                <th>Araç</th>
                <th>Hasar %</th>
                <th>Teklif</th>
                <th>Durum</th>
                <th>Aksiyonlar</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  <td>{row.customer_name}</td>
                  <td>{row.brand} {row.model}</td>
                  <td>%{row.damage_percentage}</td>
                  <td>{row.calculated_offer ? `₺${Number(row.calculated_offer).toLocaleString("tr-TR")}` : "-"}</td>
                  <td><span className="status-pill status-pill--warning">{getAppraisalStatusLabel(row.status)}</span></td>
                  <td>
                    <div className="action-grid action-grid--tight">
                      <button className="primary-button" type="button" onClick={() => handleApprove(row.id)}>Onayla</button>
                      <button className="ghost-button" type="button" onClick={() => handleRevise(row.id, row.calculated_offer)}>Revize Et</button>
                      <button className="danger-button" type="button" onClick={() => handleReject(row.id)}>Reddet</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
