import { useEffect, useState } from "react";

import { listAppointments, type ServiceAppointmentRow } from "../../api/serviceApi";
import { getErrorMessage } from "../../utils/http";
import { getServiceStatusLabel, getServiceTypeLabel } from "../../utils/labels";

export function TechnicianAppointmentsPage() {
  const [rows, setRows] = useState<ServiceAppointmentRow[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    listAppointments().then(setRows).catch((requestError) => setError(getErrorMessage(requestError, "Randevular alınamadı.")));
  }, []);

  return (
    <section className="dashboard-page">
      <section className="panel">
        <div className="panel-heading">
          <div>
            <h3>Atanan Randevularım</h3>
            <p className="section-subtitle">Teknisyen yalnızca kendisine atanan servis randevularını görür.</p>
          </div>
        </div>
        {error ? <p className="form-error">{error}</p> : null}
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Müşteri</th>
                <th>Araç</th>
                <th>Servis Tipi</th>
                <th>Tarih</th>
                <th>Durum</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  <td>#{row.id}</td>
                  <td>{row.customer_name}</td>
                  <td>{row.brand} {row.model}</td>
                  <td>{getServiceTypeLabel(row.service_type)}</td>
                  <td>{new Date(row.appointment_datetime).toLocaleString("tr-TR")}</td>
                  <td>{getServiceStatusLabel(row.status)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
