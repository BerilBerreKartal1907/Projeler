import { useEffect, useState } from "react";

import { getDashboardMetrics } from "../../api/dashboardApi";
import { StatCard } from "../../components/common/StatCard";
import { getErrorMessage } from "../../utils/http";

export function TechnicianDashboard() {
  const [metrics, setMetrics] = useState({
    todaysAppointments: 0,
    assignedJobs: 0,
    checkupsInProgress: 0,
    waitingCustomerApproval: 0,
    completedJobs: 0
  });
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getDashboardMetrics("technician")
      .then((data) => setMetrics(data as typeof metrics))
      .catch((requestError) => setError(getErrorMessage(requestError, "Teknisyen paneli verileri alınamadı.")));
  }, []);

  return (
    <section className="dashboard-page">
      <div className="stats-grid">
        <StatCard label="Bugünkü Randevu" value={String(metrics.todaysAppointments)} />
        <StatCard label="Atanmış İş" value={String(metrics.assignedJobs)} tone="warning" />
        <StatCard label="Check-up Sürecinde" value={String(metrics.checkupsInProgress)} />
        <StatCard label="Onay Bekleyen" value={String(metrics.waitingCustomerApproval)} tone="danger" />
        <StatCard label="Tamamlanan İş" value={String(metrics.completedJobs)} tone="success" />
      </div>
      {error ? <p className="form-error">{error}</p> : null}
    </section>
  );
}
