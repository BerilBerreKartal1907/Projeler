import { useEffect, useState } from "react";

import {
  completeApprovedOperations,
  listAppointments,
  listOperations,
  type ServiceAppointmentRow
} from "../../api/serviceApi";
import { getErrorMessage } from "../../utils/http";
import { getServiceStatusLabel } from "../../utils/labels";

type CompletableAppointment = ServiceAppointmentRow & {
  approvalSummary: string;
  canComplete: boolean;
};

export function OperationCompletePage() {
  const [appointments, setAppointments] = useState<CompletableAppointment[]>([]);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadCompletableAppointments() {
      const rows = await listAppointments();
      const appointmentsWithOperations = await Promise.all(
        rows.map(async (appointment) => ({
          appointment,
          operations: await listOperations(appointment.id)
        }))
      );

      setAppointments(
        appointmentsWithOperations
          .filter(({ appointment, operations }) => operations.length > 0 && !["completed", "cancelled"].includes(appointment.status))
          .map(({ appointment, operations }) => {
            const pendingCount = operations.filter((operation) => operation.customer_approval_status === "pending").length;
            const approvedCount = operations.filter((operation) => operation.customer_approval_status === "approved").length;
            const rejectedCount = operations.filter((operation) => operation.customer_approval_status === "rejected").length;
            const managerPendingCount = operations.filter(
              (operation) => operation.is_critical_safety && operation.manager_review_status === "pending"
            ).length;
            const canComplete = pendingCount === 0 && managerPendingCount === 0 && operations.length > 0;
            const approvalSummary = pendingCount > 0
              ? `${pendingCount} işlem müşteri onayı bekliyor`
              : managerPendingCount > 0
                ? `${managerPendingCount} kritik işlem yönetici incelemesinde`
              : rejectedCount > 0
                ? `${approvedCount} işlem onaylandı, ${rejectedCount} işlem reddedildi`
                : "Müşteri onayladı";

            return {
              ...appointment,
              approvalSummary,
              canComplete
            };
          })
      );
    }

    loadCompletableAppointments().catch((requestError) => setError(getErrorMessage(requestError, "Randevular alınamadı.")));
  }, []);

  async function handleComplete(id: number) {
    try {
      const result = await completeApprovedOperations(id);
      setMessage(`Randevu #${result.appointmentId} tamamlandı.`);
      setError(null);
      setAppointments((current) => current.filter((appointment) => appointment.id !== id));
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Henüz onaylanmamış veya oluşturulmamış operasyonlar olduğu için tamamlama yapılamadı."));
    }
  }

  return (
    <section className="dashboard-page">
      <section className="panel">
        <div className="panel-heading">
          <div>
            <h3>Operasyon Tamamlama</h3>
            <p className="section-subtitle">Teknisyen yalnızca onaylı operasyonları tamamlayabilir.</p>
          </div>
        </div>
        {message ? <p className="form-success">{message}</p> : null}
        {error ? <p className="form-error">{error}</p> : null}
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Randevu</th>
                <th>Araç</th>
                <th>Durum</th>
                <th>Müşteri Onayı</th>
                <th>Aksiyon</th>
              </tr>
            </thead>
            <tbody>
              {appointments.map((appointment) => (
                <tr key={appointment.id}>
                  <td>#{appointment.id}</td>
                  <td>{appointment.brand} {appointment.model}</td>
                  <td>{getServiceStatusLabel(appointment.status)}</td>
                  <td>{appointment.approvalSummary}</td>
                  <td>
                    <button
                      className="primary-button"
                      type="button"
                      onClick={() => handleComplete(appointment.id)}
                      disabled={!appointment.canComplete}
                    >
                      Tamamla
                    </button>
                  </td>
                </tr>
              ))}
              {!appointments.length ? (
                <tr>
                  <td colSpan={5}>Tamamlanmaya uygun servis operasyonu bulunan randevu yok.</td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
