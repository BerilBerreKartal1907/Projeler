import { useEffect, useState } from "react";

import { createOperation, listAppointments, type ServiceAppointmentRow } from "../../api/serviceApi";
import { formatIntegerInput, parseIntegerInput } from "../../utils/format";
import { getErrorMessage } from "../../utils/http";
import { getOperationTypeLabel, getServiceStatusLabel, getServiceTypeLabel, operationTypeLabels } from "../../utils/labels";

export function ServiceOperationCreatePage() {
  const [appointments, setAppointments] = useState<ServiceAppointmentRow[]>([]);
  const [form, setForm] = useState({
    appointmentId: "",
    operationName: "",
    operationType: "checkup_repair",
    partPrice: "",
    laborPrice: "",
    isCriticalSafety: false,
    note: ""
  });
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const creatableAppointments = appointments.filter((appointment) => !["completed", "cancelled"].includes(appointment.status));

  useEffect(() => {
    listAppointments()
      .then(setAppointments)
      .catch((requestError) => setError(getErrorMessage(requestError, "Randevular alınamadı.")));
  }, []);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setMessage(null);

    try {
      await createOperation(Number(form.appointmentId), {
        operationName: form.operationName,
        operationType: form.operationType,
        partPrice: form.partPrice ? parseIntegerInput(form.partPrice) : 0,
        laborPrice: form.laborPrice ? parseIntegerInput(form.laborPrice) : 0,
        isCriticalSafety: form.isCriticalSafety,
        note: form.note
      });
      setMessage("Operasyon oluşturuldu ve müşteri onayına gönderildi.");
      setForm({
        appointmentId: "",
        operationName: "",
        operationType: "checkup_repair",
        partPrice: "",
        laborPrice: "",
        isCriticalSafety: false,
        note: ""
      });
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Operasyon oluşturulamadı."));
    }
  }

  return (
    <section className="dashboard-page">
      <section className="panel form-panel">
        <div className="panel-heading panel-heading--stacked">
          <div>
            <h3>Servis Operasyonu Oluştur</h3>
            <p className="section-subtitle">Teknisyen onay bekleyen iş kalemlerini sisteme girer.</p>
          </div>
        </div>
        <form className="appraisal-form-grid" onSubmit={handleSubmit}>
          <label>
            <span>Randevu</span>
            <select value={form.appointmentId} onChange={(e) => setForm({ ...form, appointmentId: e.target.value })} required>
              <option value="">Randevu seçin</option>
              {creatableAppointments.map((appointment) => (
                <option key={appointment.id} value={appointment.id}>
                  #{appointment.id} - {appointment.brand} {appointment.model} / {getServiceTypeLabel(appointment.service_type)} / {getServiceStatusLabel(appointment.status)}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>İşlem adı</span>
            <input value={form.operationName} onChange={(e) => setForm({ ...form, operationName: e.target.value })} required />
          </label>
          <label>
            <span>İşlem tipi</span>
            <select value={form.operationType} onChange={(e) => setForm({ ...form, operationType: e.target.value })} required>
              {Object.keys(operationTypeLabels).map((key) => (
                <option key={key} value={key}>
                  {getOperationTypeLabel(key)}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>Parça fiyatı</span>
            <input inputMode="numeric" value={form.partPrice} onChange={(e) => setForm({ ...form, partPrice: formatIntegerInput(e.target.value) })} />
          </label>
          <label>
            <span>İşçilik fiyatı</span>
            <input inputMode="numeric" value={form.laborPrice} onChange={(e) => setForm({ ...form, laborPrice: formatIntegerInput(e.target.value) })} />
          </label>
          <label className="checkbox-row">
            <input
              type="checkbox"
              checked={form.isCriticalSafety}
              onChange={(e) => setForm({ ...form, isCriticalSafety: e.target.checked })}
            />
            <span>Kritik güvenlik bildirimi {form.isCriticalSafety ? "açık" : "kapalı"}</span>
          </label>
          <label className="form-span-2">
            <span>Not</span>
            <input value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} />
          </label>

          {error ? <p className="form-error form-error--wide">{error}</p> : null}
          {message ? <p className="form-success form-error--wide">{message}</p> : null}
          {!creatableAppointments.length ? <p className="form-error form-error--wide">Operasyon eklenebilecek aktif randevu bulunmuyor.</p> : null}

          <div className="form-actions">
            <button className="primary-button" type="submit" disabled={!creatableAppointments.length}>Operasyon Ekle</button>
          </div>
        </form>
      </section>
    </section>
  );
}
