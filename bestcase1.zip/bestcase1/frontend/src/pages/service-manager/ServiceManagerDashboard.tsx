import { useEffect, useState } from "react";

import { getDashboardMetrics } from "../../api/dashboardApi";
import { StatCard } from "../../components/common/StatCard";
import { getErrorMessage } from "../../utils/http";

export function ServiceManagerDashboard() {
  const [metrics, setMetrics] = useState({
    dailyAppointmentCount: 0,
    occupancyRate: 0,
    jobsPerTechnician: 0,
    delayedJobs: 0,
    criticalRejectedOperations: 0
  });
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getDashboardMetrics("service-manager")
      .then((data) => setMetrics(data as typeof metrics))
      .catch((requestError) => setError(getErrorMessage(requestError, "Servis müdürü paneli verileri alınamadı.")));
  }, []);

  return (
    <section className="dashboard-page">
      <div className="stats-grid">
        <StatCard label="Günlük Randevu" value={String(metrics.dailyAppointmentCount)} />
        <StatCard label="Doluluk Oranı" value={`%${Number(metrics.occupancyRate).toLocaleString("tr-TR")}`} tone="warning" />
        <StatCard label="Teknisyen Başına İş" value={Number(metrics.jobsPerTechnician).toLocaleString("tr-TR")} />
        <StatCard label="Devam Eden İş" value={String(metrics.delayedJobs)} tone="danger" />
        <StatCard label="Kritik Red" value={String(metrics.criticalRejectedOperations)} />
      </div>
      {error ? <p className="form-error">{error}</p> : null}
    </section>
  );
}
