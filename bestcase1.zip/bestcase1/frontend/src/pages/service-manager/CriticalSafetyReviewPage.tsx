import { useEffect, useState } from "react";

import {
  listCriticalCases,
  reviewCriticalOperation,
  type CriticalCaseRow
} from "../../api/serviceApi";
import { getManagerReviewStatusLabel } from "../../utils/labels";

export function CriticalSafetyReviewPage() {
  const [rows, setRows] = useState<CriticalCaseRow[]>([]);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    try {
      const data = await listCriticalCases();
      setRows(data);
    } catch {
      setError("Kritik vakalar alınamadı.");
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  async function handleDecision(id: number, decision: string) {
    await reviewCriticalOperation(id, decision, "Servis müdürü incelemesi tamamlandı.");
    refresh();
  }

  if (error) return <div className="page-state">{error}</div>;

  return (
    <section className="dashboard-page">
      <section className="panel">
        <div className="panel-heading">
          <div>
            <h3>Kritik Güvenlik İncelemesi</h3>
            <p className="section-subtitle">Reddedilen kritik operasyonlar teslimden önce incelenir.</p>
          </div>
        </div>
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Müşteri</th>
                <th>Araç</th>
                <th>Operasyon</th>
                <th>Tutar</th>
                <th>Durum</th>
                <th>Aksiyonlar</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  <td>{row.customer_name}</td>
                  <td>{row.brand} {row.model}</td>
                  <td>{row.operation_name}</td>
                  <td>₺{Number(row.total_price).toLocaleString("tr-TR")}</td>
                  <td>{getManagerReviewStatusLabel(row.manager_review_status)}</td>
                  <td>
                    <div className="action-grid action-grid--tight">
                      <button className="primary-button" type="button" onClick={() => handleDecision(row.id, "approved")}>
                        Onayla
                      </button>
                      <button className="danger-button" type="button" onClick={() => handleDecision(row.id, "rejected")}>
                        Reddet
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
