import { useEffect, useState } from "react";

import { getTechnicianPerformance, type TechnicianPerformanceRow } from "../../api/serviceApi";
import { getErrorMessage } from "../../utils/http";

export function TechnicianPerformancePage() {
  const [rows, setRows] = useState<TechnicianPerformanceRow[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getTechnicianPerformance().then(setRows).catch((requestError) =>
      setError(getErrorMessage(requestError, "Teknisyen performans verileri alınamadı."))
    );
  }, []);

  return (
    <section className="dashboard-page">
      <section className="panel">
        <div className="panel-heading">
          <div>
            <h3>Teknisyen Performansı</h3>
            <p className="section-subtitle">Atanan iş, tamamlanan iş ve üretilen servis geliri görünümü</p>
          </div>
        </div>
        {error ? <p className="form-error">{error}</p> : null}
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Teknisyen</th>
                <th>Atanan İş</th>
                <th>Tamamlanan İş</th>
                <th>Toplam Gelir</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  <td>{row.full_name}</td>
                  <td>{row.assigned_jobs}</td>
                  <td>{row.completed_jobs}</td>
                  <td>₺{Number(row.total_revenue ?? 0).toLocaleString("tr-TR")}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
