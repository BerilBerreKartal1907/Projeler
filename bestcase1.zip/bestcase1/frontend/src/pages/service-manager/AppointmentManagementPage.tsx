import { useEffect, useMemo, useState } from "react";

import {
  assignTechnician,
  cancelAppointment,
  listAppointments,
  listServiceTechnicians,
  type ServiceAppointmentRow
} from "../../api/serviceApi";
import { getErrorMessage } from "../../utils/http";
import { getServiceStatusLabel, getServiceTypeLabel } from "../../utils/labels";

function canManageAppointment(status: string) {
  return !["completed", "cancelled"].includes(status);
}

export function AppointmentManagementPage() {
  const [appointments, setAppointments] = useState<ServiceAppointmentRow[]>([]);
  const [technicians, setTechnicians] = useState<Array<{ id: number; full_name: string }>>([]);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  async function refresh() {
    const [appointmentRows, technicianRows] = await Promise.all([listAppointments(), listServiceTechnicians()]);
    setAppointments(appointmentRows);
    setTechnicians(technicianRows);
  }

  useEffect(() => {
    refresh().catch((requestError) => setError(getErrorMessage(requestError, "Randevu verileri alınamadı.")));
  }, []);

  const defaultTechnicianByAppointment = useMemo(
    () =>
      appointments.reduce<Record<number, string>>((accumulator, appointment) => {
        accumulator[appointment.id] = appointment.technician_id ? String(appointment.technician_id) : "";
        return accumulator;
      }, {}),
    [appointments]
  );
  const [selectedTechnicians, setSelectedTechnicians] = useState<Record<number, string>>({});
  useEffect(() => {
    setSelectedTechnicians(defaultTechnicianByAppointment);
  }, [defaultTechnicianByAppointment]);

  async function handleAssign(appointmentId: number) {
    const technicianId = Number(selectedTechnicians[appointmentId]);

    if (!technicianId) {
      setError("Lütfen teknisyen seçin.");
      return;
    }

    try {
      await assignTechnician(appointmentId, technicianId);
      setMessage(`Randevu #${appointmentId} için teknisyen atandı.`);
      setError(null);
      await refresh();
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Teknisyen atanamadı."));
    }
  }

  async function handleCancel(appointmentId: number) {
    try {
      await cancelAppointment(appointmentId);
      setMessage(`Randevu #${appointmentId} iptal edildi.`);
      setError(null);
      await refresh();
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Randevu iptal edilemedi."));
    }
  }

  return (
    <section className="dashboard-page">
      <section className="panel">
        <div className="panel-heading">
          <div>
            <h3>Randevu Yönetimi</h3>
            <p className="section-subtitle">Teknisyen atama ve iptal işlemleri</p>
          </div>
        </div>
        {error ? <p className="form-error">{error}</p> : null}
        {message ? <p className="form-success">{message}</p> : null}
        <div className="table-wrap">
          <table className="data-table appointment-management-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Müşteri</th>
                <th>Araç</th>
                <th>Tip</th>
                <th>Tarih</th>
                <th>Durum</th>
                <th>Teknisyen</th>
                <th>Aksiyon</th>
              </tr>
            </thead>
            <tbody>
              {appointments.map((row) => (
                <tr key={row.id}>
                  <td>#{row.id}</td>
                  <td>{row.customer_name}</td>
                  <td>{row.brand} {row.model}</td>
                  <td>{getServiceTypeLabel(row.service_type)}</td>
                  <td>{new Date(row.appointment_datetime).toLocaleString("tr-TR")}</td>
                  <td>{getServiceStatusLabel(row.status)}</td>
                  <td className="appointment-management-table__technician-cell">
                    <select
                      className="appointment-management-table__technician-select"
                      value={selectedTechnicians[row.id] ?? ""}
                      disabled={!canManageAppointment(row.status)}
                      onChange={(event) =>
                        setSelectedTechnicians((current) => ({ ...current, [row.id]: event.target.value }))
                      }
                    >
                      <option value="">Teknisyen seçin</option>
                      {technicians.map((technician) => (
                        <option key={technician.id} value={technician.id}>{technician.full_name}</option>
                      ))}
                    </select>
                  </td>
                  <td className="appointment-management-table__action-cell">
                    <div className="appointment-management-table__actions">
                      <button className="ghost-button appointment-management-table__button" type="button" onClick={() => handleAssign(row.id)} disabled={!canManageAppointment(row.status)}>Ata</button>
                      <button className="danger-button appointment-management-table__button" type="button" onClick={() => handleCancel(row.id)} disabled={!canManageAppointment(row.status)}>İptal</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
