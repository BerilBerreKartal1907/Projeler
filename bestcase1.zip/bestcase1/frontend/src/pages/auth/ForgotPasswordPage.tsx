import { useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";

import { forgotPasswordRequest } from "../../api/authApi";
import { getErrorMessage } from "../../utils/http";
import { PHONE_COUNTRIES, buildPhoneNumber } from "../../utils/phone";

export function ForgotPasswordPage() {
  const navigate = useNavigate();
  const [countryCode, setCountryCode] = useState<string>(PHONE_COUNTRIES[0].code);
  const [localNumber, setLocalNumber] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setMessage(null);
    setIsSubmitting(true);

    try {
      const response = await forgotPasswordRequest(buildPhoneNumber(countryCode, localNumber));
      setMessage(`Telefonunuza SMS gönderildi. Doğrulama kodu 10 dakika boyunca geçerlidir.`);

      if (response.resetToken) {
        const nextToken = response.resetToken;
        window.setTimeout(() => {
          navigate(`/reset-password?token=${encodeURIComponent(nextToken)}`, { replace: true });
        }, 700);
      }
    } catch (requestError) {
      setError(getErrorMessage(requestError, "SMS doğrulama kodu gönderilemedi."));
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="auth-page auth-page--brand">
      <section className="auth-panel auth-panel--single auth-panel--compact">
        <div className="auth-intro auth-intro--centered">
          <p className="eyebrow">Şifre Yardımı</p>
          <h1>Şifremi Unuttum</h1>
          <p className="auth-copy">Telefon numaranızı doğrulayın, SMS kodunu girin ve yeni şifrenizi belirleyin.</p>
        </div>

        <form className="auth-form" onSubmit={handleSubmit}>
          <label>
            <span>Telefon</span>
            <div className="phone-field">
              <select value={countryCode} onChange={(event) => setCountryCode(event.target.value)}>
                {PHONE_COUNTRIES.map((country) => (
                  <option key={country.code} value={country.code}>{country.label}</option>
                ))}
              </select>
              <input
                inputMode="tel"
                value={localNumber}
                onChange={(event) => setLocalNumber(event.target.value.replace(/[^\d]/g, ""))}
                required
              />
            </div>
          </label>
          {error ? <p className="form-error">{error}</p> : null}
          {message ? <p className="form-success">{message}</p> : null}
          <button className="primary-button" type="submit" disabled={isSubmitting}>
            {isSubmitting ? "SMS gönderiliyor..." : "SMS Gönder"}
          </button>
          <div className="auth-link-row">
            <Link className="auth-text-link" to="/login">Girişe dön</Link>
          </div>
        </form>
      </section>
    </div>
  );
}
