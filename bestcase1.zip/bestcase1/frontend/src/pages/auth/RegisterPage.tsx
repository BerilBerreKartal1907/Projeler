import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import { registerRequest } from "../../api/authApi";
import { COUNTRY_CITIES, getDistrictOptions } from "../../utils/geo";
import { PHONE_COUNTRIES, buildPhoneNumber } from "../../utils/phone";
import { getErrorMessage } from "../../utils/http";

export function RegisterPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState<{
    fullName: string;
    email: string;
    password: string;
    countryCode: string;
    localNumber: string;
    district: string;
    city: string;
  }>({
    fullName: "",
    email: "",
    password: "",
    countryCode: PHONE_COUNTRIES[0].code,
    localNumber: "",
    district: "",
    city: ""
  });
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setMessage(null);
    setIsSubmitting(true);

    try {
      const response = await registerRequest({
        fullName: form.fullName,
        email: form.email,
        password: form.password,
        phone: buildPhoneNumber(form.countryCode, form.localNumber),
        district: form.district,
        city: form.city
      });

      setMessage(response.message);
      setTimeout(() => navigate("/login", { replace: true }), 1200);
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Kayıt oluşturulamadı."));
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="auth-page auth-page--brand">
      <section className="auth-panel">
        <div>
          <p className="eyebrow">Yeni Müşteri Kaydı</p>
          <h1>Smart-Appraisal Pro</h1>
          <p className="auth-copy">
            Müşteri hesabınızı oluşturarak araç ekspertizi, servis ve finansman işlemlerini doğrudan panel üzerinden yönetin.
          </p>
        </div>

        <form className="auth-form" onSubmit={handleSubmit}>
          <label>
            <span>Ad Soyad</span>
            <input value={form.fullName} onChange={(event) => setForm((current) => ({ ...current, fullName: event.target.value }))} required />
          </label>
          <label>
            <span>E-posta</span>
            <input type="email" value={form.email} onChange={(event) => setForm((current) => ({ ...current, email: event.target.value }))} required />
          </label>
          <label>
            <span>Şifre</span>
            <input type="password" value={form.password} onChange={(event) => setForm((current) => ({ ...current, password: event.target.value }))} required />
          </label>
          <label>
            <span>Telefon</span>
            <div className="phone-field">
              <select
                value={form.countryCode}
                onChange={(event) => setForm((current) => ({ ...current, countryCode: event.target.value, city: "", district: "" }))}
              >
                {PHONE_COUNTRIES.map((country) => (
                  <option key={country.code} value={country.code}>{country.label}</option>
                ))}
              </select>
              <input
                inputMode="tel"
                value={form.localNumber}
                onChange={(event) => setForm((current) => ({ ...current, localNumber: event.target.value.replace(/[^\d]/g, "") }))}
                required
              />
            </div>
          </label>
          <label>
            <span>Şehir</span>
            <select
              value={form.city}
              onChange={(event) => setForm((current) => ({ ...current, city: event.target.value, district: "" }))}
              required
            >
              <option value="">Şehir seçin</option>
              {(COUNTRY_CITIES[form.countryCode] ?? []).map((city) => (
                <option key={city} value={city}>{city}</option>
              ))}
            </select>
          </label>
          <label>
            <span>İlçe</span>
            {form.countryCode === "+90" ? (
              <select
                value={form.district}
                onChange={(event) => setForm((current) => ({ ...current, district: event.target.value }))}
                disabled={!form.city}
                required
              >
                <option value="">{form.city ? "İlçe seçin" : "Önce şehir seçin"}</option>
                {getDistrictOptions(form.countryCode, form.city).map((district) => (
                  <option key={district} value={district}>{district}</option>
                ))}
              </select>
            ) : (
              <input
                value={form.district}
                onChange={(event) => setForm((current) => ({ ...current, district: event.target.value }))}
                placeholder="İlçe / bölge"
                required
              />
            )}
          </label>
          {error ? <p className="form-error">{error}</p> : null}
          {message ? <p className="form-success">{message}</p> : null}
          <button className="primary-button" type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Kayıt oluşturuluyor..." : "Kayıt Ol"}
          </button>
          <div className="auth-link-row">
            <Link className="auth-text-link" to="/login">Girişe dön</Link>
          </div>
        </form>
      </section>
    </div>
  );
}
