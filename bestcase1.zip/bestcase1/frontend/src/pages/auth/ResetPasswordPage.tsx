import { useMemo, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";

import { resetPasswordRequest } from "../../api/authApi";
import { getErrorMessage } from "../../utils/http";

export function ResetPasswordPage() {
  const [searchParams] = useSearchParams();
  const initialToken = useMemo(() => searchParams.get("token") ?? "", [searchParams]);
  const inputRefs = useRef<Array<HTMLInputElement | null>>([]);
  const [smsDigits, setSmsDigits] = useState(["", "", "", ""]);
  const [form, setForm] = useState({
    token: initialToken,
    smsCode: "",
    newPassword: "",
    confirmPassword: ""
  });
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  function updateDigit(index: number, rawValue: string) {
    const value = rawValue.replace(/[^\d]/g, "").slice(-1);
    const nextDigits = [...smsDigits];
    nextDigits[index] = value;
    setSmsDigits(nextDigits);
    setForm((current) => ({ ...current, smsCode: nextDigits.join("") }));

    if (value && index < inputRefs.current.length - 1) {
      inputRefs.current[index + 1]?.focus();
    }
  }

  function handleDigitKeyDown(index: number, event: React.KeyboardEvent<HTMLInputElement>) {
    if (event.key === "Backspace" && !smsDigits[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  }

  function handleDigitPaste(event: React.ClipboardEvent<HTMLDivElement>) {
    const pasted = event.clipboardData.getData("text").replace(/[^\d]/g, "").slice(0, 4);
    if (!pasted) {
      return;
    }

    event.preventDefault();
    const nextDigits = ["", "", "", ""];
    pasted.split("").forEach((digit, index) => {
      nextDigits[index] = digit;
    });

    setSmsDigits(nextDigits);
    setForm((current) => ({ ...current, smsCode: nextDigits.join("") }));
    inputRefs.current[Math.min(pasted.length, 4) - 1]?.focus();
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setMessage(null);
    setIsSubmitting(true);

    try {
      if (form.smsCode.length !== 4) {
        setError("SMS kodu 4 haneli olmalıdır.");
        return;
      }

      if (form.newPassword.length < 6) {
        setError("Yeni sifre en az 6 karakter olmalidir.");
        return;
      }

      if (form.newPassword !== form.confirmPassword) {
        setError("Sifre tekrar alani yeni sifre ile ayni olmalidir.");
        return;
      }

      const response = await resetPasswordRequest(form);
      setMessage(response.message);
      setSmsDigits(["", "", "", ""]);
      setForm((current) => ({
        ...current,
        smsCode: "",
        newPassword: "",
        confirmPassword: ""
      }));
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Şifre güncellenemedi."));
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="auth-page auth-page--brand">
      <section className="auth-panel auth-panel--single auth-panel--compact">
        <div className="auth-intro auth-intro--centered">
          <p className="eyebrow">Şifre Güncelleme</p>
          <h1>Şifreyi Sıfırla</h1>
          <p className="auth-copy">Telefonunuza gelen 4 haneli SMS doğrulama kodunu girerek yeni şifrenizi belirleyin.</p>
        </div>

        <form className="auth-form" onSubmit={handleSubmit}>
          <div className="auth-helper-card">
            <strong>SMS Doğrulama Kodu</strong>
            <div className="sms-code-grid" onPaste={handleDigitPaste}>
              {smsDigits.map((digit, index) => (
                <input
                  key={index}
                  ref={(element) => { inputRefs.current[index] = element; }}
                  className="sms-code-input"
                  inputMode="numeric"
                  maxLength={1}
                  value={digit}
                  onChange={(event) => updateDigit(index, event.target.value)}
                  onKeyDown={(event) => handleDigitKeyDown(index, event)}
                  aria-label={`${index + 1}. SMS kod hanesi`}
                />
              ))}
            </div>
          </div>
          <label>
            <span>Yeni Şifre</span>
            <input
              type="password"
              value={form.newPassword}
              onChange={(event) => setForm({ ...form, newPassword: event.target.value })}
              required
            />
          </label>
          <label>
            <span>Yeni Şifre Tekrar</span>
            <input
              type="password"
              value={form.confirmPassword}
              onChange={(event) => setForm({ ...form, confirmPassword: event.target.value })}
              required
            />
          </label>
          {error ? <p className="form-error">{error}</p> : null}
          {message ? <p className="form-success">{message}</p> : null}
          <button className="primary-button" type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Şifre güncelleniyor..." : "Şifreyi Güncelle"}
          </button>
          <div className="auth-link-row">
            <Link className="auth-text-link" to="/login">Girişe dön</Link>
          </div>
        </form>
      </section>
    </div>
  );
}
