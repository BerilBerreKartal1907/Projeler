import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";

import { useAuth } from "../../auth/AuthContext";
import { getErrorMessage } from "../../utils/http";

export function LoginPage() {
  const navigate = useNavigate();
  const { login, user } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (user) {
      navigate(`/${user.role}`, { replace: true });
    }
  }, [navigate, user]);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setErrorMessage(null);
    setIsSubmitting(true);

    try {
      await login(email, password);

      if (!rememberMe) {
        sessionStorage.setItem("smart_appraisal_session_hint", "temporary");
      }

      navigate("/", { replace: true });
    } catch (error) {
      setErrorMessage(getErrorMessage(error, "Giriş başarısız. E-posta veya şifreyi kontrol edin."));
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="auth-page auth-page--brand">
      <section className="auth-panel auth-panel--single auth-panel--login">
        <div className="auth-intro auth-intro--centered">
          <p className="eyebrow">Smart-Appraisal</p>
          <h1>Hoş geldin</h1>
          <p className="auth-copy">
            Hesabınıza giriş yapın; ekspertiz, servis, pazarlık ve finansman akışına kaldığınız yerden devam edin.
          </p>
        </div>

        <form className="auth-form" onSubmit={handleSubmit}>
          <label>
            <span>E-posta</span>
            <input type="email" value={email} onChange={(event) => setEmail(event.target.value)} required />
          </label>
          <label>
            <span>Şifre</span>
            <input type="password" value={password} onChange={(event) => setPassword(event.target.value)} required />
          </label>
          <label className="checkbox-row">
            <input type="checkbox" checked={rememberMe} onChange={(event) => setRememberMe(event.target.checked)} />
            <span>Beni hatırla</span>
          </label>
          {errorMessage ? <p className="form-error">{errorMessage}</p> : null}
          <button className="primary-button" type="submit">
            {isSubmitting ? "Giriş yapılıyor..." : "Giriş Yap"}
          </button>
          <div className="auth-secondary-actions">
            <Link className="auth-secondary-link" to="/forgot-password">Şifremi Unuttum</Link>
            <div className="auth-register-prompt">
              <span>Hesabın yok mu?</span>
              <Link className="auth-register-link" to="/register">Kayıt ol</Link>
            </div>
          </div>
        </form>
      </section>
    </div>
  );
}
