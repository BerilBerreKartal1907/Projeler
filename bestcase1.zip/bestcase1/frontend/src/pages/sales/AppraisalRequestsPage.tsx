import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import { listAppraisals } from "../../api/appraisalManagementApi";

type AppraisalRow = Awaited<ReturnType<typeof listAppraisals>>[number];

function appraisalStatusLabel(value: string) {
  switch (value) {
    case "draft":
      return "Taslak";
    case "submitted":
      return "Gönderildi";
    case "pending_manager_approval":
      return "Yönetici onayı bekliyor";
    case "preliminary_offer_ready":
      return "Ön teklif hazır";
    case "approved":
      return "Onaylandı";
    case "rejected":
      return "Reddedildi";
    case "cancelled":
      return "İptal edildi";
    default:
      return value;
  }
}

export function AppraisalRequestsPage() {
  const [rows, setRows] = useState<AppraisalRow[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    listAppraisals().then(setRows).catch(() => setError("Ekspertiz talepleri alınamadı."));
  }, []);

  if (error) {
    return <div className="page-state">{error}</div>;
  }

  return (
    <section className="dashboard-page">
      <section className="panel">
        <div className="panel-heading">
          <div>
            <h3>Ekspertiz Talepleri</h3>
            <p className="section-subtitle">Satış ekibinin takip ettiği aktif başvurular</p>
          </div>
        </div>

        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Müşteri</th>
                <th>Araç</th>
                <th>KM</th>
                <th>Hasar %</th>
                <th>Sistem Teklifi</th>
                <th>Durum</th>
                <th>Detay</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  <td>{row.customer_name}</td>
                  <td>{row.brand} {row.model} {row.year}</td>
                  <td>{row.mileage.toLocaleString("tr-TR")}</td>
                  <td>%{row.damage_percentage}</td>
                  <td>{row.calculated_offer ? `₺${Number(row.calculated_offer).toLocaleString("tr-TR")}` : "-"}</td>
                  <td>
                    <span className={`status-pill ${row.requires_manager_approval ? "status-pill--warning" : "status-pill--success"}`}>
                      {appraisalStatusLabel(row.status)}
                    </span>
                  </td>
                  <td>
                    <Link className="inline-link" to={`/sales_agent/appraisals/${row.id}`}>
                      İncele
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
