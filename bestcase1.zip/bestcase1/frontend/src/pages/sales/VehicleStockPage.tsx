import { useEffect, useState } from "react";

import {
  cancelSalesListing,
  createSalesListing,
  listSalesListingCandidates,
  listSalesListings,
  markSalesListingSold,
  type SalesListingCandidateRow,
  type SalesListingRow
} from "../../api/salesApi";
import { formatIntegerInput, parseIntegerInput } from "../../utils/format";
import { getErrorMessage } from "../../utils/http";

function stockStatusLabel(value: string) {
  switch (value) {
    case "active":
      return "Listede";
    case "under_review":
      return "İncelemede";
    case "sold":
      return "Satıldı";
    case "acquired":
      return "Bayi tarafından alındı";
    case "cancelled":
      return "İptal edildi";
    default:
      return value;
  }
}

export function VehicleStockPage() {
  const [listings, setListings] = useState<SalesListingRow[]>([]);
  const [vehicles, setVehicles] = useState<SalesListingCandidateRow[]>([]);
  const [form, setForm] = useState({ vehicleId: "", price: "" });
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    const [listingRows, vehicleRows] = await Promise.all([listSalesListings(), listSalesListingCandidates()]);
    setListings(listingRows);
    setVehicles(vehicleRows);
  }

  useEffect(() => {
    refresh().catch((requestError) => setError(getErrorMessage(requestError, "Stok verileri alınamadı.")));
  }, []);

  async function handleCreate(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    try {
      await createSalesListing({
        vehicleId: Number(form.vehicleId),
        price: parseIntegerInput(form.price)
      });
      setForm({ vehicleId: "", price: "" });
      setMessage("Satış listesi oluşturuldu.");
      setError(null);
      await refresh();
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Satış listesi oluşturulamadı."));
    }
  }

  async function handleSold(id: number) {
    try {
      await markSalesListingSold(id);
      setMessage("Araç satıldı olarak işaretlendi.");
      setError(null);
      await refresh();
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Araç satış durumu güncellenemedi."));
    }
  }

  async function handleCancel(id: number) {
    try {
      await cancelSalesListing(id);
      setMessage("Satış kaydı iptal edildi.");
      setError(null);
      await refresh();
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Satış kaydı iptal edilemedi."));
    }
  }

  return (
    <section className="dashboard-page">
      <section className="panel form-panel">
        <div className="panel-heading">
          <div>
            <h3>Araç Stok / Satış</h3>
            <p className="section-subtitle">Bayi tarafından alınan veya yönetici onayından geçen araçları satış listesine alın.</p>
          </div>
        </div>
        <form className="action-grid" onSubmit={handleCreate}>
          <select className="inline-input" value={form.vehicleId} onChange={(e) => setForm({ ...form, vehicleId: e.target.value })} required>
            <option value="">Araç seçin</option>
            {vehicles.map((vehicle) => (
              <option key={vehicle.id} value={vehicle.id}>
                {vehicle.brand} {vehicle.model}{vehicle.plate ? ` - ${vehicle.plate}` : ""} / {vehicle.customer_name} / ₺{Number(vehicle.calculated_offer ?? 0).toLocaleString("tr-TR")}
              </option>
            ))}
          </select>
          <input
            className="inline-input"
            type="text"
            inputMode="numeric"
            placeholder="Liste fiyatı"
            value={form.price}
            onChange={(e) => setForm({ ...form, price: formatIntegerInput(e.target.value) })}
            required
          />
          <button className="primary-button" type="submit">Liste Oluştur</button>
        </form>
        {error ? <p className="form-error">{error}</p> : null}
        {message ? <p className="form-success">{message}</p> : null}
      </section>

      <section className="panel">
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Araç</th>
                <th>Yıl</th>
                <th>Paket</th>
                <th>Renk</th>
                <th>Fiyat</th>
                <th>Durum</th>
                <th>Aksiyon</th>
              </tr>
            </thead>
            <tbody>
              {listings.map((row) => (
                <tr key={row.id}>
                  <td>{row.brand} {row.model}</td>
                  <td>{row.year}</td>
                  <td>{row.package ?? "-"}</td>
                  <td>{row.color ?? "-"}</td>
                  <td>₺{Number(row.price).toLocaleString("tr-TR")}</td>
                  <td>{stockStatusLabel(row.status)}</td>
                  <td>
                    {row.status === "sold" ? (
                      "Satıldı"
                    ) : row.status === "cancelled" ? (
                      "İptal edildi"
                    ) : (
                      <div className="table-actions">
                        <button className="ghost-button" type="button" onClick={() => handleSold(row.id)}>Satıldı</button>
                        <button className="danger-button" type="button" onClick={() => handleCancel(row.id)}>İptal Et</button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
