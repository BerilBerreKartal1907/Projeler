import { useEffect, useState } from "react";

import { listNegotiations, type NegotiationListRow } from "../../api/negotiationApi";

function negotiationStatusLabel(value: string) {
  switch (value) {
    case "open":
      return "Açık";
    case "auto_negotiating":
      return "Karşı teklif sürecinde";
    case "pending_manager_review":
      return "Yönetici onayı bekliyor";
    case "accepted":
      return "Anlaşma sağlandı";
    case "rejected":
      return "Reddedildi";
    case "expired":
      return "Süresi doldu";
    case "cancelled":
      return "İptal edildi";
    default:
      return value;
  }
}

export function NegotiationManagementPage() {
  const [rows, setRows] = useState<NegotiationListRow[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    listNegotiations().then(setRows).catch(() => setError("Pazarlık kayıtları alınamadı."));
  }, []);

  if (error) return <div className="page-state">{error}</div>;

  return (
    <section className="dashboard-page">
      <section className="panel">
        <div className="panel-heading">
          <div>
            <h3>Pazarlık Yönetimi</h3>
            <p className="section-subtitle">Satış ekibi pazarlık durumlarını takip eder. Yönetici onayı gereken kayıtlar yalnızca izlenir.</p>
          </div>
        </div>
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Müşteri</th>
                <th>Araç</th>
                <th>Sistem Teklifi</th>
                <th>Müşteri Beklentisi</th>
                <th>Güncel Teklif</th>
                <th>Durum</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  <td>{row.customer_name}</td>
                  <td>{row.brand} {row.model}</td>
                  <td>₺{Number(row.system_offer).toLocaleString("tr-TR")}</td>
                  <td>{row.customer_expected_price ? `₺${Number(row.customer_expected_price).toLocaleString("tr-TR")}` : "-"}</td>
                  <td>₺{Number(row.current_dealer_offer).toLocaleString("tr-TR")}</td>
                  <td>{negotiationStatusLabel(row.status)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
