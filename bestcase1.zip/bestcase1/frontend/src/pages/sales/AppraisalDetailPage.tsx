import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

import { getAppraisalDetail, type AppraisalDetail } from "../../api/appraisalManagementApi";
import { damageTypeLabels, vehiclePartLabels } from "../../utils/labels";

export function AppraisalDetailPage() {
  const { appraisalId } = useParams();
  const [detail, setDetail] = useState<AppraisalDetail | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!appraisalId) return;
    getAppraisalDetail(Number(appraisalId)).then(setDetail).catch(() => setError("Detay yüklenemedi."));
  }, [appraisalId]);

  if (error) return <div className="page-state">{error}</div>;
  if (!detail) return <div className="page-state">Ekspertiz detayı yükleniyor...</div>;

  const declaredTramerAmount = Number(detail.declared_tramer_amount ?? 0);
  const hasAccidentRecord = detail.accident_record || declaredTramerAmount > 0;

  return (
    <section className="dashboard-page">
      <div className="content-grid">
        <section className="panel">
          <div className="panel-heading panel-heading--stacked">
            <div>
              <h3>Müşteri ve Araç Bilgileri</h3>
              <p className="section-subtitle">Satış ekibi için ekspertiz özeti</p>
            </div>
          </div>
          <ul className="timeline-list">
            <li>Müşteri: {String(detail.customer_name)}</li>
            <li>E-posta: {String(detail.customer_email)}</li>
            <li>Araç: {String(detail.brand)} {String(detail.model)} {String(detail.year)}</li>
            <li>Plaka: {String(detail.plate ?? "-")}</li>
            <li>Kilometre: {Number(detail.mileage).toLocaleString("tr-TR")}</li>
          </ul>
        </section>

        <section className="panel">
          <div className="panel-heading panel-heading--stacked">
            <div>
              <h3>Piyasa Değeri ve Teklif</h3>
              <p className="section-subtitle">Kural motoru çıktıları</p>
            </div>
          </div>
          <ul className="timeline-list">
            <li>Piyasa değeri: ₺{Number(detail.market_value ?? 0).toLocaleString("tr-TR")}</li>
            <li>Beyan edilen Tramer tutarı: ₺{declaredTramerAmount.toLocaleString("tr-TR")}</li>
            <li>Kaza kaydı: {hasAccidentRecord ? "Var" : "Yok"}</li>
            <li>Hasar yüzdesi: %{Number(detail.damage_percentage).toLocaleString("tr-TR")}</li>
            <li>Ön teklif: ₺{Number(detail.calculated_offer ?? 0).toLocaleString("tr-TR")}</li>
            <li>Onay nedeni: {String(detail.approval_reason ?? "-")}</li>
          </ul>
        </section>
      </div>

      <section className="panel">
        <div className="panel-heading panel-heading--stacked">
          <div>
            <h3>Hasar Detayları</h3>
            <p className="section-subtitle">Müşteri tarafından işaretlenen parçalar</p>
          </div>
        </div>
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Parça</th>
                <th>Durum</th>
                <th>Puan</th>
                <th>Not</th>
              </tr>
            </thead>
            <tbody>
              {detail.damageDetails.map((item) => (
                <tr key={item.id}>
                  <td>{vehiclePartLabels[item.vehicle_part] ?? item.vehicle_part}</td>
                  <td>{damageTypeLabels[item.damage_type] ?? item.damage_type}</td>
                  <td>{item.damage_point}</td>
                  <td>{item.note || "-"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
