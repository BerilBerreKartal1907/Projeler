import { useEffect, useState } from "react";

import { getDashboardMetrics } from "../../api/dashboardApi";
import { StatCard } from "../../components/common/StatCard";
import { getErrorMessage } from "../../utils/http";

export function SalesDashboard() {
  const [metrics, setMetrics] = useState({
    newAppraisals: 0,
    activeNegotiations: 0,
    readyForSale: 0,
    todaysSales: 0,
    pendingCustomerMeetings: 0
  });
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getDashboardMetrics("sales")
      .then((data) => setMetrics(data as typeof metrics))
      .catch((requestError) => setError(getErrorMessage(requestError, "Satış paneli verileri alınamadı.")));
  }, []);

  return (
    <section className="dashboard-page">
      <div className="stats-grid">
        <StatCard label="Yeni Ekspertiz Talebi" value={String(metrics.newAppraisals)} />
        <StatCard label="Aktif Pazarlık" value={String(metrics.activeNegotiations)} tone="warning" />
        <StatCard label="Satışa Hazır Araç" value={String(metrics.readyForSale)} tone="success" />
        <StatCard label="Bugünkü Satış" value={`₺${Number(metrics.todaysSales).toLocaleString("tr-TR")}`} />
        <StatCard label="Bekleyen Müşteri Toplantısı" value={String(metrics.pendingCustomerMeetings)} tone="danger" />
      </div>
      {error ? <p className="form-error">{error}</p> : null}
    </section>
  );
}
