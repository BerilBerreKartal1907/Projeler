import type { PropsWithChildren, ReactNode } from "react";

type PageSectionProps = PropsWithChildren<{
  title: string;
  subtitle: string;
  aside?: ReactNode;
}>;

export function PageSection({ title, subtitle, aside, children }: PageSectionProps) {
  return (
    <section className="panel">
      <div className="panel-heading panel-heading--stacked">
        <div>
          <h3>{title}</h3>
          <p className="section-subtitle">{subtitle}</p>
        </div>
        {aside}
      </div>
      {children}
    </section>
  );
}
