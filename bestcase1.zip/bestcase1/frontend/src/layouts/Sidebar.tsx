import { NavLink } from "react-router-dom";

import { useAuth } from "../auth/AuthContext";
import { roleMenus } from "../routes/roleMenus";

export function Sidebar() {
  const { currentRole } = useAuth();

  if (!currentRole) {
    return null;
  }

  const menuItems = roleMenus[currentRole];

  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <h1>Smart-Appraisal</h1>
        <div className="sidebar-divider" />
      </div>
      <nav className="sidebar-nav">
        {menuItems.map((item) => (
          <NavLink
            key={`${item.label}-${item.path}`}
            className={({ isActive }) => `sidebar-link ${isActive ? "sidebar-link--active" : ""}`}
            to={item.path}
            end={item.path === `/${currentRole}`}
          >
            <span className="sidebar-link__text">{item.label}</span>
          </NavLink>
        ))}
      </nav>
      {currentRole === "customer" ? (
        <div className="sidebar-footer">
          <div className="sidebar-social-list" aria-label="Smart-Appraisal sosyal medya hesapları">
            <a href="https://www.instagram.com/smartappraisal" target="_blank" rel="noreferrer">
              <span className="social-icon">◎</span>
              <span>@smartappraisal</span>
            </a>
            <a href="https://twitter.com/smartappraisal" target="_blank" rel="noreferrer">
              <span className="social-icon">X</span>
              <span>@smartappraisal</span>
            </a>
            <a href="https://www.youtube.com/@smartappraisal" target="_blank" rel="noreferrer">
              <span className="social-icon">▶</span>
              <span>Smart-Appraisal</span>
            </a>
          </div>
          <p>© 2026 BestCase. Tüm hakları saklıdır.</p>
        </div>
      ) : null}
    </aside>
  );
}
