import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";

import { useAuth } from "../auth/AuthContext";
import { listNotifications, type NotificationRow } from "../api/notificationApi";
import { getErrorMessage } from "../utils/http";

export function Topbar() {
  const { currentRole, logout, user } = useAuth();
  const location = useLocation();
  const [notifications, setNotifications] = useState<NotificationRow[]>([]);
  const [error, setError] = useState<string | null>(null);

  if (!currentRole) {
    return null;
  }

  async function refreshNotifications() {
    const rows = await listNotifications();
    setNotifications(rows);
  }

  useEffect(() => {
    refreshNotifications().catch((requestError) =>
      setError(getErrorMessage(requestError, "Bildirimler alınamadı."))
    );
  }, [location.pathname]);

  useEffect(() => {
    const intervalId = window.setInterval(() => {
      refreshNotifications().catch((requestError) =>
        setError(getErrorMessage(requestError, "Bildirimler alınamadı."))
      );
    }, 12000);

    return () => window.clearInterval(intervalId);
  }, []);

  return (
    <header className="topbar">
      <div className="topbar-title">
        <h2>{user?.fullName ? `Hoş geldin ${user.fullName}!` : currentRole ? "Gösterge Paneli" : ""}</h2>
      </div>

      <div className="topbar-actions">
        {error ? <span className="topbar-error">{error}</span> : null}
        <button className="primary-button primary-button--small" type="button" onClick={logout}>
          Çıkış Yap
        </button>
      </div>
    </header>
  );
}
