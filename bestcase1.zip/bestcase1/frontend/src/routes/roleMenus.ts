export type AppRole =
  | "customer"
  | "sales_agent"
  | "technician"
  | "service_manager"
  | "authorized_manager"
  | "admin";

export const roleLabels: Record<AppRole, string> = {
  customer: "Müşteri",
  sales_agent: "Satış Danışmanı",
  technician: "Teknisyen",
  service_manager: "Servis Müdürü",
  authorized_manager: "Yetkili Yönetici",
  admin: "Admin"
};

export type MenuItem = {
  label: string;
  path: string;
};

export const roleMenus: Record<AppRole, MenuItem[]> = {
  customer: [
    { label: "Ana Sayfa", path: "/customer" },
    { label: "Araç Ekspertizi", path: "/customer/appraisal/new" },
    { label: "Pazarlık", path: "/customer/negotiation" },
    { label: "Servis", path: "/customer/service" },
    { label: "Randevularım", path: "/customer/service/appointments" },
    { label: "Finansman", path: "/customer/financing" },
    { label: "Bildirimler", path: "/customer/notifications" },
    { label: "Profil", path: "/customer/profile" }
  ],
  sales_agent: [
    { label: "Gösterge Paneli", path: "/sales_agent" },
    { label: "Ekspertiz Talepleri", path: "/sales_agent/appraisals" },
    { label: "Pazarlık Yönetimi", path: "/sales_agent/negotiations" },
    { label: "Araç Stok", path: "/sales_agent/stock" }
  ],
  technician: [
    { label: "Gösterge Paneli", path: "/technician" },
    { label: "Randevular", path: "/technician/appointments" },
    { label: "Servis Operasyonları", path: "/technician/operations" },
    { label: "Tamamlama", path: "/technician/complete" }
  ],
  service_manager: [
    { label: "Gösterge Paneli", path: "/service_manager" },
    { label: "Randevu Yönetimi", path: "/service_manager/appointments" },
    { label: "Teknisyen Performansı", path: "/service_manager/performance" },
    { label: "Kritik Güvenlik", path: "/service_manager/critical-safety" }
  ],
  authorized_manager: [
    { label: "Gösterge Paneli", path: "/authorized_manager" },
    { label: "Ekspertiz Onayları", path: "/authorized_manager/appraisal-approvals" },
    { label: "Pazarlık Onayları", path: "/authorized_manager/negotiation-approvals" },
    { label: "Raporlar", path: "/authorized_manager/reports" }
  ],
  admin: [
    { label: "Gösterge Paneli", path: "/admin" },
    { label: "Kullanıcı Yönetimi", path: "/admin/users" },
    { label: "Rol Yönetimi", path: "/admin/roles" },
    { label: "Sistem Parametreleri", path: "/admin/system-parameters" },
    { label: "Denetim Logları", path: "/admin/audit-logs" }
  ]
};
