import { Navigate, Route, Routes } from "react-router-dom";

import { ProtectedRoute } from "../auth/ProtectedRoute";
import { RoleBasedRedirect } from "../auth/RoleBasedRedirect";
import { useAuth } from "../auth/AuthContext";
import { DashboardLayout } from "../layouts/DashboardLayout";
import { CustomerDashboard } from "../pages/customer/CustomerDashboard";
import { DamageMarkingPage } from "../pages/customer/DamageMarkingPage";
import { NegotiationPage } from "../pages/customer/NegotiationPage";
import { NotificationsPage } from "../pages/customer/NotificationsPage";
import { PreliminaryOfferPage } from "../pages/customer/PreliminaryOfferPage";
import { ProfilePage } from "../pages/customer/ProfilePage";
import { CheckupApprovalPage } from "../pages/customer/CheckupApprovalPage";
import { ServiceAppointmentPage } from "../pages/customer/ServiceAppointmentPage";
import { ServiceAppointmentsPage } from "../pages/customer/ServiceAppointmentsPage";
import { VehicleAppraisalForm } from "../pages/customer/VehicleAppraisalForm";
import { AppraisalApprovalsPage } from "../pages/manager/AppraisalApprovalsPage";
import { NegotiationApprovalsPage } from "../pages/manager/NegotiationApprovalsPage";
import { ReportsPage } from "../pages/manager/ReportsPage";
import { SalesDashboard } from "../pages/sales/SalesDashboard";
import { AppraisalDetailPage } from "../pages/sales/AppraisalDetailPage";
import { NegotiationManagementPage } from "../pages/sales/NegotiationManagementPage";
import { AppraisalRequestsPage } from "../pages/sales/AppraisalRequestsPage";
import { VehicleStockPage } from "../pages/sales/VehicleStockPage";
import { CriticalSafetyReviewPage } from "../pages/service-manager/CriticalSafetyReviewPage";
import { TechnicianDashboard } from "../pages/technician/TechnicianDashboard";
import { OperationCompletePage } from "../pages/technician/OperationCompletePage";
import { ServiceOperationCreatePage } from "../pages/technician/ServiceOperationCreatePage";
import { ServiceManagerDashboard } from "../pages/service-manager/ServiceManagerDashboard";
import { ManagerDashboard } from "../pages/manager/ManagerDashboard";
import { LoginPage } from "../pages/auth/LoginPage";
import { ForgotPasswordPage } from "../pages/auth/ForgotPasswordPage";
import { ResetPasswordPage } from "../pages/auth/ResetPasswordPage";
import { RegisterPage } from "../pages/auth/RegisterPage";
import { AdminDashboard } from "../pages/admin/AdminDashboard";
import { AuditLogsPage } from "../pages/admin/AuditLogsPage";
import { RoleManagementPage } from "../pages/admin/RoleManagementPage";
import { SystemParametersPage } from "../pages/admin/SystemParametersPage";
import { UserManagementPage } from "../pages/admin/UserManagementPage";
import { FinancingCalculatorPage } from "../pages/customer/FinancingCalculatorPage";
import { TechnicianAppointmentsPage } from "../pages/technician/TechnicianAppointmentsPage";
import { AppointmentManagementPage } from "../pages/service-manager/AppointmentManagementPage";
import { TechnicianPerformancePage } from "../pages/service-manager/TechnicianPerformancePage";

export function AppRouter() {
  const { currentRole } = useAuth();

  // /:role ana yolu, giriş yapan kullanıcının rolüne göre ilgili dashboard bileşenini gösterir.
  const dashboardMap = {
    customer: <CustomerDashboard />,
    sales_agent: <SalesDashboard />,
    technician: <TechnicianDashboard />,
    service_manager: <ServiceManagerDashboard />,
    authorized_manager: <ManagerDashboard />,
    admin: <AdminDashboard />
  } as const;

  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/forgot-password" element={<ForgotPasswordPage />} />
      <Route path="/reset-password" element={<ResetPasswordPage />} />
      <Route path="/" element={<RoleBasedRedirect />} />
      <Route
        path="/:role"
        element={
          <ProtectedRoute allowedRoles={["customer", "sales_agent", "technician", "service_manager", "authorized_manager", "admin"]}>
            <DashboardLayout>{currentRole ? dashboardMap[currentRole] : null}</DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/customer/appraisal/new"
        element={
          <ProtectedRoute allowedRoles={["customer"]}>
            <DashboardLayout>
              <VehicleAppraisalForm />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/customer/appraisal/:appraisalId/damage"
        element={
          <ProtectedRoute allowedRoles={["customer"]}>
            <DashboardLayout>
              <DamageMarkingPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/customer/appraisal/:appraisalId/offer"
        element={
          <ProtectedRoute allowedRoles={["customer"]}>
            <DashboardLayout>
              <PreliminaryOfferPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/customer/negotiation"
        element={
          <ProtectedRoute allowedRoles={["customer"]}>
            <DashboardLayout>
              <NegotiationPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/customer/service"
        element={
          <ProtectedRoute allowedRoles={["customer"]}>
            <DashboardLayout>
              <ServiceAppointmentPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/customer/service/appointments"
        element={
          <ProtectedRoute allowedRoles={["customer"]}>
            <DashboardLayout>
              <ServiceAppointmentsPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/customer/checkup-approval"
        element={
          <ProtectedRoute allowedRoles={["customer"]}>
            <DashboardLayout>
              <CheckupApprovalPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/customer/financing"
        element={
          <ProtectedRoute allowedRoles={["customer"]}>
            <DashboardLayout>
              <FinancingCalculatorPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/customer/notifications"
        element={
          <ProtectedRoute allowedRoles={["customer"]}>
            <DashboardLayout>
              <NotificationsPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/customer/profile"
        element={
          <ProtectedRoute allowedRoles={["customer"]}>
            <DashboardLayout>
              <ProfilePage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/sales_agent/appraisals"
        element={
          <ProtectedRoute allowedRoles={["sales_agent"]}>
            <DashboardLayout>
              <AppraisalRequestsPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/sales_agent/appraisals/:appraisalId"
        element={
          <ProtectedRoute allowedRoles={["sales_agent"]}>
            <DashboardLayout>
              <AppraisalDetailPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/sales_agent/negotiations"
        element={
          <ProtectedRoute allowedRoles={["sales_agent"]}>
            <DashboardLayout>
              <NegotiationManagementPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/sales_agent/stock"
        element={
          <ProtectedRoute allowedRoles={["sales_agent"]}>
            <DashboardLayout>
              <VehicleStockPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/authorized_manager/appraisal-approvals"
        element={
          <ProtectedRoute allowedRoles={["authorized_manager"]}>
            <DashboardLayout>
              <AppraisalApprovalsPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/authorized_manager/negotiation-approvals"
        element={
          <ProtectedRoute allowedRoles={["authorized_manager"]}>
            <DashboardLayout>
              <NegotiationApprovalsPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/authorized_manager/reports"
        element={
          <ProtectedRoute allowedRoles={["authorized_manager"]}>
            <DashboardLayout>
              <ReportsPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/technician/appointments"
        element={
          <ProtectedRoute allowedRoles={["technician"]}>
            <DashboardLayout>
              <TechnicianAppointmentsPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/technician/operations"
        element={
          <ProtectedRoute allowedRoles={["technician"]}>
            <DashboardLayout>
              <ServiceOperationCreatePage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/technician/complete"
        element={
          <ProtectedRoute allowedRoles={["technician"]}>
            <DashboardLayout>
              <OperationCompletePage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/service_manager/appointments"
        element={
          <ProtectedRoute allowedRoles={["service_manager"]}>
            <DashboardLayout>
              <AppointmentManagementPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/service_manager/performance"
        element={
          <ProtectedRoute allowedRoles={["service_manager"]}>
            <DashboardLayout>
              <TechnicianPerformancePage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/service_manager/critical-safety"
        element={
          <ProtectedRoute allowedRoles={["service_manager"]}>
            <DashboardLayout>
              <CriticalSafetyReviewPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/admin/users"
        element={
          <ProtectedRoute allowedRoles={["admin"]}>
            <DashboardLayout>
              <UserManagementPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/admin/system-parameters"
        element={
          <ProtectedRoute allowedRoles={["admin"]}>
            <DashboardLayout>
              <SystemParametersPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/admin/roles"
        element={
          <ProtectedRoute allowedRoles={["admin"]}>
            <DashboardLayout>
              <RoleManagementPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/admin/audit-logs"
        element={
          <ProtectedRoute allowedRoles={["admin"]}>
            <DashboardLayout>
              <AuditLogsPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
