import { Navigate } from "react-router-dom";

import { useAuth } from "./AuthContext";

export function RoleBasedRedirect() {
  const { currentRole } = useAuth();

  if (!currentRole) {
    return <Navigate to="/login" replace />;
  }

  return <Navigate to={`/${currentRole}`} replace />;
}
