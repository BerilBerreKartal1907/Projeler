import type { PropsWithChildren } from "react";
import { Navigate } from "react-router-dom";

import { useAuth } from "./AuthContext";
import type { AppRole } from "../routes/roleMenus";

type ProtectedRouteProps = PropsWithChildren<{
  allowedRoles?: AppRole[];
}>;

export function ProtectedRoute({ children, allowedRoles }: ProtectedRouteProps) {
  const { user, currentRole, isLoading } = useAuth();

  if (isLoading) {
    return <div className="page-state">Oturum kontrol ediliyor...</div>;
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && currentRole && !allowedRoles.includes(currentRole)) {
    return <Navigate to={`/${currentRole}`} replace />;
  }

  return <>{children}</>;
}
