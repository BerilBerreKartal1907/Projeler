export function digitsOnly(value: string) {
  return value.replace(/\D/g, "");
}

export function formatIntegerInput(value: string) {
  const digits = digitsOnly(value);
  if (!digits) {
    return "";
  }

  return Number(digits).toLocaleString("tr-TR");
}

export function parseIntegerInput(value: string) {
  const digits = digitsOnly(value);
  return digits ? Number(digits) : 0;
}

export function formatCurrency(value: string | number | null | undefined) {
  if (value === null || value === undefined || value === "") {
    return "-";
  }

  return new Intl.NumberFormat("tr-TR", {
    style: "currency",
    currency: "TRY",
    minimumFractionDigits: 0,
    maximumFractionDigits: 2
  }).format(Number(value));
}

export function formatNumber(value: string | number | null | undefined, maximumFractionDigits = 0) {
  if (value === null || value === undefined || value === "") {
    return "-";
  }

  return new Intl.NumberFormat("tr-TR", {
    minimumFractionDigits: 0,
    maximumFractionDigits
  }).format(Number(value));
}

