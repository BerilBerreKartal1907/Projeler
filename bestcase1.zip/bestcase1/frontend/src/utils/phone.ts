export const PHONE_COUNTRIES = [
  { code: "+90", label: "Türkiye (+90)" },
  { code: "+994", label: "Azerbaycan (+994)" },
  { code: "+49", label: "Almanya (+49)" },
  { code: "+359", label: "Bulgaristan (+359)" },
  { code: "+995", label: "Gürcistan (+995)" }
] as const;

export function splitPhoneNumber(raw: string | null | undefined) {
  const input = (raw ?? "").trim();
  const matched = PHONE_COUNTRIES.find((country) => input.startsWith(country.code));

  if (!matched) {
    return {
      countryCode: PHONE_COUNTRIES[0].code,
      localNumber: input.replace(/\s+/g, "")
    };
  }

  return {
    countryCode: matched.code,
    localNumber: input.slice(matched.code.length).replace(/\s+/g, "")
  };
}

export function buildPhoneNumber(countryCode: string, localNumber: string) {
  const normalized = localNumber.replace(/[^\d]/g, "");
  return normalized ? `${countryCode} ${normalized}` : "";
}

