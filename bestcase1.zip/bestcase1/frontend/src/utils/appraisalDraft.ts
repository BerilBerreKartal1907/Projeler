const APPRAISAL_DRAFT_KEY = "smart_appraisal_latest_appraisal_id";

export function setLatestAppraisalId(id: number) {
  localStorage.setItem(APPRAISAL_DRAFT_KEY, String(id));
}

export function getLatestAppraisalId() {
  const value = localStorage.getItem(APPRAISAL_DRAFT_KEY);
  return value ? Number(value) : null;
}
