import type { AppRole } from "../routes/roleMenus";

export const serviceTypeLabels: Record<string, string> = {
  maintenance: "Periyodik bakım",
  check_up: "Check-up",
  accident_repair: "Hasar onarımı",
  modification: "Modifikasyon"
};

export const serviceStatusLabels: Record<string, string> = {
  pending: "Onay bekliyor",
  approved: "Onaylandı",
  assigned: "Teknisyen atandı",
  checkup_in_progress: "Check-up sürüyor",
  waiting_customer_approval: "Müşteri onayı bekleniyor",
  in_progress: "İşlem sürüyor",
  completed: "Tamamlandı",
  cancelled: "İptal edildi"
};

export const operationTypeLabels: Record<string, string> = {
  checkup_repair: "Check-up onarımı",
  maintenance: "Periyodik bakım işlemi",
  part_replacement: "Parça değişimi",
  diagnostics: "Arıza tespiti",
  bodywork: "Kaporta işlemi",
  paint: "Boya işlemi"
};

export const operationApprovalStatusLabels: Record<string, string> = {
  pending: "Müşteri onayı bekleniyor",
  approved: "Müşteri onayladı",
  rejected: "Müşteri reddetti"
};

export const managerReviewStatusLabels: Record<string, string> = {
  not_required: "Yönetici incelemesi gerekmiyor",
  pending: "Yönetici incelemesi bekleniyor",
  approved: "Yönetici onayladı",
  rejected: "Yönetici reddetti"
};

export const appraisalStatusLabels: Record<string, string> = {
  draft: "Taslak",
  submitted: "Gönderildi",
  pending_manager_approval: "Yönetici onayı bekliyor",
  preliminary_offer_ready: "Ön teklif hazır",
  approved: "Onaylandı",
  rejected: "Reddedildi",
  cancelled: "İptal edildi"
};

export const notificationTypeLabels: Record<string, string> = {
  in_app: "Yeni bildirim",
  email_simulated: "E-posta bildirimi",
  sms_simulated: "SMS bildirimi"
};

export const roleDisplayLabels: Record<AppRole, string> = {
  customer: "Müşteri",
  sales_agent: "Satış Danışmanı",
  technician: "Teknisyen",
  service_manager: "Servis Müdürü",
  authorized_manager: "Yetkili Yönetici",
  admin: "Admin"
};

export const financingBanks = [
  { code: "ziraat", name: "Ziraat Bankası", monthlyInterestRate: 3.19 },
  { code: "isbank", name: "İş Bankası", monthlyInterestRate: 3.29 },
  { code: "garanti", name: "Garanti BBVA", monthlyInterestRate: 3.35 },
  { code: "akbank", name: "Akbank", monthlyInterestRate: 3.39 },
  { code: "yapikredi", name: "Yapı Kredi", monthlyInterestRate: 3.44 },
  { code: "vakifbank", name: "VakıfBank", monthlyInterestRate: 3.24 }
] as const;

export const damageTypeLabels: Record<string, string> = {
  original: "Orijinal",
  painted: "Boyalı",
  local_painted: "Lokal Boyalı",
  replaced: "Değişen",
  damaged: "Hasarlı"
};

export const vehiclePartLabels: Record<string, string> = {
  hood: "Kaput",
  roof: "Tavan",
  front_bumper: "Ön Tampon",
  rear_bumper: "Arka Tampon",
  right_front_door: "Sağ Ön Kapı",
  right_rear_door: "Sağ Arka Kapı",
  left_front_door: "Sol Ön Kapı",
  left_rear_door: "Sol Arka Kapı",
  trunk: "Bagaj Kapağı",
  right_fender: "Sağ Çamurluk",
  left_fender: "Sol Çamurluk",
  engine: "Motor Bölmesi",
  tires: "Lastikler"
};

export const financingMaturityOptions = [6, 9, 12, 18, 24, 32, 36, 64];

export function getServiceTypeLabel(value: string) {
  return serviceTypeLabels[value] ?? value;
}

export function getServiceStatusLabel(value: string) {
  return serviceStatusLabels[value] ?? value;
}

export function getOperationTypeLabel(value: string) {
  return operationTypeLabels[value] ?? value;
}

export function getOperationApprovalStatusLabel(value: string) {
  return operationApprovalStatusLabels[value] ?? value;
}

export function getManagerReviewStatusLabel(value: string) {
  return managerReviewStatusLabels[value] ?? value;
}

export function getAppraisalStatusLabel(value: string) {
  return appraisalStatusLabels[value] ?? value;
}

export function getFinancingRate(bankCode: string, months: number) {
  const bank = financingBanks.find((item) => item.code === bankCode) ?? financingBanks[0];
  const maturityAdjustment =
    months <= 9 ? 0 :
    months <= 12 ? 0.08 :
    months <= 18 ? 0.18 :
    months <= 24 ? 0.32 :
    months <= 32 ? 0.46 :
    months <= 36 ? 0.61 : 0.92;

  return Number((bank.monthlyInterestRate + maturityAdjustment).toFixed(2));
}
