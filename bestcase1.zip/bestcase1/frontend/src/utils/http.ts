import axios from "axios";

export function getErrorMessage(error: unknown, fallback = "İşlem sırasında beklenmeyen bir hata oluştu.") {
  if (axios.isAxiosError(error)) {
    const responseMessage = error.response?.data?.message;

    if (typeof responseMessage === "string" && responseMessage.trim()) {
      return responseMessage;
    }
  }

  if (error instanceof Error && error.message.trim()) {
    return error.message;
  }

  return fallback;
}
