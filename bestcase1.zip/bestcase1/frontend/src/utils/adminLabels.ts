import { roleLabels, type AppRole } from "../routes/roleMenus";

// Admin ekranlarında backend kodları doğrudan göstermek yerine kullanıcı dostu Türkçe etiketler kullanılır.
export const permissionLabels: Record<string, string> = {
  view: "Görüntüleyebilir",
  create: "Yeni kayıt açabilir",
  update: "Güncelleyebilir",
  delete: "Silebilir",
  approve: "Onay verebilir"
};

export const permissionColumnLabels = {
  can_view: "Görüntüleme",
  can_create: "Kayıt açma",
  can_update: "Güncelleme",
  can_delete: "Silme",
  can_approve: "Onay"
};

export const rolePurposeLabels: Record<AppRole, string> = {
  customer: "Müşteri portalını kullanır; ekspertiz, servis, finansman ve bildirim adımlarını görür.",
  sales_agent: "Satış ve ekspertiz taleplerini takip eder, pazarlık sürecini yönetir.",
  technician: "Kendisine atanan servis randevularını ve operasyon tamamlama adımlarını yürütür.",
  service_manager: "Servis kapasitesini, teknisyen performansını ve kritik güvenlik onaylarını yönetir.",
  authorized_manager: "Fiyat farkı, pazarlık ve yönetici onayı gerektiren kararları değerlendirir.",
  admin: "Kullanıcıları, rollerin görünür yetki özetini, sistem parametrelerini ve denetim kayıtlarını yönetir."
};

export const parameterLabels: Record<string, { title: string; help: string; unit?: string }> = {
  minimum_profit_rate: {
    title: "Minimum Kar Oranı",
    help: "Bayi satıştan en az bu yüzde kadar kar hedefler.",
    unit: "%"
  },
  max_interest_rate: {
    title: "Azami Aylık Faiz",
    help: "Finansman hesaplarında kullanılabilecek en yüksek aylık faiz oranı.",
    unit: "%"
  },
  tramer_accident_discount_rate: {
    title: "TRAMER Kaza İndirimi",
    help: "Kaza kaydı olan araçlarda tekliften düşülecek otomatik oran.",
    unit: "%"
  },
  high_mileage_limit: {
    title: "Yüksek Kilometre Eşiği",
    help: "Bu kilometrenin üstündeki araçlar yüksek kilometreli kabul edilir.",
    unit: "km"
  },
  high_damage_percentage_limit: {
    title: "Yüksek Hasar Eşiği",
    help: "Hasar oranı bu değeri aşarsa kayıt daha riskli değerlendirilir.",
    unit: "%"
  },
  price_difference_manager_approval_rate: {
    title: "Yönetici Onayı Fiyat Farkı",
    help: "Müşteri beklentisi ile sistem teklifi arasındaki fark bu oranı aşarsa yönetici onayı gerekir.",
    unit: "%"
  },
  daily_maintenance_capacity: {
    title: "Günlük Bakım Kapasitesi",
    help: "Bir günde alınabilecek bakım randevusu sayısı.",
    unit: "randevu"
  },
  daily_checkup_capacity: {
    title: "Günlük Check-up Kapasitesi",
    help: "Bir günde alınabilecek check-up randevusu sayısı.",
    unit: "randevu"
  },
  daily_accident_repair_capacity: {
    title: "Günlük Kaza Onarım Kapasitesi",
    help: "Bir günde alınabilecek kaza onarım randevusu sayısı.",
    unit: "randevu"
  },
  daily_modification_capacity: {
    title: "Günlük Modifikasyon Kapasitesi",
    help: "Bir günde alınabilecek modifikasyon randevusu sayısı.",
    unit: "randevu"
  },
  damage_point_original: {
    title: "Orijinal Parça Hasar Puanı",
    help: "Orijinal parçanın ekspertiz hasar skoruna etkisi.",
    unit: "puan"
  },
  damage_point_painted: {
    title: "Boyalı Parça Hasar Puanı",
    help: "Boyalı parçanın ekspertiz hasar skoruna etkisi.",
    unit: "puan"
  },
  damage_point_local_painted: {
    title: "Lokal Boyalı Parça Hasar Puanı",
    help: "Lokal boyalı parçanın ekspertiz hasar skoruna etkisi.",
    unit: "puan"
  },
  damage_point_replaced: {
    title: "Değişen Parça Hasar Puanı",
    help: "Değişmiş parçanın ekspertiz hasar skoruna etkisi.",
    unit: "puan"
  },
  damage_point_damaged: {
    title: "Hasarlı Parça Hasar Puanı",
    help: "Hasarlı parçanın ekspertiz hasar skoruna etkisi.",
    unit: "puan"
  }
};

export const auditActionLabels: Record<string, string> = {
  update_system_parameter: "Sistem parametresi güncellendi",
  create_user: "Kullanıcı oluşturuldu",
  update_user: "Kullanıcı güncellendi",
  update_appraisal_status: "Ekspertiz durumu güncellendi",
  create_appraisal: "Ekspertiz talebi oluşturuldu",
  calculate_preliminary_offer: "Ön teklif hesaplandı",
  approve_appraisal: "Ekspertiz onaylandı",
  reject_appraisal: "Ekspertiz reddedildi",
  revise_appraisal_price: "Ekspertiz fiyatı revize edildi",
  submit_customer_expectation: "Müşteri beklentisi gönderildi",
  accept_negotiation: "Pazarlık kabul edildi",
  approve_negotiation: "Pazarlık onaylandı",
  reject_negotiation: "Pazarlık reddedildi",
  request_negotiation_meeting: "Pazarlık görüşmesi istendi",
  update_negotiation_settings: "Pazarlık ayarları güncellendi",
  create_credit_calculation: "Finansman hesaplaması oluşturuldu",
  create_service_appointment: "Servis randevusu oluşturuldu",
  cancel_service_appointment: "Servis randevusu iptal edildi",
  reschedule_service_appointment: "Servis randevusu yeniden planlandı",
  assign_technician: "Teknisyen atandı",
  complete_service_operations: "Servis işlemleri tamamlandı",
  create_negotiation_message: "Pazarlık mesajı eklendi",
  approve_service_operation: "Servis operasyonu onaylandı",
  reject_service_operation: "Servis operasyonu reddedildi",
  review_critical_operation: "Kritik servis operasyonu incelendi"
};

export const auditEntityLabels: Record<string, string> = {
  system_parameter: "Sistem parametresi",
  user: "Kullanıcı",
  appraisal_request: "Ekspertiz talebi",
  negotiation: "Pazarlık",
  negotiation_message: "Pazarlık mesajı",
  service_operation: "Servis operasyonu",
  service_appointment: "Servis randevusu",
  credit_calculation: "Finansman hesaplaması",
  vehicle: "Araç"
};

export function getRoleLabel(role: string) {
  return roleLabels[role as AppRole] ?? role;
}

export function getParameterLabel(key: string) {
  return parameterLabels[key] ?? {
    title: key,
    help: "Bu parametre ilgili iş kuralının çalışma değerini belirler."
  };
}
