import { TURKEY_DISTRICTS } from "./turkeyDistricts";

export const COUNTRY_CITIES: Record<string, string[]> = {
  "+90": [
    "Adana", "Adıyaman", "Afyonkarahisar", "Ağrı", "Aksaray", "Amasya", "Ankara", "Antalya", "Ardahan",
    "Artvin", "Aydın", "Balıkesir", "Bartın", "Batman", "Bayburt", "Bilecik", "Bingöl", "Bitlis",
    "Bolu", "Burdur", "Bursa", "Çanakkale", "Çankırı", "Çorum", "Denizli", "Diyarbakır", "Düzce",
    "Edirne", "Elazığ", "Erzincan", "Erzurum", "Eskişehir", "Gaziantep", "Giresun", "Gümüşhane",
    "Hakkari", "Hatay", "Iğdır", "Isparta", "İstanbul", "İzmir", "Kahramanmaraş", "Karabük", "Karaman",
    "Kars", "Kastamonu", "Kayseri", "Kırıkkale", "Kırklareli", "Kırşehir", "Kilis", "Kocaeli", "Konya",
    "Kütahya", "Malatya", "Manisa", "Mardin", "Mersin", "Muğla", "Muş", "Nevşehir", "Niğde", "Ordu",
    "Osmaniye", "Rize", "Sakarya", "Samsun", "Şanlıurfa", "Siirt", "Sinop", "Sivas", "Şırnak",
    "Tekirdağ", "Tokat", "Trabzon", "Tunceli", "Uşak", "Van", "Yalova", "Yozgat", "Zonguldak"
  ],
  "+994": ["Bakü", "Gence", "Sumgayıt", "Şeki", "Lenkeran", "Mingəçevir", "Nahçıvan"],
  "+49": ["Berlin", "Hamburg", "Münih", "Köln", "Frankfurt", "Stuttgart", "Düsseldorf"],
  "+359": ["Sofya", "Filibe", "Varna", "Burgaz", "Rusçuk", "Eski Zağra"],
  "+995": ["Tiflis", "Batum", "Kutaisi", "Rustavi", "Gori", "Zugdidi"]
};

export { TURKEY_DISTRICTS };

export function getDistrictOptions(countryCode: string, city: string) {
  if (countryCode !== "+90" || !city) {
    return [];
  }

  return TURKEY_DISTRICTS[city] ?? [];
}
