import { app } from "../backend/dist/app.js";

let server;
let BASE_URL = process.env.SMOKE_BASE_URL ?? null;

async function request(path, options = {}) {
  const response = await fetch(`${BASE_URL}${path}`, options);
  const contentType = response.headers.get("content-type") ?? "";
  const payload = contentType.includes("application/json") ? await response.json() : await response.text();

  if (!response.ok) {
    throw new Error(`${options.method ?? "GET"} ${path} failed: ${response.status} ${JSON.stringify(payload)}`);
  }

  return payload;
}

async function login(email, password) {
  const payload = await request("/auth/login", {
    method: "POST",
    headers: {
      "content-type": "application/json"
    },
    body: JSON.stringify({ email, password })
  });

  return payload.data.token;
}

async function main() {
  if (!BASE_URL) {
    server = await new Promise((resolve) => {
      const instance = app.listen(0, "127.0.0.1", () => resolve(instance));
    });

    const address = server.address();
    if (!address || typeof address === "string") {
      throw new Error("Smoke test geçici sunucusu başlatılamadı.");
    }

    BASE_URL = `http://127.0.0.1:${address.port}/api/v1`;
  }

  try {
    const health = await request("/health");
    if (!health.success) {
      throw new Error("Health check başarısız.");
    }

    const adminToken = await login("admin@example.com", "123456");
    const customerToken = await login("customer@example.com", "123456");
    const managerToken = await login("manager@example.com", "123456");

    const [roles, users, dashboard, notifications, summary, excelExport] = await Promise.all([
      request("/roles", {
        headers: { Authorization: `Bearer ${adminToken}` }
      }),
      request("/users", {
        headers: { Authorization: `Bearer ${adminToken}` }
      }),
      request("/dashboard/customer", {
        headers: { Authorization: `Bearer ${customerToken}` }
      }),
      request("/notifications", {
        headers: { Authorization: `Bearer ${customerToken}` }
      }),
      request("/reports/summary", {
        headers: { Authorization: `Bearer ${managerToken}` }
      }),
      fetch(`${BASE_URL}/reports/export/excel`, {
        headers: { Authorization: `Bearer ${managerToken}` }
      })
    ]);

    if (!excelExport.ok) {
      throw new Error(`GET /reports/export/excel failed: ${excelExport.status}`);
    }

    console.log(
      JSON.stringify(
        {
        health: health.message,
        roleCount: roles.data.length,
        userCount: users.data.length,
        customerDashboardKeys: Object.keys(dashboard.data ?? {}),
        notificationCount: notifications.data.length,
        reportSummaryKeys: Object.keys(summary.data ?? {}),
        excelContentType: excelExport.headers.get("content-type")
      },
        null,
        2
      )
    );
  } finally {
    await new Promise((resolve, reject) => {
      if (!server) {
        resolve();
        return;
      }

      server.close((error) => {
        if (error) {
          reject(error);
          return;
        }

        resolve();
      });
    });
  }
}

main().catch((error) => {
  console.error(error.message);
  process.exit(1);
});
