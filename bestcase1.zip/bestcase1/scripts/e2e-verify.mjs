import { randomUUID } from "node:crypto";

import pg from "pg";

import { app } from "../backend/dist/app.js";

const { Client } = pg;

let server;
let BASE_URL = process.env.E2E_BASE_URL ?? null;
const startedAt = new Date();

function assert(condition, message) {
  if (!condition) {
    throw new Error(message);
  }
}

async function startServerIfNeeded() {
  if (BASE_URL) {
    return;
  }

  server = await new Promise((resolve) => {
    const instance = app.listen(0, "127.0.0.1", () => resolve(instance));
  });

  const address = server.address();
  if (!address || typeof address === "string") {
    throw new Error("E2E doğrulama için geçici sunucu başlatılamadı.");
  }

  BASE_URL = `http://127.0.0.1:${address.port}/api/v1`;
}

async function stopServer() {
  await new Promise((resolve, reject) => {
    if (!server) {
      resolve();
      return;
    }

    server.close((error) => {
      if (error) {
        reject(error);
        return;
      }

      resolve();
    });
  });
}

async function request(path, { method = "GET", token, json, expectStatus = 200 } = {}) {
  const response = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(json ? { "content-type": "application/json" } : {})
    },
    body: json ? JSON.stringify(json) : undefined
  });

  const contentType = response.headers.get("content-type") ?? "";
  const payload = contentType.includes("application/json") ? await response.json() : await response.text();

  if (response.status !== expectStatus) {
    throw new Error(
      `${method} ${path} beklenen ${expectStatus}, gelen ${response.status}: ${JSON.stringify(payload)}`
    );
  }

  return payload;
}

async function login(email, password) {
  const payload = await request("/auth/login", {
    method: "POST",
    json: { email, password }
  });

  return payload.data.token;
}

async function sql(client, text, params = []) {
  const result = await client.query(text, params);
  return result.rows;
}

async function main() {
  await startServerIfNeeded();

  const client = new Client({ connectionString: process.env.DATABASE_URL });
  await client.connect();

  const runId = randomUUID().slice(0, 8);
  const tempPassword = "654321";
  const demoCustomerPhone = "+90 555 100 1001";
  const demoSmsCode = "1111";
  const created = {
    appraisalId: null,
    vehicleId: null,
    negotiationId: null,
    creditCalculationId: null,
    appointmentId: null,
    operationIds: [],
    tempCustomerUserId: null,
    tempUserId: null
  };

  try {
    const health = await request("/health");
    assert(health.success === true, "Health check başarısız.");

    const tokens = {
      customer: await login("customer@example.com", "123456"),
      sales: await login("sales@example.com", "123456"),
      technician: await login("technician@example.com", "123456"),
      serviceManager: await login("servicemanager@example.com", "123456"),
      manager: await login("manager@example.com", "123456"),
      admin: await login("admin@example.com", "123456")
    };

    const me = await request("/auth/me", { token: tokens.customer });
    assert(me.data.role === "customer", "auth/me rol doğrulaması başarısız.");

    await request("/users", { token: tokens.customer, expectStatus: 403 });

    const forgot = await request("/auth/forgot-password", {
      method: "POST",
      json: { phone: demoCustomerPhone }
    });
    assert(forgot.data.resetToken, "Şifre sıfırlama token üretimi başarısız.");

    await request("/auth/reset-password", {
      method: "POST",
      json: {
        token: forgot.data.resetToken,
        smsCode: demoSmsCode,
        newPassword: tempPassword,
        confirmPassword: tempPassword
      }
    });
    tokens.customer = await login("customer@example.com", tempPassword);

    const revertForgot = await request("/auth/forgot-password", {
      method: "POST",
      json: { phone: demoCustomerPhone }
    });
    await request("/auth/reset-password", {
      method: "POST",
      json: {
        token: revertForgot.data.resetToken,
        smsCode: demoSmsCode,
        newPassword: "123456",
        confirmPassword: "123456"
      }
    });
    tokens.customer = await login("customer@example.com", "123456");

    const tempCustomerEmail = `e2e-customer-${runId}@example.com`;
    await request("/auth/register", {
      method: "POST",
      json: {
        fullName: "E2E Temp Customer",
        email: tempCustomerEmail,
        password: "123456",
        phone: "+90 555 111 2222",
        district: "İzmit",
        city: "Kocaeli"
      },
      expectStatus: 201
    });
    tokens.customer = await login(tempCustomerEmail, "123456");
    const tempCustomerMe = await request("/auth/me", { token: tokens.customer });
    created.tempCustomerUserId = tempCustomerMe.data.id;

    const profile = await request("/customers/me/profile", { token: tokens.customer });
    const profilePhone = `+90 555 200 ${runId.slice(0, 4)}`;
    await request("/customers/me/profile", {
      method: "PUT",
      token: tokens.customer,
      json: {
        fullName: profile.data.full_name,
        phone: profilePhone,
        address: profile.data.address,
        city: profile.data.city
      }
    });
    const updatedProfile = await request("/customers/me/profile", { token: tokens.customer });
    assert(updatedProfile.data.phone === profilePhone, "Profil güncellemesi veritabanına yansımadı.");

    const users = await request("/users", { token: tokens.admin });
    const roles = await request("/roles", { token: tokens.admin });
    const technician = users.data.find((row) => row.email === "technician@example.com");
    const customerRole = roles.data.find((row) => row.name === "customer");
    assert(technician?.id, "Teknisyen kullanıcı bulunamadı.");
    assert(customerRole?.id, "Customer role bulunamadı.");

    const vin = `VIN${Date.now()}${runId}`.slice(0, 17);
    const plate = `TMP${runId.toUpperCase()}`;

    const appraisal = await request("/appraisals", {
      method: "POST",
      token: tokens.customer,
      json: {
        brand: "Toyota",
        model: "Corolla",
        year: 2017,
        mileage: 250001,
        plate,
        vin,
        category: "sedan",
        expectedSellingPrice: 950000
      },
      expectStatus: 201
    });
    created.appraisalId = appraisal.data.appraisalId;
    created.vehicleId = appraisal.data.vehicleId;

    await request(`/appraisals/${created.appraisalId}/damage-details`, {
      method: "POST",
      token: tokens.customer,
      json: {
        damages: [
          { vehiclePart: "hood", damageType: "damaged", note: "E2E hasar testi" },
          { vehiclePart: "roof", damageType: "painted", note: "E2E boya testi" }
        ]
      }
    });

    const preliminaryOffer = await request(`/appraisals/${created.appraisalId}/preliminary-offer`, {
      token: tokens.customer
    });
    assert(preliminaryOffer.data.calculated_offer, "Ön teklif oluşturulamadı.");

    const appraisalRow = (
      await sql(client, "SELECT status, calculated_offer FROM appraisal_requests WHERE id = $1", [created.appraisalId])
    )[0];
    assert(appraisalRow?.calculated_offer, "Ekspertiz kaydı veritabanında hesaplanmamış.");

    const salesAppraisals = await request("/appraisals", { token: tokens.sales });
    assert(
      salesAppraisals.data.some((row) => row.id === created.appraisalId),
      "Satış danışmanı yeni ekspertiz kaydını göremiyor."
    );

    await request(`/appraisals/${created.appraisalId}/approve`, {
      method: "POST",
      token: tokens.customer,
      json: { note: "yetkisiz test" },
      expectStatus: 403
    });

    await request(`/appraisals/${created.appraisalId}/approve`, {
      method: "POST",
      token: tokens.manager,
      json: { note: "E2E onayı" }
    });
    const approvedAppraisal = (
      await sql(client, "SELECT status FROM appraisal_requests WHERE id = $1", [created.appraisalId])
    )[0];
    assert(approvedAppraisal?.status === "approved", "Yönetici ekspertiz onayı veritabanına kaydedilmedi.");

    const negotiation = await request("/negotiations", {
      method: "POST",
      token: tokens.customer,
      json: { appraisalRequestId: created.appraisalId },
      expectStatus: 201
    });
    created.negotiationId = negotiation.data.negotiationId;

    await request(`/negotiations/${created.negotiationId}/customer-expectation`, {
      method: "POST",
      token: tokens.customer,
      json: { expectedPrice: 925000 }
    });
    await request(`/negotiations/${created.negotiationId}/request-meeting`, {
      method: "POST",
      token: tokens.customer
    });

    const negotiationDetail = await request(`/negotiations/${created.negotiationId}`, {
      token: tokens.manager
    });

    await request(`/negotiations/${created.negotiationId}/settings`, {
      method: "PATCH",
      token: tokens.manager,
      json: {
        maxAuthorizedOffer: Number(negotiationDetail.data.current_dealer_offer) + 50000,
        incrementAmount: 10000,
        autoNegotiationEnabled: true
      }
    });

    const salesNegotiations = await request("/negotiations", { token: tokens.sales });
    assert(
      salesNegotiations.data.some((row) => row.id === created.negotiationId),
      "Satış danışmanı yeni pazarlığı göremiyor."
    );

    const negotiationMessages = await sql(
      client,
      "SELECT message_type FROM negotiation_messages WHERE negotiation_id = $1 ORDER BY id",
      [created.negotiationId]
    );
    assert(
      negotiationMessages.some((row) => row.message_type === "meeting_request"),
      "Toplantı talebi pazarlık geçmişine kaydedilmedi."
    );

    const credit = await request("/credit-calculations", {
      method: "POST",
      token: tokens.customer,
      json: {
        vehicleId: created.vehicleId,
        vehiclePrice: 1000000,
        downPayment: 250000,
        maturityMonths: 12,
        monthlyInterestRate: 3.19
      },
      expectStatus: 201
    });
    created.creditCalculationId = credit.data.id;
    const creditList = await request("/credit-calculations", { token: tokens.customer });
    assert(
      creditList.data.some((row) => Number(row.id) === Number(created.creditCalculationId)),
      "Kredi hesaplama kaydı müşteri tarafından listelenemiyor."
    );

    const appointmentDatetime = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().slice(0, 16);
    const appointment = await request("/service/appointments", {
      method: "POST",
      token: tokens.customer,
      json: {
        vehicleId: created.vehicleId,
        serviceType: "maintenance",
        appointmentDatetime,
        complaintDescription: "E2E servis testi",
        estimatedPrice: 1500
      },
      expectStatus: 201
    });
    created.appointmentId = appointment.data.appointmentId;

    const managerAppointments = await request("/service/appointments", { token: tokens.serviceManager });
    assert(
      managerAppointments.data.some((row) => Number(row.id) === Number(created.appointmentId)),
      "Servis müdürü yeni randevuyu göremiyor."
    );

    await request(`/service/appointments/${created.appointmentId}/assign-technician`, {
      method: "PATCH",
      token: tokens.serviceManager,
      json: { technicianId: technician.id }
    });

    const technicianAppointments = await request("/service/appointments", { token: tokens.technician });
    assert(
      technicianAppointments.data.some((row) => Number(row.id) === Number(created.appointmentId)),
      "Teknisyen atanmış randevuyu göremiyor."
    );

    const normalOperation = await request(`/service/appointments/${created.appointmentId}/operations`, {
      method: "POST",
      token: tokens.technician,
      json: {
        operationName: "Yağ değişimi",
        operationType: "maintenance",
        partPrice: 300,
        laborPrice: 200,
        isCriticalSafety: false,
        note: "E2E normal operasyon"
      },
      expectStatus: 201
    });

    const criticalOperation = await request(`/service/appointments/${created.appointmentId}/operations`, {
      method: "POST",
      token: tokens.technician,
      json: {
        operationName: "Fren balata değişimi",
        operationType: "safety",
        partPrice: 600,
        laborPrice: 250,
        isCriticalSafety: true,
        note: "E2E kritik operasyon"
      },
      expectStatus: 201
    });

    created.operationIds.push(normalOperation.data.id, criticalOperation.data.id);

    const customerOperations = await request(
      `/service/appointments/${created.appointmentId}/operations`,
      { token: tokens.customer }
    );
    assert(customerOperations.data.length >= 2, "Müşteri kendi servis operasyonlarını göremiyor.");

    await request(`/service/operations/${normalOperation.data.id}/customer-approve`, {
      method: "POST",
      token: tokens.customer
    });
    const rejectedCritical = await request(`/service/operations/${criticalOperation.data.id}/customer-reject`, {
      method: "POST",
      token: tokens.customer
    });
    assert(
      rejectedCritical.data.warning?.includes("Kritik güvenlik"),
      "Kritik güvenlik uyarısı dönmedi."
    );

    const criticalCases = await request("/service/critical-cases", { token: tokens.serviceManager });
    assert(
      criticalCases.data.some((row) => Number(row.id) === Number(criticalOperation.data.id)),
      "Servis müdürü kritik vakayı göremiyor."
    );

    await request(`/service/operations/${criticalOperation.data.id}/review`, {
      method: "POST",
      token: tokens.serviceManager,
      json: { decision: "approved", note: "Teslime yönetici onayı" }
    });
    const readyForCompletion = (
      await sql(client, "SELECT status FROM service_appointments WHERE id = $1", [created.appointmentId])
    )[0];
    assert(
      readyForCompletion?.status === "in_progress",
      "Müşteri/yönetici onayları tamamlanınca randevu teknisyen ekranında işlem durumuna geçmedi."
    );

    const completion = await request(
      `/service/appointments/${created.appointmentId}/complete-approved-operations`,
      {
        method: "POST",
        token: tokens.technician
      }
    );
    assert(completion.data.status === "completed", "Servis randevusu tamamlanamadı.");

    const appointmentRow = (
      await sql(client, "SELECT status FROM service_appointments WHERE id = $1", [created.appointmentId])
    )[0];
    assert(appointmentRow?.status === "completed", "Servis tamamlanma durumu veritabanına kaydedilmedi.");

    await request(`/negotiations/${created.negotiationId}/accept`, {
      method: "POST",
      token: tokens.customer
    });
    const acceptedVehicle = (
      await sql(client, "SELECT status, purchase_price FROM vehicles WHERE id = $1", [created.vehicleId])
    )[0];
    assert(acceptedVehicle?.status === "acquired", "Kabul edilen pazarlık aracı bayi stok adayına almadı.");
    const activeListingAfterAcquisition = (
      await sql(client, "SELECT status FROM sales_listings WHERE vehicle_id = $1 AND status <> 'cancelled' ORDER BY id DESC LIMIT 1", [created.vehicleId])
    )[0];
    assert(!activeListingAfterAcquisition, "Bayi tarafından alınan araç doğrudan satılmış ilan gibi görünmemeli.");

    const tempUserEmail = `e2e-${runId}@example.com`;
    const tempUser = await request("/users", {
      method: "POST",
      token: tokens.admin,
      json: {
        fullName: "E2E Temp User",
        email: tempUserEmail,
        password: "123456",
        phone: "+90 555 333 4444",
        roleId: customerRole.id,
        isActive: true
      },
      expectStatus: 201
    });
    created.tempUserId = tempUser.data.id;

    await request(`/users/${created.tempUserId}`, {
      method: "PUT",
      token: tokens.admin,
      json: {
        fullName: "E2E Temp User Updated",
        roleId: customerRole.id,
        isActive: false,
        phone: "+90 555 999 8888"
      }
    });

    const updatedUser = (
      await sql(client, "SELECT full_name, is_active FROM users WHERE id = $1", [created.tempUserId])
    )[0];
    assert(updatedUser?.full_name === "E2E Temp User Updated", "Admin kullanıcı güncellemesi kaydedilmedi.");
    assert(updatedUser?.is_active === false, "Admin aktif/pasif güncellemesi kaydedilmedi.");

    const rolePermissions = await request("/roles/permissions", { token: tokens.admin });
    const adminPermissions = rolePermissions.data.find((row) => row.role === "admin");
    assert(adminPermissions?.can_delete === true, "Rol yetki matrisi beklenen boolean alanları dönmüyor.");

    console.log(
      JSON.stringify(
        {
          ok: true,
          runId,
          verified: [
            "auth_login_me_reset",
            "customer_profile_update",
            "appraisal_create_damage_offer_manager_approval",
            "cross_role_appraisal_visibility",
            "negotiation_create_counter_meeting_visibility",
            "finance_calculation_persistence",
            "service_create_assign_operate_review_complete",
            "admin_user_create_update",
            "role_permission_matrix",
            "api_role_protection"
          ]
        },
        null,
        2
      )
    );
  } finally {
    await sql(client, "DELETE FROM service_operation_reviews WHERE service_operation_id = ANY($1::int[])", [created.operationIds]);
    if (created.appointmentId) {
      await sql(client, "DELETE FROM service_operations WHERE appointment_id = $1", [created.appointmentId]);
      await sql(client, "DELETE FROM service_appointments WHERE id = $1", [created.appointmentId]);
    }
    if (created.negotiationId) {
      await sql(client, "DELETE FROM negotiation_messages WHERE negotiation_id = $1", [created.negotiationId]);
      await sql(client, "DELETE FROM negotiations WHERE id = $1", [created.negotiationId]);
    }
    if (created.creditCalculationId) {
      await sql(client, "DELETE FROM credit_calculations WHERE id = $1", [created.creditCalculationId]);
    }
    if (created.appraisalId) {
      await sql(client, "DELETE FROM damage_details WHERE appraisal_request_id = $1", [created.appraisalId]);
      await sql(client, "DELETE FROM appraisal_requests WHERE id = $1", [created.appraisalId]);
    }
    if (created.vehicleId) {
      await sql(client, "DELETE FROM simulated_tramer_records WHERE vehicle_id = $1", [created.vehicleId]);
      await sql(client, "DELETE FROM vehicles WHERE id = $1", [created.vehicleId]);
    }
    if (created.tempUserId) {
      await sql(client, "DELETE FROM password_reset_tokens WHERE user_id = $1", [created.tempUserId]);
      await sql(client, "DELETE FROM notifications WHERE user_id = $1", [created.tempUserId]);
      await sql(client, "DELETE FROM audit_logs WHERE user_id = $1", [created.tempUserId]);
      await sql(client, "DELETE FROM users WHERE id = $1", [created.tempUserId]);
    }
    if (created.tempCustomerUserId) {
      await sql(client, "DELETE FROM password_reset_tokens WHERE user_id = $1", [created.tempCustomerUserId]);
      await sql(client, "DELETE FROM notifications WHERE user_id = $1", [created.tempCustomerUserId]);
      await sql(client, "DELETE FROM audit_logs WHERE user_id = $1", [created.tempCustomerUserId]);
      await sql(client, "DELETE FROM users WHERE id = $1", [created.tempCustomerUserId]);
    }

    await sql(client, "DELETE FROM password_reset_tokens WHERE created_at >= $1", [startedAt.toISOString()]);
    await sql(client, "DELETE FROM notifications WHERE created_at >= $1", [startedAt.toISOString()]);
    await sql(client, "DELETE FROM audit_logs WHERE created_at >= $1", [startedAt.toISOString()]);

    await client.end();
    await stopServer();
  }
}

main().catch((error) => {
  console.error(error.message);
  process.exit(1);
});
