INSERT INTO users (full_name, email, password_hash, phone, role_id, is_active)
VALUES
  ('Customer', 'customer@example.com', '$2b$10$Vh9K6bp0oU/dzdHHhj.BlOBXs5CXtU8fBwbci7XPpOEG0yOgQ66RW', '+90 555 100 1001', (SELECT id FROM roles WHERE name = 'customer'), TRUE),
  ('Sales Agent', 'sales@example.com', '$2b$10$Vh9K6bp0oU/dzdHHhj.BlOBXs5CXtU8fBwbci7XPpOEG0yOgQ66RW', '+90 555 100 1002', (SELECT id FROM roles WHERE name = 'sales_agent'), TRUE),
  ('Technician 1', 'technician@example.com', '$2b$10$Vh9K6bp0oU/dzdHHhj.BlOBXs5CXtU8fBwbci7XPpOEG0yOgQ66RW', '+90 555 100 1003', (SELECT id FROM roles WHERE name = 'technician'), TRUE),
  ('Technician 2', 'technician02@example.com', '$2b$10$Vh9K6bp0oU/dzdHHhj.BlOBXs5CXtU8fBwbci7XPpOEG0yOgQ66RW', '+90 555 100 1102', (SELECT id FROM roles WHERE name = 'technician'), TRUE),
  ('Technician 3', 'technician03@example.com', '$2b$10$Vh9K6bp0oU/dzdHHhj.BlOBXs5CXtU8fBwbci7XPpOEG0yOgQ66RW', '+90 555 100 1103', (SELECT id FROM roles WHERE name = 'technician'), TRUE),
  ('Technician 4', 'technician04@example.com', '$2b$10$Vh9K6bp0oU/dzdHHhj.BlOBXs5CXtU8fBwbci7XPpOEG0yOgQ66RW', '+90 555 100 1104', (SELECT id FROM roles WHERE name = 'technician'), TRUE),
  ('Technician 5', 'technician05@example.com', '$2b$10$Vh9K6bp0oU/dzdHHhj.BlOBXs5CXtU8fBwbci7XPpOEG0yOgQ66RW', '+90 555 100 1105', (SELECT id FROM roles WHERE name = 'technician'), TRUE),
  ('Service Manager', 'servicemanager@example.com', '$2b$10$Vh9K6bp0oU/dzdHHhj.BlOBXs5CXtU8fBwbci7XPpOEG0yOgQ66RW', '+90 555 100 1004', (SELECT id FROM roles WHERE name = 'service_manager'), TRUE),
  ('Authorized Manager', 'manager@example.com', '$2b$10$Vh9K6bp0oU/dzdHHhj.BlOBXs5CXtU8fBwbci7XPpOEG0yOgQ66RW', '+90 555 100 1005', (SELECT id FROM roles WHERE name = 'authorized_manager'), TRUE),
  ('Admin', 'admin@example.com', '$2b$10$Vh9K6bp0oU/dzdHHhj.BlOBXs5CXtU8fBwbci7XPpOEG0yOgQ66RW', '+90 555 100 1006', (SELECT id FROM roles WHERE name = 'admin'), TRUE)
ON CONFLICT (email) DO NOTHING;

INSERT INTO customers (user_id, national_id, address, city, phone)
SELECT
  u.id,
  '11111111111',
  'Örnek Mahallesi No:1',
  'Kocaeli',
  '+90 555 100 1001'
FROM users u
JOIN roles r ON r.id = u.role_id
WHERE r.name = 'customer'
  AND NOT EXISTS (
    SELECT 1 FROM customers c WHERE c.user_id = u.id
  );

INSERT INTO vehicles (owner_customer_id, plate, vin, brand, model, year, mileage, category, package, color, purchase_price, list_price, status)
SELECT
  c.id,
  '41 SAP 001',
  'WVWZZZ1JZXW000001',
  'Volkswagen',
  'Passat',
  2020,
  84500,
  'sedan',
  'Business',
  'Lacivert',
  870000,
  975000,
  'in_appraisal'
FROM customers c
JOIN users u ON u.id = c.user_id
WHERE u.email = 'customer@example.com'
  AND NOT EXISTS (
    SELECT 1 FROM vehicles v WHERE v.vin = 'WVWZZZ1JZXW000001'
  );

INSERT INTO vehicles (owner_customer_id, plate, vin, brand, model, year, mileage, category, package, color, purchase_price, list_price, status)
SELECT
  NULL,
  '34 SAP 002',
  'WBAAA31020F000002',
  'BMW',
  '320i',
  2022,
  24000,
  'sedan',
  'M Sport',
  'Beyaz',
  1450000,
  1615000,
  'for_sale'
WHERE NOT EXISTS (
  SELECT 1 FROM vehicles v WHERE v.vin = 'WBAAA31020F000002'
);

INSERT INTO simulated_tramer_records (vehicle_id, market_value, accident_record, owner_count, heavy_damage, customs_problem, damage_history_text)
SELECT
  v.id,
  925000,
  TRUE,
  2,
  FALSE,
  FALSE,
  'Ön tampon ve sağ çamurluk geçmiş hasar kaydı bulunmaktadır.'
FROM vehicles v
WHERE v.vin = 'WVWZZZ1JZXW000001'
  AND NOT EXISTS (
    SELECT 1 FROM simulated_tramer_records str WHERE str.vehicle_id = v.id
  );

INSERT INTO simulated_tramer_records (vehicle_id, market_value, accident_record, owner_count, heavy_damage, customs_problem, damage_history_text)
SELECT
  v.id,
  1590000,
  FALSE,
  1,
  FALSE,
  FALSE,
  'Temiz kayıt.'
FROM vehicles v
WHERE v.vin = 'WBAAA31020F000002'
  AND NOT EXISTS (
    SELECT 1 FROM simulated_tramer_records str WHERE str.vehicle_id = v.id
  );

INSERT INTO appraisal_requests (
  customer_id,
  vehicle_id,
  status,
  expected_selling_price,
  damage_score,
  damage_percentage,
  tramer_value,
  calculated_offer,
  requires_manager_approval,
  approval_reason,
  manager_id,
  manager_decision,
  manager_note
)
SELECT
  c.id,
  v.id,
  'pending_manager_approval',
  910000,
  17,
  13.08,
  925000,
  684500,
  TRUE,
  'TRAMER kaza kaydı mevcut olduğu için yönetici onayı gerekiyor.',
  u.id,
  NULL,
  NULL
FROM customers c
JOIN users cu ON cu.id = c.user_id
JOIN vehicles v ON v.owner_customer_id = c.id
LEFT JOIN users u ON u.email = 'manager@example.com'
WHERE cu.email = 'customer@example.com'
  AND v.vin = 'WVWZZZ1JZXW000001'
  AND NOT EXISTS (
    SELECT 1 FROM appraisal_requests ar WHERE ar.vehicle_id = v.id
  );

INSERT INTO damage_details (appraisal_request_id, vehicle_part, damage_type, damage_point, note)
SELECT ar.id, 'front_bumper', 'painted', 2, 'Lokal boya sonrası yüzey düzeltme izi'
FROM appraisal_requests ar
JOIN vehicles v ON v.id = ar.vehicle_id
WHERE v.vin = 'WVWZZZ1JZXW000001'
  AND NOT EXISTS (
    SELECT 1 FROM damage_details dd WHERE dd.appraisal_request_id = ar.id AND dd.vehicle_part = 'front_bumper'
  );

INSERT INTO damage_details (appraisal_request_id, vehicle_part, damage_type, damage_point, note)
SELECT ar.id, 'right_fender', 'replaced', 3, 'Parça değişimi müşteri beyanına göre işlendi'
FROM appraisal_requests ar
JOIN vehicles v ON v.id = ar.vehicle_id
WHERE v.vin = 'WVWZZZ1JZXW000001'
  AND NOT EXISTS (
    SELECT 1 FROM damage_details dd WHERE dd.appraisal_request_id = ar.id AND dd.vehicle_part = 'right_fender'
  );

INSERT INTO damage_details (appraisal_request_id, vehicle_part, damage_type, damage_point, note)
SELECT ar.id, 'rear_bumper', 'damaged', 10, 'Derin çizik ve çatlak'
FROM appraisal_requests ar
JOIN vehicles v ON v.id = ar.vehicle_id
WHERE v.vin = 'WVWZZZ1JZXW000001'
  AND NOT EXISTS (
    SELECT 1 FROM damage_details dd WHERE dd.appraisal_request_id = ar.id AND dd.vehicle_part = 'rear_bumper'
  );

INSERT INTO negotiations (
  appraisal_request_id,
  customer_id,
  system_offer,
  customer_expected_price,
  current_dealer_offer,
  max_authorized_offer,
  increment_amount,
  auto_negotiation_enabled,
  status,
  result
)
SELECT
  ar.id,
  ar.customer_id,
  684500,
  760000,
  700000,
  735000,
  10000,
  TRUE,
  'pending_manager_review',
  NULL
FROM appraisal_requests ar
JOIN vehicles v ON v.id = ar.vehicle_id
WHERE v.vin = 'WVWZZZ1JZXW000001'
  AND NOT EXISTS (
    SELECT 1 FROM negotiations n WHERE n.appraisal_request_id = ar.id
  );

INSERT INTO negotiation_messages (negotiation_id, sender_user_id, sender_type, message_type, offered_price, note)
SELECT
  n.id,
  NULL,
  'system',
  'initial_offer',
  684500,
  'Sistem ilk ön alım teklifini oluşturdu.'
FROM negotiations n
WHERE NOT EXISTS (
  SELECT 1 FROM negotiation_messages nm WHERE nm.negotiation_id = n.id AND nm.message_type = 'initial_offer'
);

INSERT INTO service_appointments (
  customer_id,
  vehicle_id,
  service_type,
  appointment_datetime,
  complaint_description,
  estimated_price,
  status,
  assigned_technician_id
)
SELECT
  c.id,
  v.id,
  'check_up',
  NOW() + INTERVAL '2 day',
  'Uzun yolda ses ve fren performansı kontrolü talep edildi.',
  4500,
  'waiting_customer_approval',
  u.id
FROM customers c
JOIN users cu ON cu.id = c.user_id
JOIN vehicles v ON v.owner_customer_id = c.id
LEFT JOIN users u ON u.email = 'technician@example.com'
WHERE cu.email = 'customer@example.com'
  AND v.vin = 'WVWZZZ1JZXW000001'
  AND NOT EXISTS (
    SELECT 1 FROM service_appointments sa WHERE sa.vehicle_id = v.id
  );

INSERT INTO service_operations (
  appointment_id,
  technician_id,
  operation_name,
  operation_type,
  part_price,
  labor_price,
  total_price,
  is_critical_safety,
  customer_approval_status,
  manager_review_status,
  note
)
SELECT
  sa.id,
  u.id,
  'Fren balatası değişimi',
  'checkup_repair',
  2800,
  900,
  3700,
  TRUE,
  'pending',
  'not_required',
  'Güvenlik açısından kritik seviye aşınma mevcut.'
FROM service_appointments sa
LEFT JOIN users u ON u.email = 'technician@example.com'
JOIN vehicles v ON v.id = sa.vehicle_id
WHERE v.vin = 'WVWZZZ1JZXW000001'
  AND NOT EXISTS (
    SELECT 1 FROM service_operations so WHERE so.appointment_id = sa.id AND so.operation_name = 'Fren balatası değişimi'
  );

INSERT INTO service_operations (
  appointment_id,
  technician_id,
  operation_name,
  operation_type,
  part_price,
  labor_price,
  total_price,
  is_critical_safety,
  customer_approval_status,
  manager_review_status,
  note
)
SELECT
  sa.id,
  u.id,
  'Motor yağı ve filtre değişimi',
  'maintenance',
  1200,
  650,
  1850,
  FALSE,
  'approved',
  'not_required',
  'Periyodik bakım kapsamında önerildi.'
FROM service_appointments sa
LEFT JOIN users u ON u.email = 'technician@example.com'
JOIN vehicles v ON v.id = sa.vehicle_id
WHERE v.vin = 'WVWZZZ1JZXW000001'
  AND NOT EXISTS (
    SELECT 1 FROM service_operations so WHERE so.appointment_id = sa.id AND so.operation_name = 'Motor yağı ve filtre değişimi'
  );

INSERT INTO credit_calculations (
  customer_id,
  vehicle_id,
  vehicle_price,
  down_payment,
  down_payment_rate,
  maturity_months,
  monthly_interest_rate,
  financed_amount,
  monthly_payment,
  total_payment,
  total_interest
)
SELECT
  c.id,
  v.id,
  975000,
  250000,
  25.64,
  24,
  3.19,
  725000,
  43825.76,
  1051818.24,
  326818.24
FROM customers c
JOIN users u ON u.id = c.user_id
JOIN vehicles v ON v.owner_customer_id = c.id
WHERE u.email = 'customer@example.com'
  AND v.vin = 'WVWZZZ1JZXW000001'
  AND NOT EXISTS (
    SELECT 1 FROM credit_calculations cc WHERE cc.customer_id = c.id AND cc.vehicle_id = v.id
  );

INSERT INTO notifications (user_id, title, message, type, is_read)
SELECT u.id, 'Ön teklif hazır', 'Araç ekspertiz talebiniz için ön alım teklifi oluşturuldu.', 'in_app', FALSE
FROM users u
WHERE u.email = 'customer@example.com'
  AND NOT EXISTS (
    SELECT 1 FROM notifications n WHERE n.user_id = u.id AND n.title = 'Ön teklif hazır'
  );

INSERT INTO notifications (user_id, title, message, type, is_read)
SELECT u.id, 'Kritik ekspertiz onayı', 'TRAMER kayıtlı bir başvuru yönetici onayı bekliyor.', 'in_app', FALSE
FROM users u
WHERE u.email = 'manager@example.com'
  AND NOT EXISTS (
    SELECT 1 FROM notifications n WHERE n.user_id = u.id AND n.title = 'Kritik ekspertiz onayı'
  );
