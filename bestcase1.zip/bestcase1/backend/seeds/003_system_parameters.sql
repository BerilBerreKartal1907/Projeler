INSERT INTO system_parameters (key, value, description, updated_by)
VALUES
  ('minimum_profit_rate', '12', 'Bayi minimum karlilik orani (%)', (SELECT id FROM users WHERE email = 'admin@example.com')),
  ('max_interest_rate', '4.5', 'Maksimum aylik faiz orani (%)', (SELECT id FROM users WHERE email = 'admin@example.com')),
  ('tramer_accident_discount_rate', '20', 'TRAMER kaza kaydi bulunan araclar icin otomatik iskonto (%)', (SELECT id FROM users WHERE email = 'admin@example.com')),
  ('high_mileage_limit', '200000', 'Yuksek kilometre esigi', (SELECT id FROM users WHERE email = 'admin@example.com')),
  ('high_damage_percentage_limit', '50', 'Yuksek hasar yuzdesi esigi', (SELECT id FROM users WHERE email = 'admin@example.com')),
  ('price_difference_manager_approval_rate', '20', 'Musteri beklentisi ile sistem teklifi arasindaki kritik fark yuzdesi', (SELECT id FROM users WHERE email = 'admin@example.com')),
  ('daily_maintenance_capacity', '12', 'Gunluk maintenance kapasitesi', (SELECT id FROM users WHERE email = 'admin@example.com')),
  ('daily_checkup_capacity', '8', 'Gunluk check-up kapasitesi', (SELECT id FROM users WHERE email = 'admin@example.com')),
  ('daily_accident_repair_capacity', '5', 'Gunluk accident repair kapasitesi', (SELECT id FROM users WHERE email = 'admin@example.com')),
  ('daily_modification_capacity', '2', 'Gunluk modification kapasitesi', (SELECT id FROM users WHERE email = 'admin@example.com')),
  ('damage_point_original', '0', 'Original parca hasar puani', (SELECT id FROM users WHERE email = 'admin@example.com')),
  ('damage_point_painted', '2', 'Boyalı parca hasar puani', (SELECT id FROM users WHERE email = 'admin@example.com')),
  ('damage_point_local_painted', '5', 'Lokal boyali parca hasar puani', (SELECT id FROM users WHERE email = 'admin@example.com')),
  ('damage_point_replaced', '3', 'Degisen parca hasar puani', (SELECT id FROM users WHERE email = 'admin@example.com')),
  ('damage_point_damaged', '10', 'Hasarlı parca hasar puani', (SELECT id FROM users WHERE email = 'admin@example.com'))
ON CONFLICT (key) DO UPDATE
SET
  value = EXCLUDED.value,
  description = EXCLUDED.description,
  updated_by = EXCLUDED.updated_by,
  updated_at = NOW();
