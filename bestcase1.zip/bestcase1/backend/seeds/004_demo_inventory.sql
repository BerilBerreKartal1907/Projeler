WITH sold_seed AS (
  SELECT
    gs,
    CASE gs % 5
      WHEN 0 THEN 'Renault'
      WHEN 1 THEN 'Opel'
      WHEN 2 THEN 'Toyota'
      WHEN 3 THEN 'Hyundai'
      ELSE 'Honda'
    END AS brand,
    CASE gs % 5
      WHEN 0 THEN 'Megane'
      WHEN 1 THEN 'Astra'
      WHEN 2 THEN 'Corolla'
      WHEN 3 THEN 'Elantra'
      ELSE 'Civic'
    END AS model,
    CASE gs % 5
      WHEN 0 THEN 'sedan'
      WHEN 1 THEN 'hatchback'
      WHEN 2 THEN 'sedan'
      WHEN 3 THEN 'sedan'
      ELSE 'sedan'
    END AS category,
    2017 + (gs % 7) AS year,
    35000 + (gs * 4200) AS mileage,
    720000 + (gs * 18000) AS purchase_price,
    910000 + (gs * 22000) AS sale_price
  FROM generate_series(1, 25) AS gs
),
inserted_sold AS (
  INSERT INTO vehicles (
    owner_customer_id,
    plate,
    vin,
    brand,
    model,
    year,
    mileage,
    category,
    package,
    color,
    purchase_price,
    list_price,
    status
  )
  SELECT
    NULL,
    format('34 SLD %03s', gs),
    format('DEMOSOLD%08s', gs),
    brand,
    model,
    year,
    mileage,
    category,
    'Demo Paket',
    CASE gs % 4
      WHEN 0 THEN 'Beyaz'
      WHEN 1 THEN 'Gri'
      WHEN 2 THEN 'Siyah'
      ELSE 'Mavi'
    END,
    purchase_price,
    sale_price,
    'sold'
  FROM sold_seed
  RETURNING id, vin
)
INSERT INTO sales_listings (vehicle_id, price, damage_score, status, created_at, updated_at)
SELECT
  v.id,
  s.sale_price,
  (s.gs % 8) * 2,
  'sold',
  NOW() - make_interval(days => 60 - s.gs),
  NOW() - make_interval(days => 30 - s.gs)
FROM sold_seed s
JOIN inserted_sold v ON v.vin = format('DEMOSOLD%08s', s.gs);

WITH acquired_seed AS (
  SELECT
    gs,
    CASE gs % 5
      WHEN 0 THEN 'Volkswagen'
      WHEN 1 THEN 'Peugeot'
      WHEN 2 THEN 'Skoda'
      WHEN 3 THEN 'Kia'
      ELSE 'Ford'
    END AS brand,
    CASE gs % 5
      WHEN 0 THEN 'Passat'
      WHEN 1 THEN '2008'
      WHEN 2 THEN 'Octavia'
      WHEN 3 THEN 'Sportage'
      ELSE 'Focus'
    END AS model,
    CASE gs % 5
      WHEN 0 THEN 'sedan'
      WHEN 1 THEN 'suv'
      WHEN 2 THEN 'sedan'
      WHEN 3 THEN 'suv'
      ELSE 'hatchback'
    END AS category,
    2018 + (gs % 6) AS year,
    28000 + (gs * 3900) AS mileage,
    680000 + (gs * 15000) AS purchase_price,
    845000 + (gs * 21000) AS target_sale_price
  FROM generate_series(1, 25) AS gs
),
inserted_acquired AS (
  INSERT INTO vehicles (
    owner_customer_id,
    plate,
    vin,
    brand,
    model,
    year,
    mileage,
    category,
    package,
    color,
    purchase_price,
    list_price,
    status
  )
  SELECT
    NULL,
    format('34 ACQ %03s', gs),
    format('DEMOACQ%09s', gs),
    brand,
    model,
    year,
    mileage,
    category,
    'Demo Paket',
    CASE gs % 4
      WHEN 0 THEN 'Kırmızı'
      WHEN 1 THEN 'Beyaz'
      WHEN 2 THEN 'Gri'
      ELSE 'Siyah'
    END,
    purchase_price,
    target_sale_price,
    'for_sale'
  FROM acquired_seed
  RETURNING id, vin
)
INSERT INTO sales_listings (vehicle_id, price, damage_score, status, created_at, updated_at)
SELECT
  v.id,
  a.target_sale_price,
  (a.gs % 6) * 2,
  'active',
  NOW() - make_interval(days => 20 - (a.gs % 10)),
  NOW() - make_interval(days => 5 - (a.gs % 4))
FROM acquired_seed a
JOIN inserted_acquired v ON v.vin = format('DEMOACQ%09s', a.gs);

WITH demo_context AS (
  SELECT
    (SELECT c.id FROM customers c JOIN users u ON u.id = c.user_id WHERE u.email = 'customer@example.com' LIMIT 1) AS customer_id,
    (SELECT u.id FROM users u WHERE u.email = 'technician@example.com' LIMIT 1) AS technician_1,
    (SELECT u.id FROM users u WHERE u.email = 'technician02@example.com' LIMIT 1) AS technician_2,
    (SELECT u.id FROM users u WHERE u.email = 'technician03@example.com' LIMIT 1) AS technician_3,
    (SELECT u.id FROM users u WHERE u.email = 'technician04@example.com' LIMIT 1) AS technician_4,
    (SELECT u.id FROM users u WHERE u.email = 'technician05@example.com' LIMIT 1) AS technician_5
),
service_seed AS (
  SELECT
    ROW_NUMBER() OVER (ORDER BY v.id) AS rn,
    v.id AS vehicle_id,
    v.brand,
    v.model
  FROM vehicles v
  WHERE v.vin LIKE 'DEMOSOLD%'
     OR v.vin LIKE 'DEMOACQ%'
  ORDER BY v.id
  LIMIT 18
)
INSERT INTO service_appointments (
  customer_id,
  vehicle_id,
  service_type,
  appointment_datetime,
  complaint_description,
  estimated_price,
  status,
  assigned_technician_id,
  created_at,
  updated_at
)
SELECT
  dc.customer_id,
  ss.vehicle_id,
  CASE ss.rn % 4
    WHEN 0 THEN 'maintenance'
    WHEN 1 THEN 'check_up'
    WHEN 2 THEN 'accident_repair'
    ELSE 'modification'
  END,
  NOW() - make_interval(days => (20 - ss.rn)::int),
  format('%s %s için demo servis kaydı', ss.brand, ss.model),
  2500 + (ss.rn * 350),
  CASE
    WHEN ss.rn <= 10 THEN 'completed'
    WHEN ss.rn <= 14 THEN 'waiting_customer_approval'
    ELSE 'assigned'
  END,
  CASE
    WHEN ss.rn % 5 = 1 THEN dc.technician_1
    WHEN ss.rn % 5 = 2 THEN dc.technician_2
    WHEN ss.rn % 5 = 3 THEN dc.technician_3
    WHEN ss.rn % 5 = 4 THEN dc.technician_4
    ELSE dc.technician_5
  END,
  NOW() - make_interval(days => (25 - ss.rn)::int),
  NOW() - make_interval(days => (18 - ss.rn)::int)
FROM service_seed ss
CROSS JOIN demo_context dc;

INSERT INTO service_operations (
  appointment_id,
  technician_id,
  operation_name,
  operation_type,
  part_price,
  labor_price,
  total_price,
  is_critical_safety,
  customer_approval_status,
  manager_review_status,
  note,
  created_at,
  updated_at
)
SELECT
  sa.id,
  sa.assigned_technician_id,
  CASE sa.service_type
    WHEN 'maintenance' THEN 'Periyodik bakım paketi'
    WHEN 'check_up' THEN 'Genel check-up kontrolü'
    WHEN 'accident_repair' THEN 'Kaporta ve boya işlemi'
    ELSE 'Aksesuar ve modifikasyon montajı'
  END,
  sa.service_type,
  GREATEST(700, ROUND(sa.estimated_price * 0.55)),
  GREATEST(400, ROUND(sa.estimated_price * 0.45)),
  sa.estimated_price,
  FALSE,
  CASE WHEN sa.status = 'completed' THEN 'approved' ELSE 'pending' END,
  'not_required',
  'Demo servis operasyonu',
  sa.created_at,
  sa.updated_at
FROM service_appointments sa
JOIN vehicles v ON v.id = sa.vehicle_id
WHERE (v.vin LIKE 'DEMOSOLD%' OR v.vin LIKE 'DEMOACQ%');
