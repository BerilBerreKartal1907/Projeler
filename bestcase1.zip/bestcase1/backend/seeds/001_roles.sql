INSERT INTO roles (name)
VALUES
  ('customer'),
  ('sales_agent'),
  ('technician'),
  ('service_manager'),
  ('authorized_manager'),
  ('admin')
ON CONFLICT (name) DO NOTHING;
