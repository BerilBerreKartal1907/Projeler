BEGIN;

TRUNCATE TABLE
  password_reset_tokens,
  notifications,
  audit_logs,
  system_parameters,
  credit_calculations,
  service_operation_reviews,
  service_operations,
  service_appointments,
  negotiation_messages,
  negotiations,
  sales_listings,
  damage_details,
  appraisal_requests,
  simulated_tramer_records,
  vehicles,
  customers,
  users,
  roles
RESTART IDENTITY CASCADE;

COMMIT;
