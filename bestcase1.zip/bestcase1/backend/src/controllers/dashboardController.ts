import type { Request, Response } from "express";

import { query } from "../config/db.js";
import { fail, ok } from "../utils/apiResponse.js";

async function scalar(sql: string) {
  const result = await query<{ value: string }>(sql);
  return Number(result.rows[0]?.value ?? 0);
}

async function scalarWithParams(sql: string, params: unknown[]) {
  const result = await query<{ value: string }>(sql, params);
  return Number(result.rows[0]?.value ?? 0);
}

export async function getCustomerDashboard(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const activeAppraisal = await scalarWithParams(
    `
      SELECT COUNT(*)::text AS value
      FROM appraisal_requests ar
      JOIN customers c ON c.id = ar.customer_id
      WHERE c.user_id = $1
        AND ar.status IN ('draft','submitted','pending_manager_approval','preliminary_offer_ready')
    `,
    [req.authUser.id]
  );
  const activeNegotiation = await scalarWithParams(
    `
      SELECT COUNT(*)::text AS value
      FROM negotiations n
      JOIN customers c ON c.id = n.customer_id
      WHERE c.user_id = $1
        AND n.status IN ('open','auto_negotiating','pending_manager_review')
    `,
    [req.authUser.id]
  );
  const upcomingAppointment = await scalarWithParams(
    `
      SELECT COUNT(*)::text AS value
      FROM service_appointments sa
      JOIN customers c ON c.id = sa.customer_id
      WHERE c.user_id = $1
        AND sa.status NOT IN ('completed','cancelled')
    `,
    [req.authUser.id]
  );
  const pendingApproval = await scalarWithParams(
    `
      SELECT COUNT(*)::text AS value
      FROM service_operations so
      JOIN service_appointments sa ON sa.id = so.appointment_id
      JOIN customers c ON c.id = sa.customer_id
      WHERE c.user_id = $1
        AND so.customer_approval_status = 'pending'
    `,
    [req.authUser.id]
  );
  const pendingPreliminaryOffer = await scalarWithParams(
    `
      SELECT COUNT(*)::text AS value
      FROM appraisal_requests ar
      JOIN customers c ON c.id = ar.customer_id
      WHERE c.user_id = $1
        AND ar.status IN ('preliminary_offer_ready','approved')
    `,
    [req.authUser.id]
  );
  const latestCreditCalculationResult = await query<{ monthly_payment: string | null }>(
    `
      SELECT monthly_payment::text
      FROM credit_calculations cc
      JOIN customers c ON c.id = cc.customer_id
      WHERE c.user_id = $1
      ORDER BY cc.created_at DESC
      LIMIT 1
    `,
    [req.authUser.id]
  );
  const unreadNotifications = await scalarWithParams(
    `
      SELECT COUNT(*)::text AS value
      FROM notifications
      WHERE user_id = $1
        AND is_read = FALSE
    `,
    [req.authUser.id]
  );

  return res.json(ok({
    activeAppraisal,
    pendingPreliminaryOffer,
    activeNegotiation,
    upcomingAppointment,
    pendingApproval,
    latestCreditMonthlyPayment: Number(latestCreditCalculationResult.rows[0]?.monthly_payment ?? 0),
    unreadNotifications
  }));
}

export async function getSalesDashboard(_req: Request, res: Response) {
  const newAppraisals = await scalar("SELECT COUNT(*)::text AS value FROM appraisal_requests");
  const activeNegotiations = await scalar("SELECT COUNT(*)::text AS value FROM negotiations WHERE status IN ('open','auto_negotiating','pending_manager_review')");
  const readyForSale = await scalar("SELECT COUNT(*)::text AS value FROM vehicles WHERE status = 'for_sale'");
  const todaysSales = await scalar("SELECT COALESCE(SUM(list_price),0)::text AS value FROM vehicles WHERE status = 'sold'");
  const pendingCustomerMeetings = await scalar(
    `
      SELECT COUNT(DISTINCT negotiation_id)::text AS value
      FROM negotiation_messages
      WHERE message_type = 'meeting_request'
    `
  );

  return res.json(ok({
    newAppraisals,
    activeNegotiations,
    readyForSale,
    todaysSales,
    pendingCustomerMeetings
  }));
}

export async function getTechnicianDashboard(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const todaysAppointments = await scalarWithParams(
    `
      SELECT COUNT(*)::text AS value
      FROM service_appointments
      WHERE assigned_technician_id = $1
        AND DATE(appointment_datetime) = CURRENT_DATE
    `,
    [req.authUser.id]
  );
  const assignedJobs = await scalarWithParams(
    `
      SELECT COUNT(*)::text AS value
      FROM service_appointments
      WHERE assigned_technician_id = $1
        AND status = 'assigned'
    `,
    [req.authUser.id]
  );
  const waitingCustomerApproval = await scalarWithParams(
    `
      SELECT COUNT(*)::text AS value
      FROM service_appointments
      WHERE assigned_technician_id = $1
        AND status = 'waiting_customer_approval'
    `,
    [req.authUser.id]
  );
  const checkupsInProgress = await scalarWithParams(
    `
      SELECT COUNT(*)::text AS value
      FROM service_appointments
      WHERE assigned_technician_id = $1
        AND status = 'checkup_in_progress'
    `,
    [req.authUser.id]
  );
  const completedJobs = await scalarWithParams(
    `
      SELECT COUNT(*)::text AS value
      FROM service_appointments
      WHERE assigned_technician_id = $1
        AND status = 'completed'
    `,
    [req.authUser.id]
  );

  return res.json(ok({
    todaysAppointments,
    assignedJobs,
    checkupsInProgress,
    waitingCustomerApproval,
    completedJobs
  }));
}

export async function getServiceManagerDashboard(_req: Request, res: Response) {
  const dailyAppointmentCount = await scalar("SELECT COUNT(*)::text AS value FROM service_appointments WHERE DATE(appointment_datetime) = CURRENT_DATE");
  const delayedJobs = await scalar("SELECT COUNT(*)::text AS value FROM service_appointments WHERE status IN ('assigned','checkup_in_progress','in_progress')");
  const criticalRejectedOperations = await scalar("SELECT COUNT(*)::text AS value FROM service_operations WHERE is_critical_safety = TRUE AND customer_approval_status = 'rejected'");
  const occupancyRate = await scalar("SELECT COALESCE(ROUND((COUNT(*) FILTER (WHERE status <> 'cancelled')::numeric / NULLIF(COUNT(*),0)) * 100, 2),0)::text AS value FROM service_appointments");
  const jobsPerTechnician = await scalar(
    `
      SELECT COALESCE(ROUND(AVG(job_count), 2),0)::text AS value
      FROM (
        SELECT COUNT(*)::numeric AS job_count
        FROM service_appointments
        WHERE assigned_technician_id IS NOT NULL
          AND status IN ('assigned','checkup_in_progress','waiting_customer_approval','in_progress')
        GROUP BY assigned_technician_id
      ) technician_jobs
    `
  );

  return res.json(ok({
    dailyAppointmentCount,
    jobsPerTechnician,
    delayedJobs,
    criticalRejectedOperations,
    occupancyRate
  }));
}

export async function getManagerDashboard(_req: Request, res: Response) {
  const pendingAppraisalApprovals = await scalar("SELECT COUNT(*)::text AS value FROM appraisal_requests WHERE requires_manager_approval = TRUE");
  const pendingNegotiations = await scalar("SELECT COUNT(*)::text AS value FROM negotiations WHERE status = 'pending_manager_review'");
  const totalSalesRevenue = await scalar("SELECT COALESCE(SUM(list_price),0)::text AS value FROM vehicles WHERE status = 'sold'");
  const criticalSafetyCases = await scalar("SELECT COUNT(*)::text AS value FROM service_operations WHERE manager_review_status = 'pending'");
  const averageProfit = await scalar("SELECT COALESCE(AVG(list_price - purchase_price),0)::text AS value FROM vehicles WHERE status = 'sold' AND purchase_price IS NOT NULL AND list_price IS NOT NULL");
  const capacityResult = await query<{
    maintenance_capacity: string | null;
    checkup_capacity: string | null;
    accident_capacity: string | null;
    modification_capacity: string | null;
  }>(
    `
      SELECT
        MAX(CASE WHEN key = 'daily_maintenance_capacity' THEN value END) AS maintenance_capacity,
        MAX(CASE WHEN key = 'daily_checkup_capacity' THEN value END) AS checkup_capacity,
        MAX(CASE WHEN key = 'daily_accident_repair_capacity' THEN value END) AS accident_capacity,
        MAX(CASE WHEN key = 'daily_modification_capacity' THEN value END) AS modification_capacity
      FROM system_parameters
    `
  );
  const occupiedAppointments = await scalar("SELECT COUNT(*)::text AS value FROM service_appointments WHERE status <> 'cancelled'");
  const appointmentDayCount = await scalar("SELECT GREATEST(COUNT(DISTINCT appointment_datetime::date), 1)::text AS value FROM service_appointments");
  const capacities = capacityResult.rows[0];
  const dailyCapacity =
    Number(capacities?.maintenance_capacity ?? 12) +
    Number(capacities?.checkup_capacity ?? 8) +
    Number(capacities?.accident_capacity ?? 5) +
    Number(capacities?.modification_capacity ?? 2);
  const serviceOccupancy = dailyCapacity > 0
    ? Number(((occupiedAppointments / (dailyCapacity * appointmentDayCount)) * 100).toFixed(2))
    : 0;

  return res.json(ok({
    pendingAppraisalApprovals,
    pendingNegotiations,
    totalSalesRevenue,
    criticalSafetyCases,
    averageProfit,
    serviceOccupancy
  }));
}

export async function getAdminDashboard(_req: Request, res: Response) {
  const totalUsers = await scalar("SELECT COUNT(*)::text AS value FROM users");
  const activeCustomers = await scalar("SELECT COUNT(*)::text AS value FROM users u JOIN roles r ON r.id = u.role_id WHERE r.name = 'customer' AND u.is_active = TRUE");
  const activeStaff = await scalar("SELECT COUNT(*)::text AS value FROM users u JOIN roles r ON r.id = u.role_id WHERE r.name <> 'customer' AND u.is_active = TRUE");
  const systemLogs = await scalar("SELECT COUNT(*)::text AS value FROM audit_logs");
  const pendingUserActions = await scalar(
    `
      SELECT COUNT(DISTINCT user_id)::text AS value
      FROM (
        SELECT id AS user_id
        FROM users
        WHERE is_active = FALSE

        UNION

        SELECT user_id
        FROM password_reset_tokens
        WHERE used_at IS NULL
          AND expires_at > NOW()
      ) pending_actions
    `
  );

  return res.json(ok({
    totalUsers,
    activeCustomers,
    activeStaff,
    systemLogs,
    pendingUserActions
  }));
}
