import type { Request, Response } from "express";

import { query } from "../config/db.js";
import { ok } from "../utils/apiResponse.js";

export async function listRoles(_req: Request, res: Response) {
  const result = await query<{ id: number; name: string }>(
    "SELECT id, name FROM roles ORDER BY id"
  );

  return res.json(ok(result.rows));
}

export async function getRolePermissions(_req: Request, res: Response) {
  const permissions = [
    {
      role: "customer",
      permissions: ["view", "create"],
      can_view: true,
      can_create: true,
      can_update: false,
      can_delete: false,
      can_approve: false
    },
    {
      role: "sales_agent",
      permissions: ["view", "create", "update"],
      can_view: true,
      can_create: true,
      can_update: true,
      can_delete: false,
      can_approve: false
    },
    {
      role: "technician",
      permissions: ["view", "create", "update"],
      can_view: true,
      can_create: true,
      can_update: true,
      can_delete: false,
      can_approve: false
    },
    {
      role: "service_manager",
      permissions: ["view", "update", "approve"],
      can_view: true,
      can_create: false,
      can_update: true,
      can_delete: false,
      can_approve: true
    },
    {
      role: "authorized_manager",
      permissions: ["view", "update", "approve"],
      can_view: true,
      can_create: false,
      can_update: true,
      can_delete: false,
      can_approve: true
    },
    {
      role: "admin",
      permissions: ["view", "create", "update", "delete", "approve"],
      can_view: true,
      can_create: true,
      can_update: true,
      can_delete: true,
      can_approve: true
    }
  ];

  return res.json(ok(permissions));
}
