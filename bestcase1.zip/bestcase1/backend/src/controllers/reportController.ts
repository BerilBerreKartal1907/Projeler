import type { Request, Response } from "express";
import * as XLSX from "xlsx";

import { query } from "../config/db.js";
import { ok } from "../utils/apiResponse.js";

const currencyFormatter = new Intl.NumberFormat("tr-TR", {
  style: "currency",
  currency: "TRY",
  maximumFractionDigits: 0
});

const numberFormatter = new Intl.NumberFormat("tr-TR", {
  maximumFractionDigits: 2
});

function formatVehicleStatus(status: string) {
  const statusMap: Record<string, string> = {
    active: "Aktif",
    in_appraisal: "Ekspertizde",
    for_sale: "Satışta",
    sold: "Satıldı",
    acquired: "Bayi tarafından alındı",
    in_service: "Serviste",
    cancelled: "İptal edildi",
    under_review: "İncelemede"
  };

  return statusMap[status] ?? status;
}

function formatServiceType(serviceType: string) {
  const typeMap: Record<string, string> = {
    maintenance: "Periyodik bakım",
    check_up: "Check-up",
    accident_repair: "Hasar onarımı",
    modification: "Modifikasyon"
  };

  return typeMap[serviceType] ?? serviceType;
}

function formatServiceStatus(status: string) {
  const statusMap: Record<string, string> = {
    pending: "Onay bekliyor",
    assigned: "Teknisyen atandı",
    checkup_in_progress: "Check-up devam ediyor",
    waiting_customer_approval: "Müşteri onayı bekleniyor",
    in_progress: "Müşteri onayladı",
    completed: "Tamamlandı",
    cancelled: "İptal edildi"
  };

  return statusMap[status] ?? status;
}

export async function getSummaryReport(_req: Request, res: Response) {
  return res.json(ok(await getSummaryData(_req)));
}

async function getSalesRows(filters: {
  brand?: string;
  dateFrom?: string;
  dateTo?: string;
}) {
  return query(
    `
      SELECT
        CONCAT('acq-', v.id)::text AS id,
        v.brand,
        v.model,
        v.year,
        NULL::numeric AS list_price,
        v.purchase_price,
        (COALESCE(v.purchase_price, 0) * -1)::numeric AS report_price,
        'acquired'::text AS status,
        'Bayi alimi'::text AS transaction_type,
        v.updated_at AS created_at
      FROM vehicles v
      WHERE v.purchase_price IS NOT NULL
        AND v.status IN ('acquired', 'for_sale', 'sold')
        AND ($1::text IS NULL OR v.brand = $1)
        AND ($2::date IS NULL OR v.updated_at::date >= $2::date)
        AND ($3::date IS NULL OR v.updated_at::date <= $3::date)

      UNION ALL

      SELECT
        CONCAT('sale-', sl.id)::text AS id,
        v.brand,
        v.model,
        v.year,
        sl.price AS list_price,
        v.purchase_price,
        COALESCE(NULLIF(sl.price, 0), v.list_price, 0)::numeric AS report_price,
        'sold'::text AS status,
        'Satis'::text AS transaction_type,
        sl.updated_at AS created_at
      FROM sales_listings sl
      JOIN vehicles v ON v.id = sl.vehicle_id
      WHERE sl.status = 'sold'
        AND ($1::text IS NULL OR v.brand = $1)
        AND ($2::date IS NULL OR sl.updated_at::date >= $2::date)
        AND ($3::date IS NULL OR sl.updated_at::date <= $3::date)

      ORDER BY created_at DESC
    `,
    [filters.brand ?? null, filters.dateFrom ?? null, filters.dateTo ?? null]
  );
}

async function getServiceRows(filters: {
  brand?: string;
  serviceType?: string;
  dateFrom?: string;
  dateTo?: string;
}) {
  return query(
    `
      SELECT
        sa.id,
        sa.service_type,
        sa.status,
        sa.appointment_datetime,
        v.brand,
        v.model,
        u.full_name AS customer_name
      FROM service_appointments sa
      JOIN vehicles v ON v.id = sa.vehicle_id
      JOIN customers c ON c.id = sa.customer_id
      JOIN users u ON u.id = c.user_id
      WHERE ($1::text IS NULL OR v.brand = $1)
        AND ($2::text IS NULL OR sa.service_type = $2)
        AND ($3::date IS NULL OR sa.appointment_datetime::date >= $3::date)
        AND ($4::date IS NULL OR sa.appointment_datetime::date <= $4::date)
      ORDER BY sa.appointment_datetime DESC
    `,
    [filters.brand ?? null, filters.serviceType ?? null, filters.dateFrom ?? null, filters.dateTo ?? null]
  );
}

export async function getSalesReport(req: Request, res: Response) {
  const { brand, dateFrom, dateTo } = req.query as { brand?: string; dateFrom?: string; dateTo?: string };
  const result = await getSalesRows({ brand, dateFrom, dateTo });

  return res.json(ok(result.rows));
}

export async function getServiceReport(req: Request, res: Response) {
  const { brand, serviceType, dateFrom, dateTo } = req.query as { brand?: string; serviceType?: string; dateFrom?: string; dateTo?: string };
  const result = await getServiceRows({ brand, serviceType, dateFrom, dateTo });

  return res.json(ok(result.rows));
}

export async function exportSummaryCsv(req: Request, res: Response) {
  const { brand, serviceType, dateFrom, dateTo } = req.query as {
    brand?: string;
    serviceType?: string;
    dateFrom?: string;
    dateTo?: string;
  };
  const summary = await getSummaryData(req);
  const [salesRows, serviceRows] = await Promise.all([
    getSalesRows({ brand, dateFrom, dateTo }),
    getServiceRows({ brand, serviceType, dateFrom, dateTo })
  ]);

  const rows = [
    ["Smart Appraisal Ozet Raporu", ""],
    ["Marka Filtresi", brand ?? "Tum markalar"],
    ["Servis Tipi Filtresi", serviceType ? formatServiceType(serviceType) : "Tum servis tipleri"],
    ["Tarih Araligi", dateFrom || dateTo ? `${dateFrom ?? "-"} - ${dateTo ?? "-"}` : "Tum tarihler"],
    [],
    ["Rapor Kalemi", "Deger"],
    ["Toplam Satis Adedi", String(summary.totalSalesCount)],
    ["Toplam Satis Geliri", currencyFormatter.format(summary.totalSalesRevenue)],
    ["Bayi Alim Gideri", currencyFormatter.format(summary.totalAcquisitionExpense * -1)],
    ["Toplam Gelir", currencyFormatter.format(summary.totalRevenue)],
    ["Servis Geliri", currencyFormatter.format(summary.totalServiceRevenue)],
    ["Ortalama Kar", currencyFormatter.format(summary.averageProfit)],
    ["Servis Doluluk Orani", `%${numberFormatter.format(summary.serviceOccupancyRate)}`],
    ["En Aktif Teknisyen", summary.mostActiveTechnicianName],
    ["En Aktif Teknisyen Tamamlanan Is", String(summary.mostActiveTechnicianJobs)],
    ["Aktif Pazarlik", String(summary.activeNegotiations)],
    ["Bekleyen Onay", String(summary.pendingApprovals)],
    [],
    ["Satis Raporu", "", "", ""],
    ["Islem", "Arac", "Yil", "Tutar", "Durum"],
    ...salesRows.rows.map((row) => [
      row.transaction_type,
      `${row.brand} ${row.model}`,
      String(row.year),
      currencyFormatter.format(Number(row.report_price ?? 0)),
      formatVehicleStatus(row.status)
    ]),
    [],
    ["Servis Raporu", "", "", ""],
    ["Musteri", "Arac", "Servis Tipi", "Durum"],
    ...serviceRows.rows.map((row) => [
      row.customer_name,
      `${row.brand} ${row.model}`,
      formatServiceType(row.service_type),
      formatServiceStatus(row.status)
    ])
  ];

  const csv = rows
    .map((row) => row.map((cell) => `"${String(cell ?? "").replaceAll("\"", "\"\"")}"`).join(";"))
    .join("\n");

  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", "attachment; filename=\"smart-appraisal-summary.csv\"");

  return res.send(csv);
}

export async function exportSummaryExcel(req: Request, res: Response) {
  const { brand, serviceType, dateFrom, dateTo } = req.query as {
    brand?: string;
    serviceType?: string;
    dateFrom?: string;
    dateTo?: string;
  };
  const [summary, salesRows, serviceRows] = await Promise.all([
    getSummaryData(req),
    getSalesRows({ brand, dateFrom, dateTo }),
    getServiceRows({ brand, serviceType, dateFrom, dateTo })
  ]);

  const workbook = XLSX.utils.book_new();

  const summarySheet = XLSX.utils.aoa_to_sheet([
    ["Smart Appraisal Özet Raporu", ""],
    ["Marka Filtresi", brand ?? "Tüm markalar"],
    ["Servis Tipi Filtresi", serviceType ? formatServiceType(serviceType) : "Tüm servis tipleri"],
    ["Tarih Aralığı", dateFrom || dateTo ? `${dateFrom ?? "-"} - ${dateTo ?? "-"}` : "Tüm tarihler"],
    [],
    ["Rapor Kalemi", "Değer"],
    ["Toplam Satış Adedi", String(summary.totalSalesCount)],
    ["Toplam Satış Geliri", currencyFormatter.format(summary.totalSalesRevenue)],
    ["Bayi Alım Gideri", currencyFormatter.format(summary.totalAcquisitionExpense * -1)],
    ["Toplam Gelir", currencyFormatter.format(summary.totalRevenue)],
    ["Servis Geliri", currencyFormatter.format(summary.totalServiceRevenue)],
    ["Ortalama Kâr", currencyFormatter.format(summary.averageProfit)],
    ["Servis Doluluk Oranı", `%${numberFormatter.format(summary.serviceOccupancyRate)}`],
    ["En Aktif Teknisyen", summary.mostActiveTechnicianName],
    ["En Aktif Teknisyen Tamamlanan İş", String(summary.mostActiveTechnicianJobs)],
    ["Aktif Pazarlık", String(summary.activeNegotiations)],
    ["Bekleyen Onay", String(summary.pendingApprovals)]
  ]);
  const salesSheet = XLSX.utils.json_to_sheet(
    salesRows.rows.map((row) => ({
      İşlem: row.transaction_type,
      Araç: `${row.brand} ${row.model}`,
      Yıl: row.year,
      Tutar: currencyFormatter.format(Number(row.report_price ?? 0)),
      Durum: formatVehicleStatus(row.status),
      "Kayıt Tarihi": new Date(row.created_at).toLocaleDateString("tr-TR")
    }))
  );
  const serviceSheet = XLSX.utils.json_to_sheet(
    serviceRows.rows.map((row) => ({
      Müşteri: row.customer_name,
      Araç: `${row.brand} ${row.model}`,
      "Servis Tipi": formatServiceType(row.service_type),
      Durum: formatServiceStatus(row.status),
      "Randevu Tarihi": new Date(row.appointment_datetime).toLocaleDateString("tr-TR")
    }))
  );

  summarySheet["!cols"] = [{ wch: 32 }, { wch: 22 }];
  salesSheet["!cols"] = [
    { wch: 14 },
    { wch: 24 },
    { wch: 8 },
    { wch: 16 },
    { wch: 24 },
    { wch: 14 }
  ];
  serviceSheet["!cols"] = [
    { wch: 24 },
    { wch: 24 },
    { wch: 20 },
    { wch: 22 },
    { wch: 16 }
  ];

  XLSX.utils.book_append_sheet(workbook, summarySheet, "Ozet");
  XLSX.utils.book_append_sheet(workbook, salesSheet, "Satis");
  XLSX.utils.book_append_sheet(workbook, serviceSheet, "Servis");

  const buffer = XLSX.write(workbook, {
    type: "buffer",
    bookType: "xlsx"
  });

  res.setHeader(
    "Content-Type",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  );
  res.setHeader(
    "Content-Disposition",
    "attachment; filename=\"smart-appraisal-summary.xlsx\""
  );

  return res.send(buffer);
}

async function getSummaryData(req?: Request) {
  const {
    brand,
    serviceType,
    dateFrom,
    dateTo
  } = (req?.query ?? {}) as { brand?: string; serviceType?: string; dateFrom?: string; dateTo?: string };

  const [salesCount, acquisitionExpense, salesRevenue, serviceRevenue, activeNegotiations, pendingApprovals, averageProfit, mostActiveTechnician] = await Promise.all([
    query<{ value: string }>(
      `
        SELECT COUNT(*)::text AS value
        FROM vehicles
        WHERE status = 'sold'
          AND ($1::text IS NULL OR brand = $1)
          AND ($2::date IS NULL OR created_at::date >= $2::date)
          AND ($3::date IS NULL OR created_at::date <= $3::date)
      `,
      [brand ?? null, dateFrom ?? null, dateTo ?? null]
    ),
    query<{ value: string }>(
      `
        SELECT COALESCE(SUM(purchase_price),0)::text AS value
        FROM vehicles
        WHERE purchase_price IS NOT NULL
          AND status IN ('acquired', 'for_sale', 'sold')
          AND ($1::text IS NULL OR brand = $1)
          AND ($2::date IS NULL OR created_at::date >= $2::date)
          AND ($3::date IS NULL OR created_at::date <= $3::date)
      `,
      [brand ?? null, dateFrom ?? null, dateTo ?? null]
    ),
    query<{ value: string }>(
      `
        SELECT COALESCE(SUM(list_price),0)::text AS value
        FROM vehicles
        WHERE status = 'sold'
          AND ($1::text IS NULL OR brand = $1)
          AND ($2::date IS NULL OR created_at::date >= $2::date)
          AND ($3::date IS NULL OR created_at::date <= $3::date)
      `,
      [brand ?? null, dateFrom ?? null, dateTo ?? null]
    ),
    query<{ value: string }>(
      `
        SELECT COALESCE(SUM(total_price),0)::text AS value
        FROM service_operations
        JOIN service_appointments sa ON sa.id = service_operations.appointment_id
        JOIN vehicles v ON v.id = sa.vehicle_id
        WHERE customer_approval_status = 'approved'
          AND ($1::text IS NULL OR v.brand = $1)
          AND ($2::text IS NULL OR sa.service_type = $2)
          AND ($3::date IS NULL OR service_operations.created_at::date >= $3::date)
          AND ($4::date IS NULL OR service_operations.created_at::date <= $4::date)
      `,
      [brand ?? null, serviceType ?? null, dateFrom ?? null, dateTo ?? null]
    ),
    query<{ value: string }>(
      `
        SELECT COUNT(*)::text AS value
        FROM negotiations n
        JOIN appraisal_requests ar ON ar.id = n.appraisal_request_id
        JOIN vehicles v ON v.id = ar.vehicle_id
        WHERE n.status IN ('open','auto_negotiating','pending_manager_review')
          AND ($1::text IS NULL OR v.brand = $1)
          AND ($2::date IS NULL OR n.created_at::date >= $2::date)
          AND ($3::date IS NULL OR n.created_at::date <= $3::date)
      `,
      [brand ?? null, dateFrom ?? null, dateTo ?? null]
    ),
    query<{ value: string }>(
      `
        SELECT COUNT(*)::text AS value
        FROM appraisal_requests
        JOIN vehicles v ON v.id = appraisal_requests.vehicle_id
        WHERE requires_manager_approval = TRUE
          AND ($1::text IS NULL OR v.brand = $1)
          AND ($2::date IS NULL OR appraisal_requests.created_at::date >= $2::date)
          AND ($3::date IS NULL OR appraisal_requests.created_at::date <= $3::date)
      `,
      [brand ?? null, dateFrom ?? null, dateTo ?? null]
    ),
    query<{ value: string }>(
      `
        SELECT COALESCE(AVG(list_price - purchase_price),0)::text AS value
        FROM vehicles
        WHERE status = 'sold'
          AND ($1::text IS NULL OR brand = $1)
          AND purchase_price IS NOT NULL
          AND list_price IS NOT NULL
          AND ($2::date IS NULL OR created_at::date >= $2::date)
          AND ($3::date IS NULL OR created_at::date <= $3::date)
      `,
      [brand ?? null, dateFrom ?? null, dateTo ?? null]
    ),
    query<{ full_name: string; completed_jobs: string }>(
      `
        SELECT
          u.full_name,
          COUNT(*)::text AS completed_jobs
        FROM service_appointments sa
        JOIN users u ON u.id = sa.assigned_technician_id
        JOIN vehicles v ON v.id = sa.vehicle_id
        WHERE sa.assigned_technician_id IS NOT NULL
          AND sa.status = 'completed'
          AND ($1::text IS NULL OR v.brand = $1)
          AND ($2::text IS NULL OR sa.service_type = $2)
          AND ($3::date IS NULL OR sa.appointment_datetime::date >= $3::date)
          AND ($4::date IS NULL OR sa.appointment_datetime::date <= $4::date)
        GROUP BY u.id, u.full_name
        ORDER BY COUNT(*) DESC, u.full_name ASC
        LIMIT 1
      `,
      [brand ?? null, serviceType ?? null, dateFrom ?? null, dateTo ?? null]
    )
  ]);

  const capacityResult = await query<{
    maintenance_capacity: string | null;
    checkup_capacity: string | null;
    accident_capacity: string | null;
    modification_capacity: string | null;
  }>(
    `
      SELECT
        MAX(CASE WHEN key = 'daily_maintenance_capacity' THEN value END) AS maintenance_capacity,
        MAX(CASE WHEN key = 'daily_checkup_capacity' THEN value END) AS checkup_capacity,
        MAX(CASE WHEN key = 'daily_accident_repair_capacity' THEN value END) AS accident_capacity,
        MAX(CASE WHEN key = 'daily_modification_capacity' THEN value END) AS modification_capacity
      FROM system_parameters
    `
  );

  const occupiedAppointments = await query<{ value: string }>(
    `
      SELECT COUNT(*)::text AS value
      FROM service_appointments sa
      JOIN vehicles v ON v.id = sa.vehicle_id
      WHERE sa.status <> 'cancelled'
        AND ($1::text IS NULL OR v.brand = $1)
        AND ($2::text IS NULL OR sa.service_type = $2)
        AND ($3::date IS NULL OR sa.appointment_datetime::date >= $3::date)
        AND ($4::date IS NULL OR sa.appointment_datetime::date <= $4::date)
    `,
    [brand ?? null, serviceType ?? null, dateFrom ?? null, dateTo ?? null]
  );

  const appointmentDayCount = await query<{ value: string }>(
    `
      SELECT GREATEST(COUNT(DISTINCT appointment_datetime::date), 1)::text AS value
      FROM service_appointments sa
      JOIN vehicles v ON v.id = sa.vehicle_id
      WHERE ($1::text IS NULL OR v.brand = $1)
        AND ($2::text IS NULL OR sa.service_type = $2)
        AND ($3::date IS NULL OR sa.appointment_datetime::date >= $3::date)
        AND ($4::date IS NULL OR sa.appointment_datetime::date <= $4::date)
    `,
    [brand ?? null, serviceType ?? null, dateFrom ?? null, dateTo ?? null]
  );

  const capacities = capacityResult.rows[0];
  const dailyCapacity =
    Number(capacities?.maintenance_capacity ?? 12) +
    Number(capacities?.checkup_capacity ?? 8) +
    Number(capacities?.accident_capacity ?? 5) +
    Number(capacities?.modification_capacity ?? 2);
  const dayCount = Number(appointmentDayCount.rows[0]?.value ?? 1);
  const occupied = Number(occupiedAppointments.rows[0]?.value ?? 0);
  const serviceOccupancyRate = dailyCapacity > 0
    ? Number(((occupied / (dailyCapacity * dayCount)) * 100).toFixed(2))
    : 0;
  const mostActive = mostActiveTechnician.rows[0];
  const totalSalesRevenue = Number(salesRevenue.rows[0]?.value ?? 0);
  const totalAcquisitionExpense = Number(acquisitionExpense.rows[0]?.value ?? 0);
  const totalServiceRevenue = Number(serviceRevenue.rows[0]?.value ?? 0);

  return {
    totalSalesCount: Number(salesCount.rows[0]?.value ?? 0),
    totalSalesRevenue,
    totalAcquisitionExpense,
    totalRevenue: totalSalesRevenue + totalServiceRevenue - totalAcquisitionExpense,
    totalServiceRevenue,
    averageProfit: Number(averageProfit.rows[0]?.value ?? 0),
    serviceOccupancyRate,
    mostActiveTechnicianName: mostActive?.full_name ?? "-",
    mostActiveTechnicianJobs: Number(mostActive?.completed_jobs ?? 0),
    activeNegotiations: Number(activeNegotiations.rows[0]?.value ?? 0),
    pendingApprovals: Number(pendingApprovals.rows[0]?.value ?? 0)
  };
}
