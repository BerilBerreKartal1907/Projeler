import type { Request, Response } from "express";

import { query } from "../config/db.js";
import { ok } from "../utils/apiResponse.js";

export async function listAuditLogs(_req: Request, res: Response) {
  const result = await query(
    `
      SELECT
        al.id,
        al.action,
        al.entity_type,
        al.entity_id,
        al.old_value,
        al.new_value,
        al.ip_address,
        al.created_at,
        u.full_name AS user_name
      FROM audit_logs al
      LEFT JOIN users u ON u.id = al.user_id
      ORDER BY al.created_at DESC
      LIMIT 200
    `
  );

  return res.json(ok(result.rows));
}
