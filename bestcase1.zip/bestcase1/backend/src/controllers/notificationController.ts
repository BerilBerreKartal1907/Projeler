import type { Request, Response } from "express";

import { query } from "../config/db.js";
import { fail, ok } from "../utils/apiResponse.js";

export async function listNotifications(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const result = await query(
    `
      SELECT id, title, message, type, is_read, created_at
      FROM notifications
      WHERE user_id = $1
      ORDER BY created_at DESC
    `,
    [req.authUser.id]
  );

  return res.json(ok(result.rows));
}

export async function markNotificationRead(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const result = await query(
    `
      UPDATE notifications
      SET is_read = TRUE
      WHERE id = $1
        AND user_id = $2
      RETURNING id, is_read
    `,
    [req.params.id, req.authUser.id]
  );

  if (!result.rows[0]) {
    return res.status(404).json(fail("Bildirim bulunamadı."));
  }

  return res.json(ok(result.rows[0], "Bildirim okundu olarak işaretlendi."));
}

export async function markAllNotificationsRead(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  await query(
    `
      UPDATE notifications
      SET is_read = TRUE
      WHERE user_id = $1
    `,
    [req.authUser.id]
  );

  return res.json(ok(null, "Tüm bildirimler okundu olarak işaretlendi."));
}
