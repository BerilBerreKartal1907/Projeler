import type { Request, Response } from "express";
import bcrypt from "bcrypt";

import { query } from "../config/db.js";
import { fail, ok } from "../utils/apiResponse.js";
import { createAuditLog } from "../utils/audit.js";

type UserRow = {
  id: number;
  full_name: string;
  email: string;
  phone: string | null;
  is_active: boolean;
  role_id: number;
  role: string;
  created_at: string;
  updated_at: string;
};

export async function listUsers(_req: Request, res: Response) {
  const result = await query<UserRow>(
    `
      SELECT
        u.id,
        u.full_name,
        u.email,
        u.phone,
        u.is_active,
        u.role_id,
        r.name AS role,
        u.created_at,
        u.updated_at
      FROM users u
      JOIN roles r ON r.id = u.role_id
      ORDER BY u.id
    `
  );

  return res.json(ok(result.rows));
}

export async function getUser(req: Request, res: Response) {
  const result = await query<UserRow>(
    `
      SELECT
        u.id,
        u.full_name,
        u.email,
        u.phone,
        u.is_active,
        u.role_id,
        r.name AS role,
        u.created_at,
        u.updated_at
      FROM users u
      JOIN roles r ON r.id = u.role_id
      WHERE u.id = $1
      LIMIT 1
    `,
    [req.params.id]
  );

  const user = result.rows[0];
  if (!user) {
    return res.status(404).json(fail("Kullanıcı bulunamadı."));
  }

  return res.json(ok(user));
}

export async function createUser(req: Request, res: Response) {
  const { fullName, email, password, phone, roleId, isActive = true } = req.body as {
    fullName?: string;
    email?: string;
    password?: string;
    phone?: string;
    roleId?: number;
    isActive?: boolean;
  };

  if (!fullName || !email || !password || !roleId) {
    return res.status(400).json(fail("fullName, email, password ve roleId zorunludur."));
  }

  const roleExists = await query<{ id: number }>("SELECT id FROM roles WHERE id = $1 LIMIT 1", [roleId]);
  if (!roleExists.rows[0]) {
    return res.status(400).json(fail("Seçilen rol bulunamadı."));
  }

  const passwordHash = await bcrypt.hash(password, 10);

  const result = await query<UserRow>(
    `
      INSERT INTO users (full_name, email, password_hash, phone, role_id, is_active)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING id, full_name, email, phone, is_active, role_id, created_at, updated_at
    `,
    [fullName, email, passwordHash, phone ?? null, roleId, isActive]
  );

  await createAuditLog({
    userId: req.authUser?.id,
    action: "create_user",
    entityType: "user",
    entityId: result.rows[0].id,
    newValue: result.rows[0],
    ipAddress: req.ip
  });

  return res.status(201).json(ok(result.rows[0], "Kullanıcı oluşturuldu."));
}

export async function updateUser(req: Request, res: Response) {
  const { fullName, phone, roleId, isActive } = req.body as {
    fullName?: string;
    phone?: string | null;
    roleId?: number;
    isActive?: boolean;
  };

  const currentResult = await query<UserRow>(
    `
      SELECT
        u.id,
        u.full_name,
        u.email,
        u.phone,
        u.is_active,
        u.role_id,
        r.name AS role,
        u.created_at,
        u.updated_at
      FROM users u
      JOIN roles r ON r.id = u.role_id
      WHERE u.id = $1
      LIMIT 1
    `,
    [req.params.id]
  );

  const currentUser = currentResult.rows[0];
  if (!currentUser) {
    return res.status(404).json(fail("Kullanıcı bulunamadı."));
  }

  if (roleId !== undefined) {
    // Admin ekranından gelen rol id'si DB'de yoksa kullanıcı güncellemesi yapılmaz.
    const roleExists = await query<{ id: number }>("SELECT id FROM roles WHERE id = $1 LIMIT 1", [roleId]);
    if (!roleExists.rows[0]) {
      return res.status(400).json(fail("Seçilen rol bulunamadı."));
    }
  }

  const result = await query<UserRow>(
    `
      UPDATE users
      SET
        full_name = COALESCE($2, full_name),
        phone = COALESCE($3, phone),
        role_id = COALESCE($4, role_id),
        is_active = COALESCE($5, is_active),
        updated_at = NOW()
      WHERE id = $1
      RETURNING id, full_name, email, phone, is_active, role_id, created_at, updated_at
    `,
    [req.params.id, fullName ?? null, phone ?? null, roleId ?? null, isActive ?? null]
  );

  await createAuditLog({
    userId: req.authUser?.id,
    action: "update_user",
    entityType: "user",
    entityId: result.rows[0].id,
    // Eski ve yeni değer birlikte tutulur; admin geçmiş ekranında değişiklik izi buradan okunur.
    oldValue: currentUser,
    newValue: result.rows[0],
    ipAddress: req.ip
  });

  return res.json(ok(result.rows[0], "Kullanıcı güncellendi."));
}
