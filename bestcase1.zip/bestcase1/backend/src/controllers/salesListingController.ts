import type { Request, Response } from "express";

import { query } from "../config/db.js";
import { fail, ok } from "../utils/apiResponse.js";

export async function listSalesListings(_req: Request, res: Response) {
  const result = await query(
    `
      SELECT
        sl.id,
        sl.price,
        sl.damage_score,
        sl.status,
        sl.created_at,
        v.id AS vehicle_id,
        v.brand,
        v.model,
        v.year,
        v.package,
        v.color
      FROM sales_listings sl
      JOIN vehicles v ON v.id = sl.vehicle_id
      ORDER BY sl.created_at DESC
    `
  );

  return res.json(ok(result.rows));
}

export async function listSalesListingCandidates(_req: Request, res: Response) {
  const result = await query(
    `
      SELECT
        v.id,
        v.brand,
        v.model,
        v.year,
        v.plate,
        v.vin,
        v.list_price,
        ar.calculated_offer,
        ar.damage_score,
        ar.status AS appraisal_status,
        u.full_name AS customer_name
      FROM vehicles v
      JOIN appraisal_requests ar ON ar.vehicle_id = v.id
      JOIN customers c ON c.id = ar.customer_id
      JOIN users u ON u.id = c.user_id
      LEFT JOIN sales_listings sl ON sl.vehicle_id = v.id AND sl.status <> 'cancelled'
      WHERE ar.status = 'approved'
        AND ar.calculated_offer IS NOT NULL
        AND v.status NOT IN ('for_sale', 'sold')
        AND sl.id IS NULL
      ORDER BY ar.updated_at DESC, ar.id DESC
    `
  );

  return res.json(ok(result.rows));
}

export async function createSalesListing(req: Request, res: Response) {
  const { vehicleId, price, damageScore, status = "active" } = req.body as {
    vehicleId?: number;
    price?: number;
    damageScore?: number;
    status?: string;
  };

  if (!vehicleId || typeof price !== "number") {
    return res.status(400).json(fail("vehicleId ve price zorunludur."));
  }

  const candidateResult = await query<{ id: number; damage_score: number }>(
    `
      SELECT ar.id, ar.damage_score
      FROM appraisal_requests ar
      JOIN vehicles v ON v.id = ar.vehicle_id
      WHERE v.id = $1
        AND ar.status = 'approved'
        AND ar.calculated_offer IS NOT NULL
        AND v.status NOT IN ('for_sale', 'sold')
      ORDER BY ar.updated_at DESC, ar.id DESC
      LIMIT 1
    `,
    [vehicleId]
  );

  const candidate = candidateResult.rows[0];
  if (!candidate) {
    return res.status(409).json(fail("Yalnızca onaylanmış ve henüz satışa alınmamış ekspertiz araçları listelenebilir."));
  }

  const result = await query(
    `
      INSERT INTO sales_listings (vehicle_id, price, damage_score, status)
      VALUES ($1, $2, $3, $4)
      RETURNING id, vehicle_id, price, damage_score, status
    `,
    [vehicleId, price, damageScore ?? candidate.damage_score, status]
  );

  await query(
    `
      UPDATE vehicles
      SET status = 'for_sale', list_price = $2, updated_at = NOW()
      WHERE id = $1
    `,
    [vehicleId, price]
  );

  return res.status(201).json(ok(result.rows[0], "Satış listesi oluşturuldu."));
}

export async function markListingSold(req: Request, res: Response) {
  const result = await query(
    `
      UPDATE sales_listings
      SET status = 'sold', updated_at = NOW()
      WHERE id = $1
      RETURNING id, vehicle_id, status
    `,
    [req.params.id]
  );

  if (!result.rows[0]) {
    return res.status(404).json(fail("Satış listesi bulunamadı."));
  }

  await query(
    `
      UPDATE vehicles
      SET status = 'sold', updated_at = NOW()
      WHERE id = $1
    `,
    [result.rows[0].vehicle_id]
  );

  return res.json(ok(result.rows[0], "Araç satıldı olarak işaretlendi."));
}

export async function cancelSalesListing(req: Request, res: Response) {
  const result = await query(
    `
      UPDATE sales_listings
      SET status = 'cancelled', updated_at = NOW()
      WHERE id = $1
        AND status <> 'sold'
        AND status <> 'cancelled'
      RETURNING id, vehicle_id, status
    `,
    [req.params.id]
  );

  if (!result.rows[0]) {
    return res.status(404).json(fail("İptal edilebilecek satış listesi bulunamadı."));
  }

  await query(
    `
      UPDATE vehicles
      SET status = 'acquired', updated_at = NOW()
      WHERE id = $1
        AND status = 'for_sale'
    `,
    [result.rows[0].vehicle_id]
  );

  return res.json(ok(result.rows[0], "Satış listesi iptal edildi."));
}
