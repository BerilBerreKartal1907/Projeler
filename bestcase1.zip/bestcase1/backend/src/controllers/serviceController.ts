import type { Request, Response } from "express";

import { query } from "../config/db.js";
import { ROLES } from "../constants/roles.js";
import { countAppointmentsForDay, getDailyCapacity } from "../services/service/capacityService.js";
import { fail, ok } from "../utils/apiResponse.js";
import { createAuditLog } from "../utils/audit.js";
import { createNotification } from "../utils/notifications.js";

const APPOINTMENT_SLOTS = [
  "09:00",
  "10:00",
  "11:00",
  "12:00",
  "13:00",
  "14:00",
  "15:00",
  "16:00",
  "17:00"
] as const;

function hashSlotSeed(value: string) {
  return value.split("").reduce((sum, char) => sum + char.charCodeAt(0), 0);
}

async function refreshAppointmentWorkStatus(appointmentId: number) {
  const pendingResult = await query<{ count: string }>(
    `
      SELECT COUNT(*)::text AS count
      FROM service_operations
      WHERE appointment_id = $1
        AND (
          customer_approval_status = 'pending'
          OR (is_critical_safety = TRUE AND manager_review_status = 'pending')
        )
    `,
    [appointmentId]
  );

  const hasPendingApproval = Number(pendingResult.rows[0]?.count ?? 0) > 0;

  await query(
    `
      UPDATE service_appointments
      SET
        status = CASE
          WHEN $2::boolean THEN 'waiting_customer_approval'
          WHEN status NOT IN ('completed', 'cancelled') THEN 'in_progress'
          ELSE status
        END,
        updated_at = NOW()
      WHERE id = $1
    `,
    [appointmentId, hasPendingApproval]
  );
}

export async function checkCapacity(req: Request, res: Response) {
  const { serviceType, date } = req.query as { serviceType?: string; date?: string };

  if (!serviceType || !date) {
    return res.status(400).json(fail("serviceType ve date zorunludur."));
  }

  const capacity = await getDailyCapacity(serviceType);
  const used = await countAppointmentsForDay(serviceType, date);

  return res.json(
    ok({
      serviceType,
      date,
      capacity,
      used,
      remaining: Math.max(capacity - used, 0),
      available: used < capacity
    })
  );
}

export async function getAvailabilitySlots(req: Request, res: Response) {
  const { serviceType, date } = req.query as { serviceType?: string; date?: string };

  if (!serviceType || !date) {
    return res.status(400).json(fail("serviceType ve date zorunludur."));
  }

  const bookedResult = await query<{ appointment_datetime: string }>(
    `
      SELECT appointment_datetime
      FROM service_appointments
      WHERE service_type = $1
        AND DATE(appointment_datetime) = DATE($2)
        AND status <> 'cancelled'
      ORDER BY appointment_datetime
    `,
    [serviceType, date]
  );

  const actualBusyTimes = new Set(
    bookedResult.rows.map((row) => new Date(row.appointment_datetime).toLocaleTimeString("tr-TR", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false
    }).slice(0, 5))
  );

  const seed = hashSlotSeed(`${serviceType}-${date}`);
  const simulatedBusyCount = 1 + (seed % 3);
  const simulatedBusyTimes = new Set<string>();

  for (let index = 0; index < simulatedBusyCount; index += 1) {
    const slot = APPOINTMENT_SLOTS[(seed + index * 2) % APPOINTMENT_SLOTS.length];
    if (!actualBusyTimes.has(slot)) {
      simulatedBusyTimes.add(slot);
    }
  }

  const slots = APPOINTMENT_SLOTS.map((time) => ({
    time,
    available: !actualBusyTimes.has(time) && !simulatedBusyTimes.has(time),
    source: actualBusyTimes.has(time) ? "booked" : simulatedBusyTimes.has(time) ? "busy" : "free"
  }));

  return res.json(ok({
    date,
    serviceType,
    slots
  }));
}

export async function listAppointments(req: Request, res: Response) {
  const role = req.authUser?.role;
  const userId = req.authUser?.id ?? null;
  const result = await query(
    `
      SELECT
        sa.id,
        sa.service_type,
        sa.appointment_datetime,
        sa.estimated_price,
        sa.status,
        sa.complaint_description,
        u.full_name AS customer_name,
        v.brand,
        v.model,
        v.plate,
        tech.full_name AS technician_name,
        tech.id AS technician_id,
        u.id AS customer_user_id
      FROM service_appointments sa
      JOIN customers c ON c.id = sa.customer_id
      JOIN users u ON u.id = c.user_id
      JOIN vehicles v ON v.id = sa.vehicle_id
      LEFT JOIN users tech ON tech.id = sa.assigned_technician_id
      WHERE (
        $1::text IS NULL
        OR $1 <> 'customer'
        OR u.id = $2
      )
      AND (
        $1::text IS NULL
        OR $1 <> 'technician'
        OR tech.id = $2
      )
      ORDER BY sa.appointment_datetime DESC
    `,
    [role, userId]
  );

  return res.json(ok(result.rows));
}

export async function listAssignableTechnicians(_req: Request, res: Response) {
  const result = await query(
    `
      SELECT
        u.id,
        u.full_name,
        u.email,
        u.phone
      FROM users u
      JOIN roles r ON r.id = u.role_id
      WHERE r.name = $1
        AND u.is_active = TRUE
      ORDER BY u.full_name
    `,
    [ROLES.TECHNICIAN]
  );

  return res.json(ok(result.rows));
}

export async function createAppointment(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const {
    vehicleId,
    serviceType,
    appointmentDatetime,
    complaintDescription
  } = req.body as {
    vehicleId?: number;
    serviceType?: string;
    appointmentDatetime?: string;
    complaintDescription?: string;
  };

  if (!vehicleId || !serviceType || !appointmentDatetime) {
    return res.status(400).json(fail("vehicleId, serviceType ve appointmentDatetime zorunludur."));
  }

  const customerResult = await query<{ id: number }>(
    `
      SELECT c.id
      FROM customers c
      JOIN users u ON u.id = c.user_id
      WHERE u.id = $1
      LIMIT 1
    `,
    [req.authUser.id]
  );

  const customer = customerResult.rows[0];
  if (!customer) {
    return res.status(403).json(fail("Bu işlem yalnızca müşteri hesabıyla yapılabilir."));
  }

  const vehicleOwnershipResult = await query<{ id: number }>(
    `
      SELECT id
      FROM vehicles
      WHERE id = $1
        AND owner_customer_id = $2
      LIMIT 1
    `,
    [vehicleId, customer.id]
  );

  if (!vehicleOwnershipResult.rows[0]) {
    return res.status(403).json(fail("Bu araç için servis randevusu oluşturma yetkiniz bulunmuyor."));
  }

  const dateOnly = appointmentDatetime.slice(0, 10);
  const capacity = await getDailyCapacity(serviceType);
  const used = await countAppointmentsForDay(serviceType, dateOnly);

  if (used >= capacity) {
    return res.status(409).json(
      fail("Maalesef bu gün için uygun slot bulunmuyor. Lütfen başka bir gün seçin.")
    );
  }

  const requestedDate = new Date(appointmentDatetime);
  if (Number.isNaN(requestedDate.getTime()) || requestedDate <= new Date()) {
    return res.status(400).json(fail("Geçmiş tarih veya saat için servis randevusu oluşturulamaz."));
  }

  const conflictingAppointment = await query<{ id: number }>(
    `
      SELECT id
      FROM service_appointments
      WHERE service_type = $1
        AND appointment_datetime = $2
        AND status <> 'cancelled'
      LIMIT 1
    `,
    [serviceType, appointmentDatetime]
  );

  if (conflictingAppointment.rows[0]) {
    return res.status(409).json(fail("Seçtiğiniz saat dolu. Lütfen başka bir saat seçin."));
  }

  const result = await query<{ id: number }>(
    `
      INSERT INTO service_appointments (
        customer_id,
        vehicle_id,
        service_type,
        appointment_datetime,
        complaint_description,
        status
      )
      VALUES ($1, $2, $3, $4, $5, 'pending')
      RETURNING id
    `,
    [customer.id, vehicleId, serviceType, appointmentDatetime, complaintDescription ?? null]
  );

  await createAuditLog({
    userId: req.authUser.id,
    action: "create_service_appointment",
    entityType: "service_appointment",
    entityId: result.rows[0].id,
    newValue: { vehicleId, serviceType, appointmentDatetime },
    ipAddress: req.ip
  });

  await createNotification({
    userId: req.authUser.id,
    title: "Servis randevunuz oluşturuldu",
    message: "Servis randevu talebiniz alındı. Atama ve onay bilgileri bu alanda gösterilecektir."
  });

  return res.status(201).json(ok({ appointmentId: result.rows[0].id }, "Servis randevusu oluşturuldu."));
}

export async function assignTechnician(req: Request, res: Response) {
  const { technicianId } = req.body as { technicianId?: number };

  if (!technicianId) {
    return res.status(400).json(fail("technicianId zorunludur."));
  }

  const technicianResult = await query<{ id: number }>(
    `
      SELECT u.id
      FROM users u
      JOIN roles r ON r.id = u.role_id
      WHERE u.id = $1
        AND r.name = $2
        AND u.is_active = TRUE
      LIMIT 1
    `,
    [technicianId, ROLES.TECHNICIAN]
  );

  if (!technicianResult.rows[0]) {
    return res.status(400).json(fail("Seçilen kullanıcı aktif bir teknisyen değildir."));
  }

  const result = await query(
    `
      UPDATE service_appointments
      SET
        assigned_technician_id = $2,
        status = 'assigned',
        updated_at = NOW()
      WHERE id = $1
      RETURNING id, status, assigned_technician_id
    `,
    [req.params.id, technicianId]
  );

  if (!result.rows[0]) {
    return res.status(404).json(fail("Randevu bulunamadı."));
  }

  const appointmentInfo = await query<{ customer_user_id: number; technician_user_id: number | null }>(
    `
      SELECT u.id AS customer_user_id
           , tech.id AS technician_user_id
      FROM service_appointments sa
      JOIN customers c ON c.id = sa.customer_id
      JOIN users u ON u.id = c.user_id
      LEFT JOIN users tech ON tech.id = sa.assigned_technician_id
      WHERE sa.id = $1
      LIMIT 1
    `,
    [req.params.id]
  );

  if (appointmentInfo.rows[0]) {
    await createNotification({
      userId: appointmentInfo.rows[0].customer_user_id,
      title: "Servis randevusu atandı",
      message: "Servis randevunuz için teknisyen ataması yapıldı."
    });

    if (appointmentInfo.rows[0].technician_user_id) {
      await createNotification({
        userId: appointmentInfo.rows[0].technician_user_id,
        title: "Yeni servis görevi atandı",
        message: "Size yeni bir servis randevusu atandı."
      });
    }
  }

  await createAuditLog({
    userId: req.authUser?.id,
    action: "assign_technician",
    entityType: "service_appointment",
    entityId: String(req.params.id),
    newValue: result.rows[0],
    ipAddress: req.ip
  });

  return res.json(ok(result.rows[0], "Teknisyen atandı."));
}

export async function listOperations(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  if (req.authUser.role === ROLES.CUSTOMER) {
    const ownershipResult = await query<{ id: number }>(
      `
        SELECT sa.id
        FROM service_appointments sa
        JOIN customers c ON c.id = sa.customer_id
        WHERE sa.id = $1
          AND c.user_id = $2
        LIMIT 1
      `,
      [req.params.appointmentId, req.authUser.id]
    );

    if (!ownershipResult.rows[0]) {
      return res.status(403).json(fail("Bu servis operasyonlarını görüntüleme yetkiniz bulunmuyor."));
    }
  }

  if (req.authUser.role === ROLES.TECHNICIAN) {
    const ownershipResult = await query<{ id: number }>(
      `
        SELECT id
        FROM service_appointments
        WHERE id = $1
          AND assigned_technician_id = $2
        LIMIT 1
      `,
      [req.params.appointmentId, req.authUser.id]
    );

    if (!ownershipResult.rows[0]) {
      return res.status(403).json(fail("Bu servis operasyonlarını görüntüleme yetkiniz bulunmuyor."));
    }
  }

  const result = await query(
    `
      SELECT
        so.*,
        u.full_name AS technician_name
      FROM service_operations so
      JOIN users u ON u.id = so.technician_id
      WHERE so.appointment_id = $1
      ORDER BY so.id
    `,
    [req.params.appointmentId]
  );

  return res.json(ok(result.rows));
}

export async function createOperation(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const {
    operationName,
    operationType,
    partPrice,
    laborPrice,
    isCriticalSafety,
    note
  } = req.body as {
    operationName?: string;
    operationType?: string;
    partPrice?: number;
    laborPrice?: number;
    isCriticalSafety?: boolean;
    note?: string;
  };

  if (!operationName || !operationType) {
    return res.status(400).json(fail("operationName ve operationType zorunludur."));
  }

  const appointmentResult = await query<{ assigned_technician_id: number | null; status: string }>(
    `
      SELECT assigned_technician_id, status
      FROM service_appointments
      WHERE id = $1
      LIMIT 1
    `,
    [req.params.appointmentId]
  );

  const appointment = appointmentResult.rows[0];
  if (!appointment) {
    return res.status(404).json(fail("Randevu bulunamadı."));
  }

  if (["completed", "cancelled"].includes(appointment.status)) {
    return res.status(409).json(fail("Tamamlanmış veya iptal edilmiş randevuya operasyon eklenemez."));
  }

  if (Number(appointment.assigned_technician_id) !== Number(req.authUser.id)) {
    return res.status(403).json(fail("Yalnızca atanan teknisyen bu randevuya operasyon ekleyebilir."));
  }

  const totalPrice = Number(partPrice ?? 0) + Number(laborPrice ?? 0);

  const result = await query(
    `
      INSERT INTO service_operations (
        appointment_id,
        technician_id,
        operation_name,
        operation_type,
        part_price,
        labor_price,
        total_price,
        is_critical_safety,
        customer_approval_status,
        manager_review_status,
        note
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'pending', 'not_required', $9)
      RETURNING id, operation_name, total_price, is_critical_safety
    `,
    [
      req.params.appointmentId,
      req.authUser.id,
      operationName,
      operationType,
      partPrice ?? 0,
      laborPrice ?? 0,
      totalPrice,
      isCriticalSafety ?? false,
      note ?? null
    ]
  );

  await query(
    `
      UPDATE service_appointments
      SET
        status = 'waiting_customer_approval',
        updated_at = NOW()
      WHERE id = $1
    `,
    [req.params.appointmentId]
  );

  return res.status(201).json(ok(result.rows[0], "Servis operasyonu eklendi."));
}

export async function approveOperation(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const ownershipResult = await query<{ id: number }>(
    `
      SELECT so.id
      FROM service_operations so
      JOIN service_appointments sa ON sa.id = so.appointment_id
      JOIN customers c ON c.id = sa.customer_id
      WHERE so.id = $1
        AND c.user_id = $2
      LIMIT 1
    `,
    [req.params.id, req.authUser.id]
  );

  if (!ownershipResult.rows[0]) {
    return res.status(403).json(fail("Bu operasyon için onay yetkiniz bulunmuyor."));
  }

  const result = await query(
    `
      UPDATE service_operations
      SET
        customer_approval_status = 'approved',
        updated_at = NOW()
      WHERE id = $1
      RETURNING id, customer_approval_status, is_critical_safety
    `,
    [req.params.id]
  );

  await createAuditLog({
    userId: req.authUser?.id,
    action: "approve_service_operation",
    entityType: "service_operation",
    entityId: String(req.params.id),
    newValue: result.rows[0],
    ipAddress: req.ip
  });

  if (!result.rows[0]) {
    return res.status(404).json(fail("Servis operasyonu bulunamadı."));
  }

  const appointmentResult = await query<{ appointment_id: number }>(
    `
      SELECT appointment_id
      FROM service_operations
      WHERE id = $1
      LIMIT 1
    `,
    [req.params.id]
  );

  if (appointmentResult.rows[0]) {
    await refreshAppointmentWorkStatus(appointmentResult.rows[0].appointment_id);
  }

  return res.json(ok(result.rows[0], "Operasyon onaylandı."));
}

export async function rejectOperation(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const operationResult = await query<{
    id: number;
    appointment_id: number;
    is_critical_safety: boolean;
  }>(
    `
      SELECT so.id, so.appointment_id, so.is_critical_safety
      FROM service_operations so
      JOIN service_appointments sa ON sa.id = so.appointment_id
      JOIN customers c ON c.id = sa.customer_id
      WHERE so.id = $1
        AND c.user_id = $2
      LIMIT 1
    `,
    [req.params.id, req.authUser.id]
  );

  const operation = operationResult.rows[0];
  if (!operation) {
    return res.status(403).json(fail("Bu operasyon için red yetkiniz bulunmuyor."));
  }

  const nextManagerStatus = operation.is_critical_safety ? "pending" : "not_required";

  const result = await query(
    `
      UPDATE service_operations
      SET
        customer_approval_status = 'rejected',
        manager_review_status = $2,
        updated_at = NOW()
      WHERE id = $1
      RETURNING id, customer_approval_status, manager_review_status, is_critical_safety
    `,
    [req.params.id, nextManagerStatus]
  );

  if (operation.is_critical_safety) {
    const managerResult = await query<{ id: number }>(
      `
        SELECT u.id
        FROM users u
        JOIN roles r ON r.id = u.role_id
        WHERE r.name = $1
        ORDER BY u.id
        LIMIT 1
      `,
      [ROLES.SERVICE_MANAGER]
    );

    if (managerResult.rows[0]) {
      await createNotification({
        userId: managerResult.rows[0].id,
        title: "Kritik güvenlik reddi",
        message: "Müşteri kritik bir servis operasyonunu reddetti. İnceleme gerekli."
      });
    }
  }

  await createAuditLog({
    userId: req.authUser?.id,
    action: "reject_service_operation",
    entityType: "service_operation",
    entityId: String(req.params.id),
    newValue: result.rows[0],
    ipAddress: req.ip
  });

  await refreshAppointmentWorkStatus(operation.appointment_id);

  return res.json(
    ok(
      {
        ...result.rows[0],
        warning: operation.is_critical_safety
          ? "Kritik güvenlik işlemi reddedildi. Araç tesliminden önce servis müdürü incelemesi gerekir."
          : null
      },
      "Operasyon reddedildi."
    )
  );
}

export async function reviewCriticalOperation(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const { decision, note } = req.body as {
    decision?: "approved" | "rejected" | "pending";
    note?: string;
  };

  if (!decision) {
    return res.status(400).json(fail("decision zorunludur."));
  }

  const result = await query(
    `
      UPDATE service_operations
      SET
        manager_review_status = $2,
        updated_at = NOW()
      WHERE id = $1
      RETURNING id, manager_review_status
    `,
    [req.params.id, decision]
  );

  if (!result.rows[0]) {
    return res.status(404).json(fail("Servis operasyonu bulunamadı."));
  }

  await query(
    `
      INSERT INTO service_operation_reviews (
        service_operation_id,
        reviewed_by,
        decision,
        note
      )
      VALUES ($1, $2, $3, $4)
    `,
    [req.params.id, req.authUser.id, decision, note ?? null]
  );

  await createAuditLog({
    userId: req.authUser.id,
    action: "review_critical_operation",
    entityType: "service_operation",
    entityId: String(req.params.id),
    newValue: { decision },
    ipAddress: req.ip
  });

  const operationResult = await query<{ appointment_id: number }>(
    `
      SELECT appointment_id
      FROM service_operations
      WHERE id = $1
      LIMIT 1
    `,
    [req.params.id]
  );

  if (operationResult.rows[0]) {
    await refreshAppointmentWorkStatus(operationResult.rows[0].appointment_id);
  }

  return res.json(ok(result.rows[0], "Kritik güvenlik incelemesi kaydedildi."));
}

export async function completeApprovedOperations(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const appointmentResult = await query<{ assigned_technician_id: number | null; customer_user_id: number | null; status: string }>(
    `
      SELECT sa.assigned_technician_id, u.id AS customer_user_id, sa.status
      FROM service_appointments sa
      JOIN customers c ON c.id = sa.customer_id
      JOIN users u ON u.id = c.user_id
      WHERE sa.id = $1
      LIMIT 1
    `,
    [req.params.appointmentId]
  );

  const appointment = appointmentResult.rows[0];
  if (!appointment) {
    return res.status(404).json(fail("Randevu bulunamadı."));
  }

  if (Number(appointment.assigned_technician_id) !== Number(req.authUser.id)) {
    return res.status(403).json(fail("Yalnızca atanan teknisyen operasyonları tamamlayabilir."));
  }

  if (appointment.status === "completed") {
    return res.status(409).json(fail("Bu randevu zaten tamamlanmış görünüyor."));
  }

  if (appointment.status === "cancelled") {
    return res.status(409).json(fail("İptal edilmiş randevu tamamlanamaz."));
  }

  const totalOperations = await query<{ count: string }>(
    `
      SELECT COUNT(*)::text AS count
      FROM service_operations
      WHERE appointment_id = $1
    `,
    [req.params.appointmentId]
  );

  if (Number(totalOperations.rows[0]?.count ?? 0) === 0) {
    return res.status(409).json(fail("Bu randevu için henüz servis operasyonu oluşturulmadı."));
  }

  const pendingCritical = await query<{ count: string }>(
    `
      SELECT COUNT(*)::text AS count
      FROM service_operations
      WHERE appointment_id = $1
        AND (
          (
            customer_approval_status <> 'approved'
            AND NOT (
              is_critical_safety = TRUE
              AND customer_approval_status = 'rejected'
              AND manager_review_status = 'approved'
            )
          )
          OR (is_critical_safety = TRUE AND manager_review_status = 'pending')
        )
    `,
    [req.params.appointmentId]
  );

  if (Number(pendingCritical.rows[0]?.count ?? 0) > 0) {
    return res.status(409).json(fail("Onaysız veya inceleme bekleyen operasyonlar varken tamamlama yapılamaz."));
  }

  await query(
    `
      UPDATE service_appointments
      SET
        status = 'completed',
        updated_at = NOW()
      WHERE id = $1
    `,
    [req.params.appointmentId]
  );

  if (appointment.customer_user_id) {
    await createNotification({
      userId: appointment.customer_user_id,
      title: "Servis işlemi tamamlandı",
      message: "Onaylı servis operasyonlarınız tamamlandı."
    });
  }

  await createAuditLog({
    userId: req.authUser.id,
    action: "complete_service_operations",
    entityType: "service_appointment",
    entityId: String(req.params.appointmentId),
    newValue: { status: "completed" },
    ipAddress: req.ip
  });

  return res.json(ok({ appointmentId: Number(req.params.appointmentId), status: "completed" }, "Operasyonlar tamamlandı."));
}

export async function rescheduleAppointment(req: Request, res: Response) {
  const { appointmentDatetime } = req.body as { appointmentDatetime?: string };

  if (!appointmentDatetime) {
    return res.status(400).json(fail("appointmentDatetime zorunludur."));
  }

  const appointmentResult = await query<{
    service_type: string;
    customer_user_id: number;
  }>(
    `
      SELECT sa.service_type, u.id AS customer_user_id
      FROM service_appointments sa
      JOIN customers c ON c.id = sa.customer_id
      JOIN users u ON u.id = c.user_id
      WHERE sa.id = $1
      LIMIT 1
    `,
    [req.params.id]
  );

  const appointment = appointmentResult.rows[0];
  if (!appointment) {
    return res.status(404).json(fail("Randevu bulunamadı."));
  }

  const dateOnly = appointmentDatetime.slice(0, 10);
  const requestedDate = new Date(appointmentDatetime);
  if (Number.isNaN(requestedDate.getTime()) || requestedDate <= new Date()) {
    return res.status(400).json(fail("Geçmiş tarih veya saat için randevu güncellenemez."));
  }

  const capacity = await getDailyCapacity(appointment.service_type);
  const used = await countAppointmentsForDay(appointment.service_type, dateOnly);

  if (used >= capacity) {
    return res.status(409).json(
      fail("Maalesef bu gün için uygun slot bulunmuyor. Lütfen başka bir gün seçin.")
    );
  }

  const conflictingAppointment = await query<{ id: number }>(
    `
      SELECT id
      FROM service_appointments
      WHERE service_type = $1
        AND appointment_datetime = $2
        AND status <> 'cancelled'
        AND id <> $3
      LIMIT 1
    `,
    [appointment.service_type, appointmentDatetime, req.params.id]
  );

  if (conflictingAppointment.rows[0]) {
    return res.status(409).json(fail("Seçtiğiniz saat dolu. Lütfen başka bir saat seçin."));
  }

  const result = await query(
    `
      UPDATE service_appointments
      SET
        appointment_datetime = $2,
        status = 'approved',
        updated_at = NOW()
      WHERE id = $1
      RETURNING id, appointment_datetime, status
    `,
    [req.params.id, appointmentDatetime]
  );

  await createNotification({
    userId: appointment.customer_user_id,
    title: "Servis randevusu güncellendi",
    message: "Servis randevu tarih/saat bilginiz güncellendi."
  });

  await createAuditLog({
    userId: req.authUser?.id,
    action: "reschedule_service_appointment",
    entityType: "service_appointment",
    entityId: String(req.params.id),
    newValue: result.rows[0],
    ipAddress: req.ip
  });

  return res.json(ok(result.rows[0], "Randevu tarihi güncellendi."));
}

export async function cancelAppointment(req: Request, res: Response) {
  const result = await query<{
    id: number;
    status: string;
    customer_user_id: number;
  }>(
    `
      UPDATE service_appointments sa
      SET
        status = 'cancelled',
        updated_at = NOW()
      FROM customers c
      JOIN users u ON u.id = c.user_id
      WHERE sa.id = $1
        AND c.id = sa.customer_id
      RETURNING sa.id, sa.status, u.id AS customer_user_id
    `,
    [req.params.id]
  );

  const appointment = result.rows[0];
  if (!appointment) {
    return res.status(404).json(fail("Randevu bulunamadı."));
  }

  await createNotification({
    userId: appointment.customer_user_id,
    title: "Servis randevusu iptal edildi",
    message: "Servis randevunuz bayi tarafından iptal edildi."
  });

  await createAuditLog({
    userId: req.authUser?.id,
    action: "cancel_service_appointment",
    entityType: "service_appointment",
    entityId: String(req.params.id),
    newValue: { status: "cancelled" },
    ipAddress: req.ip
  });

  return res.json(ok({ id: appointment.id, status: appointment.status }, "Randevu iptal edildi."));
}

export async function getTechnicianPerformance(_req: Request, res: Response) {
  const result = await query(
    `
      SELECT
        u.id,
        u.full_name,
        COUNT(DISTINCT sa.id)::int AS assigned_jobs,
        COUNT(DISTINCT CASE WHEN sa.status = 'completed' THEN sa.id END)::int AS completed_jobs,
        COALESCE(SUM(CASE WHEN so.customer_approval_status = 'approved' THEN so.total_price ELSE 0 END), 0)::float AS total_revenue
      FROM users u
      JOIN roles r ON r.id = u.role_id
      LEFT JOIN service_appointments sa ON sa.assigned_technician_id = u.id
      LEFT JOIN service_operations so ON so.appointment_id = sa.id
      WHERE r.name = $1
      GROUP BY u.id, u.full_name
      ORDER BY completed_jobs DESC, total_revenue DESC
    `,
    [ROLES.TECHNICIAN]
  );

  return res.json(ok(result.rows));
}

export async function listCriticalCases(_req: Request, res: Response) {
  const result = await query(
    `
      SELECT
        so.id,
        so.operation_name,
        so.total_price,
        so.customer_approval_status,
        so.manager_review_status,
        sa.id AS appointment_id,
        u.full_name AS customer_name,
        v.brand,
        v.model
      FROM service_operations so
      JOIN service_appointments sa ON sa.id = so.appointment_id
      JOIN customers c ON c.id = sa.customer_id
      JOIN users u ON u.id = c.user_id
      JOIN vehicles v ON v.id = sa.vehicle_id
      WHERE so.is_critical_safety = TRUE
        AND so.customer_approval_status = 'rejected'
        AND so.manager_review_status = 'pending'
      ORDER BY so.updated_at DESC
    `
  );

  return res.json(ok(result.rows));
}
