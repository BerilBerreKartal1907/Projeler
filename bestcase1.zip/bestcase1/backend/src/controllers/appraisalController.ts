import type { Request, Response } from "express";
import { randomUUID } from "node:crypto";

import { query } from "../config/db.js";
import { DAMAGE_POINTS, type DamageType } from "../constants/damage.js";
import { fail, ok } from "../utils/apiResponse.js";
import { createAuditLog } from "../utils/audit.js";
import { createNotification } from "../utils/notifications.js";
import { computePreliminaryOffer } from "../services/appraisal/preliminaryOfferService.js";

const APPRAISAL_COOLDOWN_MS = 7 * 24 * 60 * 60 * 1000;

type AppraisalListRow = {
  id: number;
  status: string;
  damage_score: number;
  damage_percentage: string;
  calculated_offer: string | null;
  requires_manager_approval: boolean;
  customer_name: string;
  brand: string;
  model: string;
  year: number;
  mileage: number;
};

function buildVehicleSeed(input: string) {
  return input.split("").reduce((sum, char) => sum + char.charCodeAt(0), 0);
}

function estimateSimulatedTramer(input: {
  vin: string;
  brand: string;
  model: string;
  year: number;
  mileage: number;
  category: string;
  expectedSellingPrice?: number | null;
  declaredTramerAmount?: number | null;
}) {
  const seed = buildVehicleSeed(`${input.vin}${input.brand}${input.model}`);
  const currentYear = new Date().getFullYear();
  const age = Math.max(currentYear - input.year, 0);

  const modelReferenceMap: Record<string, number> = {
    "Audi:A3": 2_640_000,
    "Audi:A4": 3_620_000,
    "Audi:A6": 5_280_000,
    "Audi:Q3": 3_980_000,
    "Audi:Q5": 5_020_000,
    "BMW:320i": 3_280_000,
    "BMW:520i": 5_420_000,
    "BMW:X1": 3_940_000,
    "BMW:X3": 4_480_000,
    "Ford:Focus": 1_420_000,
    "Ford:Kuga": 2_260_000,
    "Ford:Puma": 1_760_000,
    "Ford:Ranger": 2_880_000,
    "Honda:Civic": 2_020_000,
    "Honda:CR-V": 3_360_000,
    "Hyundai:Bayon": 1_360_000,
    "Hyundai:Elantra": 1_860_000,
    "Hyundai:i20": 1_120_000,
    "Hyundai:Tucson": 2_260_000,
    "Kia:Ceed": 1_340_000,
    "Kia:Sorento": 3_420_000,
    "Kia:Sportage": 2_380_000,
    "Kia:Stonic": 1_520_000,
    "Mercedes:A180": 3_140_000,
    "Mercedes:C200": 4_860_000,
    "Mercedes:E200": 6_120_000,
    "Mercedes:GLA": 4_220_000,
    "Mercedes:GLC": 5_580_000,
    "Nissan:Qashqai": 2_080_000,
    "Opel:Astra": 1_340_000,
    "Opel:Grandland": 1_980_000,
    "Opel:Mokka": 1_620_000,
    "Peugeot:2008": 1_760_000,
    "Peugeot:3008": 2_360_000,
    "Peugeot:408": 2_420_000,
    "Renault:Austral": 2_280_000,
    "Renault:Clio": 1_040_000,
    "Renault:Megane": 1_560_000,
    "Skoda:Kodiaq": 3_180_000,
    "Skoda:Octavia": 1_960_000,
    "Skoda:Superb": 2_960_000,
    "Toyota:C-HR": 2_120_000,
    "Toyota:Corolla": 1_820_000,
    "Toyota:RAV4": 3_380_000,
    "Volkswagen:Golf": 1_640_000,
    "Volkswagen:Passat": 2_240_000,
    "Volkswagen:Polo": 1_140_000,
    "Volkswagen:Tiguan": 2_920_000,
    "Volkswagen:Touareg": 5_860_000
  };

  const baseMap: Record<string, number> = {
    sedan: 1_620_000,
    hatchback: 1_260_000,
    suv: 2_120_000,
    pickup: 2_420_000
  };

  const brandMultiplierMap: Record<string, number> = {
    Audi: 1.42,
    BMW: 1.4,
    Mercedes: 1.52,
    Volkswagen: 1.12,
    Toyota: 1.08,
    Honda: 1.1,
    Skoda: 1.05,
    Peugeot: 1.03,
    Hyundai: 1.0,
    Kia: 0.99,
    Ford: 0.97,
    Opel: 0.96,
    Renault: 0.93,
    Nissan: 1.02
  };

  const referenceKey = `${input.brand}:${input.model}`;
  const categoryBaseValue = baseMap[input.category] ?? 1_280_000;
  const brandMultiplier = brandMultiplierMap[input.brand] ?? 1;
  const baseValue = modelReferenceMap[referenceKey] ?? Math.round(categoryBaseValue * brandMultiplier);
  const yearBoost = input.year >= currentYear ? 1.08 : input.year >= currentYear - 1 ? 1.05 : input.year >= currentYear - 2 ? 1.02 : 1;
  const premiumAgingFactor = ["Audi", "BMW", "Mercedes"].includes(input.brand) ? 0.032 : 0.042;
  const ageFactor = Math.max(0.58, 1 - age * premiumAgingFactor);
  const mileageStep = input.mileage > 120_000 ? 0.024 : 0.017;
  const mileageFactor = Math.max(0.72, 1 - Math.floor(input.mileage / 20_000) * mileageStep);
  const trimFactor = 0.985 + (seed % 5) * 0.02;
  const simulatedValue = baseValue * ageFactor * mileageFactor * trimFactor;
  const marketValue = Math.round(simulatedValue * yearBoost);
  const declaredTramerAmount = Math.max(0, Number(input.declaredTramerAmount ?? 0));
  const accidentRecord = declaredTramerAmount > 0;
  const ownerCount = Math.max(1, Math.min(4, 1 + Math.floor(age / 4) + (seed % 2)));
  const heavyDamage = declaredTramerAmount >= Math.max(350_000, marketValue * 0.18);

  return {
    marketValue,
    accidentRecord,
    ownerCount,
    heavyDamage,
    customsProblem: false,
    damageHistoryText: accidentRecord
      ? "Beyan edilen TRAMER tutarına göre araçta kaza kaydı bulunduğu varsayıldı."
      : "Beyan edilen TRAMER tutarına göre araçta kaza kaydı bulunmuyor."
  };
}

async function syncSimulatedTramerRecord(vehicleId: number, declaredTramerAmount?: number | null) {
  const vehicleResult = await query<{
    vin: string;
    brand: string;
    model: string;
    year: number;
    mileage: number;
    category: string;
  }>(
    `
      SELECT vin, brand, model, year, mileage, category
      FROM vehicles
      WHERE id = $1
      LIMIT 1
    `,
    [vehicleId]
  );

  const vehicle = vehicleResult.rows[0];
  if (!vehicle) {
    return;
  }

  const simulatedTramer = estimateSimulatedTramer({
    vin: vehicle.vin,
    brand: vehicle.brand,
    model: vehicle.model,
    year: vehicle.year,
    mileage: vehicle.mileage,
    category: vehicle.category,
    declaredTramerAmount: declaredTramerAmount ?? null
  });

  await query(
    `
      UPDATE simulated_tramer_records
      SET
        market_value = $2,
        accident_record = $3,
        owner_count = $4,
        heavy_damage = $5,
        customs_problem = $6,
        damage_history_text = $7
      WHERE vehicle_id = $1
    `,
    [
      vehicleId,
      simulatedTramer.marketValue,
      simulatedTramer.accidentRecord,
      simulatedTramer.ownerCount,
      simulatedTramer.heavyDamage,
      simulatedTramer.customsProblem,
      simulatedTramer.damageHistoryText
    ]
  );
}

async function ensureDeclaredTramerAmountColumn() {
  await query(`
    ALTER TABLE appraisal_requests
    ADD COLUMN IF NOT EXISTS declared_tramer_amount numeric(12,2)
  `);
}

function formatCooldownMessage(remainingMs: number) {
  const totalMinutes = Math.max(0, Math.ceil(remainingMs / 60000));
  const days = Math.floor(totalMinutes / (60 * 24));
  const hours = Math.floor((totalMinutes % (60 * 24)) / 60);
  const minutes = totalMinutes % 60;
  return `Haftada bir ekspertiz ve pazarlık yapabilirsiniz. Kalan süre: ${days} gün ${hours} saat ${minutes} dakika.`;
}

async function getAppraisalCooldownForUser(userId: number) {
  const latestAppraisalResult = await query<{ created_at: string }>(
    `
      SELECT ar.created_at::text
      FROM appraisal_requests ar
      JOIN customers c ON c.id = ar.customer_id
      WHERE c.user_id = $1
      ORDER BY ar.created_at DESC
      LIMIT 1
    `,
    [userId]
  );

  const latestCreatedAt = latestAppraisalResult.rows[0]?.created_at;
  if (!latestCreatedAt) {
    return { canCreate: true, remainingMs: 0, message: "" };
  }

  const nextAvailableAt = new Date(new Date(latestCreatedAt).getTime() + APPRAISAL_COOLDOWN_MS);
  const remainingMs = nextAvailableAt.getTime() - Date.now();

  if (remainingMs <= 0) {
    return { canCreate: true, remainingMs: 0, message: "" };
  }

  return {
    canCreate: false,
    remainingMs,
    message: formatCooldownMessage(remainingMs)
  };
}

export async function listAppraisals(req: Request, res: Response) {
  const role = req.authUser?.role ?? null;
  const userId = req.authUser?.id ?? null;
  const result = await query<AppraisalListRow>(
    `
      SELECT
        ar.id,
        ar.status,
        ar.damage_score,
        ar.damage_percentage,
        ar.calculated_offer,
        ar.requires_manager_approval,
        u.full_name AS customer_name,
        v.brand,
        v.model,
        v.year,
        v.mileage
      FROM appraisal_requests ar
      JOIN customers c ON c.id = ar.customer_id
      JOIN users u ON u.id = c.user_id
      JOIN vehicles v ON v.id = ar.vehicle_id
      WHERE (
        $1::text IS NULL
        OR $1 <> 'customer'
        OR u.id = $2
      )
      ORDER BY ar.created_at DESC
    `,
    [role, userId]
  );

  return res.json(ok(result.rows));
}

export async function getAppraisal(req: Request, res: Response) {
  const appraisalResult = await query(
    `
      SELECT
        ar.*,
        u.full_name AS customer_name,
        u.email AS customer_email,
        v.plate,
        v.vin,
        v.brand,
        v.model,
        v.year,
        v.mileage,
        v.category,
        str.market_value,
        str.accident_record,
        str.owner_count,
        str.heavy_damage,
        str.customs_problem,
        str.damage_history_text
      FROM appraisal_requests ar
      JOIN customers c ON c.id = ar.customer_id
      JOIN users u ON u.id = c.user_id
      JOIN vehicles v ON v.id = ar.vehicle_id
      LEFT JOIN simulated_tramer_records str ON str.vehicle_id = v.id
      WHERE ar.id = $1
      LIMIT 1
    `,
    [req.params.id]
  );

  const appraisal = appraisalResult.rows[0];
  if (!appraisal) {
    return res.status(404).json(fail("Ekspertiz talebi bulunamadı."));
  }

  if (req.authUser?.role === "customer" && appraisal.customer_id !== req.authUser.id) {
    const ownershipResult = await query<{ id: number }>(
      `
        SELECT ar.id
        FROM appraisal_requests ar
        JOIN customers c ON c.id = ar.customer_id
        WHERE ar.id = $1
          AND c.user_id = $2
        LIMIT 1
      `,
      [req.params.id, req.authUser.id]
    );

    if (!ownershipResult.rows[0]) {
      return res.status(403).json(fail("Bu ekspertiz kaydını görüntüleme yetkiniz bulunmuyor."));
    }
  }

  const damageResult = await query(
    `
      SELECT id, vehicle_part, damage_type, damage_point, note, created_at
      FROM damage_details
      WHERE appraisal_request_id = $1
      ORDER BY id
    `,
    [req.params.id]
  );

  return res.json(
    ok({
      ...appraisal,
      damageDetails: damageResult.rows
    })
  );
}

export async function createAppraisal(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const {
    brand,
    model,
    package: packageName,
    year,
    mileage,
    plate,
    vin,
    category,
    expectedSellingPrice,
    declaredTramerAmount
  } = req.body as {
    brand?: string;
    model?: string;
    package?: string;
    year?: number;
    mileage?: number;
    plate?: string;
    vin?: string;
    category?: string;
    expectedSellingPrice?: number;
    declaredTramerAmount?: number;
  };

  if (!brand || !model || !packageName || !year || mileage === undefined || !category) {
    return res.status(400).json(fail("brand, model, package, year, mileage ve category zorunludur."));
  }

  await ensureDeclaredTramerAmountColumn();
  const resolvedVin = (vin && vin.trim().length >= 5) ? vin.trim() : `SIM-${randomUUID().replace(/-/g, "").slice(0, 14).toUpperCase()}`;

  const customerResult = await query<{ id: number }>(
    `
      SELECT c.id
      FROM customers c
      JOIN users u ON u.id = c.user_id
      WHERE u.id = $1
      LIMIT 1
    `,
    [req.authUser.id]
  );

  const customer = customerResult.rows[0];
  if (!customer) {
    return res.status(403).json(fail("Bu işlem yalnızca müşteri hesabıyla yapılabilir."));
  }

  const cooldown = await getAppraisalCooldownForUser(req.authUser.id);
  if (!cooldown.canCreate) {
    return res.status(429).json(
      fail(cooldown.message, {
        canCreate: false,
        remainingMs: cooldown.remainingMs
      })
    );
  }

  const vehicleResult = await query<{ id: number }>(
    `
      INSERT INTO vehicles (
        owner_customer_id,
        plate,
        vin,
        brand,
        model,
        package,
        year,
        mileage,
        category,
        status
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'in_appraisal')
      RETURNING id
    `,
    [customer.id, plate ?? null, resolvedVin, brand, model, packageName, year, mileage, category]
  );

  const vehicleId = vehicleResult.rows[0].id;
  const simulatedTramer = estimateSimulatedTramer({
    vin: resolvedVin,
    brand,
    model,
    year,
    mileage,
    category,
    expectedSellingPrice: expectedSellingPrice ?? null
    ,
    declaredTramerAmount: declaredTramerAmount ?? null
  });

  await query(
    `
      INSERT INTO simulated_tramer_records (
        vehicle_id,
        market_value,
        accident_record,
        owner_count,
        heavy_damage,
        customs_problem,
        damage_history_text
      )
      VALUES (
        $1,
        $2,
        $3,
        $4,
        $5,
        $6,
        $7
      )
    `,
    [
      vehicleId,
      simulatedTramer.marketValue,
      simulatedTramer.accidentRecord,
      simulatedTramer.ownerCount,
      simulatedTramer.heavyDamage,
      simulatedTramer.customsProblem,
      simulatedTramer.damageHistoryText
    ]
  );

  const appraisalResult = await query<{ id: number }>(
    `
      INSERT INTO appraisal_requests (
        customer_id,
        vehicle_id,
        status,
        expected_selling_price,
        declared_tramer_amount
      )
      VALUES ($1, $2, 'draft', $3, $4)
      RETURNING id
    `,
    [customer.id, vehicleId, expectedSellingPrice ?? null, declaredTramerAmount ?? null]
  );

  await createAuditLog({
    userId: req.authUser.id,
    action: "create_appraisal",
    entityType: "appraisal_request",
    entityId: appraisalResult.rows[0].id,
    newValue: { vehicleId, expectedSellingPrice: expectedSellingPrice ?? null, declaredTramerAmount: declaredTramerAmount ?? null },
    ipAddress: req.ip
  });

  await createNotification({
    userId: req.authUser.id,
    title: "Araç ekspertizi oluşturuldu",
    message: "Araç ekspertiz talebiniz kaydedildi. Hasar bilgilerini tamamladıktan sonra ön teklifiniz oluşturulacaktır."
  });

  return res.status(201).json(
    ok(
      {
        appraisalId: appraisalResult.rows[0].id,
        vehicleId
      },
      "Ekspertiz talebi oluşturuldu."
    )
  );
}

export async function getAppraisalCooldownStatus(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const customerResult = await query<{ id: number }>(
    `
      SELECT c.id
      FROM customers c
      JOIN users u ON u.id = c.user_id
      WHERE u.id = $1
      LIMIT 1
    `,
    [req.authUser.id]
  );

  if (!customerResult.rows[0]) {
    return res.status(403).json(fail("Bu işlem yalnızca müşteri hesabıyla yapılabilir."));
  }

  const cooldown = await getAppraisalCooldownForUser(req.authUser.id);
  return res.json(ok(cooldown));
}

export async function saveDamageDetails(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const appraisalId = Number(req.params.id);
  const { damages } = req.body as {
    damages?: Array<{
      vehiclePart: string;
      damageType: DamageType;
      note?: string | null;
    }>;
  };

  if (!damages || damages.length === 0) {
    return res.status(400).json(fail("En az bir hasar detayı gönderilmelidir."));
  }

  await ensureDeclaredTramerAmountColumn();

  const appraisalResult = await query<{ id: number; vehicle_id: number; expected_selling_price: string | null; declared_tramer_amount: string | null }>(
    `
      SELECT id, vehicle_id, expected_selling_price, declared_tramer_amount
      FROM appraisal_requests
      WHERE id = $1
      LIMIT 1
    `,
    [appraisalId]
  );

  const appraisal = appraisalResult.rows[0];
  if (!appraisal) {
    return res.status(404).json(fail("Ekspertiz talebi bulunamadı."));
  }

  const ownershipResult = await query<{ id: number }>(
    `
      SELECT ar.id
      FROM appraisal_requests ar
      JOIN customers c ON c.id = ar.customer_id
      WHERE ar.id = $1
        AND c.user_id = $2
      LIMIT 1
    `,
    [appraisalId, req.authUser.id]
  );

  if (!ownershipResult.rows[0]) {
    return res.status(403).json(fail("Bu ekspertiz kaydı üzerinde işlem yapma yetkiniz bulunmuyor."));
  }

  await syncSimulatedTramerRecord(
    appraisal.vehicle_id,
    appraisal.declared_tramer_amount ? Number(appraisal.declared_tramer_amount) : 0
  );

  await query("DELETE FROM damage_details WHERE appraisal_request_id = $1", [appraisalId]);

  for (const damage of damages) {
    const damagePoint = DAMAGE_POINTS[damage.damageType];

    await query(
      `
        INSERT INTO damage_details (
          appraisal_request_id,
          vehicle_part,
          damage_type,
          damage_point,
          note
        )
        VALUES ($1, $2, $3, $4, $5)
      `,
      [appraisalId, damage.vehiclePart, damage.damageType, damagePoint, damage.note ?? null]
    );
  }

  const detailResult = await query<{
    vehicle_part: string;
    damage_type: DamageType;
    note: string | null;
  }>(
    `
      SELECT vehicle_part, damage_type, note
      FROM damage_details
      WHERE appraisal_request_id = $1
      ORDER BY id
    `,
    [appraisalId]
  );

  const vehicleResult = await query<{
    mileage: number;
    market_value: string;
    accident_record: boolean;
    owner_count: number;
    heavy_damage: boolean;
    customs_problem: boolean;
  }>(
    `
      SELECT
        v.mileage,
        str.market_value,
        str.accident_record,
        str.owner_count,
        str.heavy_damage,
        str.customs_problem
      FROM vehicles v
      JOIN simulated_tramer_records str ON str.vehicle_id = v.id
      WHERE v.id = $1
      LIMIT 1
    `,
    [appraisal.vehicle_id]
  );

  const vehicle = vehicleResult.rows[0];
  if (!vehicle) {
    return res.status(404).json(fail("Araç TRAMER kaydı bulunamadı."));
  }

  const computed = await computePreliminaryOffer({
    mileage: vehicle.mileage,
    expectedSellingPrice: appraisal.expected_selling_price ? Number(appraisal.expected_selling_price) : null,
    declaredTramerAmount: appraisal.declared_tramer_amount ? Number(appraisal.declared_tramer_amount) : 0,
    tramer: {
      marketValue: Number(vehicle.market_value),
      accidentRecord: vehicle.accident_record,
      ownerCount: vehicle.owner_count,
      heavyDamage: vehicle.heavy_damage,
      customsProblem: vehicle.customs_problem
    },
    damages: detailResult.rows.map((row) => ({
      vehiclePart: row.vehicle_part,
      damageType: row.damage_type,
      note: row.note
    }))
  });

  await query(
    `
      UPDATE appraisal_requests
      SET
        status = $2,
        damage_score = $3,
        damage_percentage = $4,
        tramer_value = $5,
        calculated_offer = $6,
        requires_manager_approval = $7,
        approval_reason = $8,
        updated_at = NOW()
      WHERE id = $1
    `,
    [
      appraisalId,
      computed.requiresManagerApproval ? "pending_manager_approval" : "preliminary_offer_ready",
      computed.damageScore,
      computed.damagePercentage,
      computed.tramerValue,
      computed.calculatedOffer,
      computed.requiresManagerApproval,
      computed.approvalReasons.join(" "),
    ]
  );

  await createNotification({
    userId: req.authUser?.id ?? 0,
    title: "Ön teklif hazırlandı",
    message: computed.requiresManagerApproval
      ? "Ekspertiz başvurunuz yönetici onayına gönderildi."
      : "Ekspertiz başvurunuz için ön teklif hazırlandı."
  });

  await createAuditLog({
    userId: req.authUser?.id,
    action: "calculate_preliminary_offer",
    entityType: "appraisal_request",
    entityId: appraisalId,
    newValue: computed,
    ipAddress: req.ip
  });

  return res.json(
    ok(
      {
        appraisalId,
        ...computed
      },
      "Hasar detayları kaydedildi ve ön teklif hesaplandı."
    )
  );
}

export async function getPreliminaryOffer(req: Request, res: Response) {
  if (req.authUser?.role === "customer") {
    await ensureDeclaredTramerAmountColumn();
    const ownershipResult = await query<{ id: number }>(
      `
        SELECT ar.id
        FROM appraisal_requests ar
        JOIN customers c ON c.id = ar.customer_id
        WHERE ar.id = $1
          AND c.user_id = $2
        LIMIT 1
      `,
      [req.params.id, req.authUser.id]
    );

    if (!ownershipResult.rows[0]) {
      return res.status(403).json(fail("Bu ön teklif kaydını görüntüleme yetkiniz bulunmuyor."));
    }
  }

  const result = await query<{
    id: number;
    vehicle_id: number;
    status: string;
    damage_score: number;
    damage_percentage: string;
    tramer_value: string;
    calculated_offer: string;
    requires_manager_approval: boolean;
    approval_reason: string | null;
    expected_selling_price: string | null;
    declared_tramer_amount: string | null;
    mileage: number;
    accident_record: boolean;
    owner_count: number;
    heavy_damage: boolean;
    customs_problem: boolean;
    damage_history_text: string | null;
  }>(
    `
      SELECT
        ar.id,
        ar.vehicle_id,
        ar.status,
        ar.damage_score,
        ar.damage_percentage,
        ar.tramer_value,
        ar.calculated_offer,
        ar.requires_manager_approval,
        ar.approval_reason,
        ar.expected_selling_price,
        ar.declared_tramer_amount,
        v.mileage,
        str.accident_record,
        str.owner_count,
        str.heavy_damage,
        str.customs_problem,
        str.damage_history_text
      FROM appraisal_requests ar
      JOIN vehicles v ON v.id = ar.vehicle_id
      LEFT JOIN simulated_tramer_records str ON str.vehicle_id = v.id
      WHERE ar.id = $1
      LIMIT 1
    `,
    [req.params.id]
  );

  if (!result.rows[0]) {
    return res.status(404).json(fail("Ön teklif bulunamadı."));
  }

  const damageDetailsResult = await query<{
    vehicle_part: string;
    damage_type: DamageType;
    note: string | null;
  }>(
    `
      SELECT vehicle_part, damage_type, note
      FROM damage_details
      WHERE appraisal_request_id = $1
      ORDER BY id
    `,
    [req.params.id]
  );

  const offer = result.rows[0];
  await syncSimulatedTramerRecord(
    offer.vehicle_id,
    offer.declared_tramer_amount ? Number(offer.declared_tramer_amount) : 0
  );
  const recomputed = await computePreliminaryOffer({
    mileage: offer.mileage,
    expectedSellingPrice: offer.expected_selling_price ? Number(offer.expected_selling_price) : null,
    declaredTramerAmount: offer.declared_tramer_amount ? Number(offer.declared_tramer_amount) : 0,
    tramer: {
      marketValue: Number(offer.tramer_value),
      accidentRecord: offer.accident_record,
      ownerCount: offer.owner_count,
      heavyDamage: offer.heavy_damage,
      customsProblem: offer.customs_problem
    },
    damages: damageDetailsResult.rows.map((item) => ({
      vehiclePart: item.vehicle_part,
      damageType: item.damage_type,
      note: item.note
    }))
  });

  const suggestedMinPrice = Math.round(recomputed.calculatedOffer * 0.98);
  const suggestedMaxPrice = Math.round(recomputed.calculatedOffer * 1.12);
  const normalizedStatus = offer.status === "approved"
    ? "approved"
    : recomputed.requiresManagerApproval
      ? "pending_manager_approval"
      : "preliminary_offer_ready";

  await query(
    `
      UPDATE appraisal_requests
      SET
        status = $2,
        damage_score = $3,
        damage_percentage = $4,
        tramer_value = $5,
        calculated_offer = $6,
        requires_manager_approval = $7,
        approval_reason = $8,
        updated_at = NOW()
      WHERE id = $1
    `,
    [
      offer.id,
      normalizedStatus,
      recomputed.damageScore,
      recomputed.damagePercentage,
      recomputed.tramerValue,
      recomputed.calculatedOffer,
      recomputed.requiresManagerApproval,
      recomputed.approvalReasons.join(" ") || null
    ]
  );

  return res.json(ok({
    ...offer,
    status: normalizedStatus,
    damage_score: recomputed.damageScore,
    damage_percentage: String(recomputed.damagePercentage),
    tramer_value: String(recomputed.tramerValue),
    calculated_offer: String(recomputed.calculatedOffer),
    requires_manager_approval: recomputed.requiresManagerApproval,
    approval_reason: recomputed.approvalReasons.join(" ") || null,
    applied_discounts: recomputed.appliedDiscounts,
    pricing_explanation: "Ön alım teklifi; piyasa değeri, müşteri beklentisi, hasar durumu, beyan edilen Tramer tutarı ve işletme güvenlik payı dikkate alınarak hesaplanır.",
    suggested_min_price: suggestedMinPrice,
    suggested_max_price: suggestedMaxPrice
  }));
}

export async function updateExpectedPrice(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const appraisalId = Number(req.params.id);
  const { expectedSellingPrice } = req.body as { expectedSellingPrice?: number };

  if (typeof expectedSellingPrice !== "number" || expectedSellingPrice <= 0) {
    return res.status(400).json(fail("Geçerli bir beklenti fiyatı zorunludur."));
  }

  const ownershipResult = await query<{ id: number }>(
    `
      SELECT ar.id
      FROM appraisal_requests ar
      JOIN customers c ON c.id = ar.customer_id
      WHERE ar.id = $1
        AND c.user_id = $2
      LIMIT 1
    `,
    [appraisalId, req.authUser.id]
  );

  if (!ownershipResult.rows[0]) {
    return res.status(403).json(fail("Bu ekspertiz kaydı üzerinde işlem yapma yetkiniz bulunmuyor."));
  }

  const appraisalResult = await query<{
    vehicle_id: number;
    declared_tramer_amount: string | null;
  }>(
    `
      SELECT vehicle_id, declared_tramer_amount
      FROM appraisal_requests
      WHERE id = $1
      LIMIT 1
    `,
    [appraisalId]
  );

  const appraisal = appraisalResult.rows[0];
  if (!appraisal) {
    return res.status(404).json(fail("Ekspertiz kaydı bulunamadı."));
  }

  await syncSimulatedTramerRecord(
    appraisal.vehicle_id,
    appraisal.declared_tramer_amount ? Number(appraisal.declared_tramer_amount) : 0
  );

  const damageDetailsResult = await query<{
    vehicle_part: string;
    damage_type: DamageType;
    note: string | null;
  }>(
    `
      SELECT vehicle_part, damage_type, note
      FROM damage_details
      WHERE appraisal_request_id = $1
      ORDER BY id
    `,
    [appraisalId]
  );

  const vehicleResult = await query<{
    mileage: number;
    market_value: string;
    accident_record: boolean;
    owner_count: number;
    heavy_damage: boolean;
    customs_problem: boolean;
  }>(
    `
      SELECT
        v.mileage,
        str.market_value,
        str.accident_record,
        str.owner_count,
        str.heavy_damage,
        str.customs_problem
      FROM vehicles v
      JOIN simulated_tramer_records str ON str.vehicle_id = v.id
      WHERE v.id = $1
      LIMIT 1
    `,
    [appraisal.vehicle_id]
  );

  const vehicle = vehicleResult.rows[0];
  if (!vehicle) {
    return res.status(404).json(fail("Araç bilgisi bulunamadı."));
  }

  const recomputed = await computePreliminaryOffer({
    mileage: vehicle.mileage,
    expectedSellingPrice,
    declaredTramerAmount: appraisal.declared_tramer_amount ? Number(appraisal.declared_tramer_amount) : 0,
    tramer: {
      marketValue: Number(vehicle.market_value),
      accidentRecord: vehicle.accident_record,
      ownerCount: vehicle.owner_count,
      heavyDamage: vehicle.heavy_damage,
      customsProblem: vehicle.customs_problem
    },
    damages: damageDetailsResult.rows.map((item) => ({
      vehiclePart: item.vehicle_part,
      damageType: item.damage_type,
      note: item.note
    }))
  });

  await query(
    `
      UPDATE appraisal_requests
      SET
        expected_selling_price = $2,
        status = $3,
        damage_score = $4,
        damage_percentage = $5,
        tramer_value = $6,
        calculated_offer = $7,
        requires_manager_approval = $8,
        approval_reason = $9,
        updated_at = NOW()
      WHERE id = $1
    `,
    [
      appraisalId,
      expectedSellingPrice,
      recomputed.requiresManagerApproval ? "pending_manager_approval" : "preliminary_offer_ready",
      recomputed.damageScore,
      recomputed.damagePercentage,
      recomputed.tramerValue,
      recomputed.calculatedOffer,
      recomputed.requiresManagerApproval,
      recomputed.approvalReasons.join(" ")
    ]
  );

  return getPreliminaryOffer(req, res);
}

export async function approveAppraisal(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const { note } = req.body as { note?: string };

  const result = await query(
    `
      UPDATE appraisal_requests
      SET
        status = 'approved',
        requires_manager_approval = FALSE,
        manager_id = $2,
        manager_decision = 'approved',
        manager_note = $3,
        updated_at = NOW()
      WHERE id = $1
      RETURNING id, status, manager_decision, manager_note
    `,
    [req.params.id, req.authUser.id, note ?? null]
  );

  if (!result.rows[0]) {
    return res.status(404).json(fail("Ekspertiz talebi bulunamadı."));
  }

  const appraisalResult = await query<{ customer_user_id: number }>(
    `
      SELECT u.id AS customer_user_id
      FROM appraisal_requests ar
      JOIN customers c ON c.id = ar.customer_id
      JOIN users u ON u.id = c.user_id
      WHERE ar.id = $1
      LIMIT 1
    `,
    [req.params.id]
  );

  if (appraisalResult.rows[0]) {
    await createNotification({
      userId: appraisalResult.rows[0].customer_user_id,
      title: "Ekspertiz onaylandı",
      message: "Ön alım teklifiniz yetkili yönetici tarafından onaylandı."
    });
  }

  await createAuditLog({
    userId: req.authUser.id,
    action: "approve_appraisal",
    entityType: "appraisal_request",
    entityId: String(req.params.id),
    newValue: result.rows[0],
    ipAddress: req.ip
  });

  return res.json(ok(result.rows[0], "Ekspertiz talebi onaylandı."));
}

export async function rejectAppraisal(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const { note } = req.body as { note?: string };

  const result = await query(
    `
      UPDATE appraisal_requests
      SET
        status = 'rejected',
        manager_id = $2,
        manager_decision = 'rejected',
        manager_note = $3,
        updated_at = NOW()
      WHERE id = $1
      RETURNING id, status, manager_decision, manager_note
    `,
    [req.params.id, req.authUser.id, note ?? null]
  );

  if (!result.rows[0]) {
    return res.status(404).json(fail("Ekspertiz talebi bulunamadı."));
  }

  await createAuditLog({
    userId: req.authUser.id,
    action: "reject_appraisal",
    entityType: "appraisal_request",
    entityId: String(req.params.id),
    newValue: result.rows[0],
    ipAddress: req.ip
  });

  return res.json(ok(result.rows[0], "Ekspertiz talebi reddedildi."));
}

export async function reviseAppraisalPrice(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const { revisedPrice, note } = req.body as {
    revisedPrice?: number;
    note?: string;
  };

  if (typeof revisedPrice !== "number" || revisedPrice < 0) {
    return res.status(400).json(fail("Geçerli bir revisedPrice değeri zorunludur."));
  }

  const result = await query(
    `
      UPDATE appraisal_requests
      SET
        status = 'approved',
        calculated_offer = $2,
        requires_manager_approval = FALSE,
        manager_id = $3,
        manager_decision = 'revised',
        manager_note = $4,
        updated_at = NOW()
      WHERE id = $1
      RETURNING id, status, calculated_offer, manager_decision, manager_note
    `,
    [req.params.id, revisedPrice, req.authUser.id, note ?? null]
  );

  if (!result.rows[0]) {
    return res.status(404).json(fail("Ekspertiz talebi bulunamadı."));
  }

  await createAuditLog({
    userId: req.authUser.id,
    action: "revise_appraisal_price",
    entityType: "appraisal_request",
    entityId: String(req.params.id),
    newValue: result.rows[0],
    ipAddress: req.ip
  });

  return res.json(ok(result.rows[0], "Ekspertiz fiyatı revize edildi."));
}
