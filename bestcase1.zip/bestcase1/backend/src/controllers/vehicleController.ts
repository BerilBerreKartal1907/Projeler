import type { Request, Response } from "express";

import { query } from "../config/db.js";
import { ROLES } from "../constants/roles.js";
import { fail, ok } from "../utils/apiResponse.js";

export async function listVehicles(req: Request, res: Response) {
  const role = req.authUser?.role ?? null;
  const userId = req.authUser?.id ?? null;
  const result = await query<{
    id: number;
    owner_customer_id: number | null;
    plate: string | null;
    vin: string;
    brand: string;
    model: string;
    year: number;
    mileage: number;
    category: string;
    package: string | null;
    color: string | null;
    purchase_price: string | null;
    list_price: string | null;
    status: string;
  }>(
    `
      SELECT
        id,
        owner_customer_id,
        plate,
        vin,
        brand,
        model,
        year,
        mileage,
        category,
        package,
        color,
        purchase_price,
        list_price,
        status
      FROM vehicles
      WHERE (
        $1::text IS NULL
        OR $1 <> 'customer'
        OR owner_customer_id IN (
          SELECT c.id
          FROM customers c
          WHERE c.user_id = $2
        )
      )
      ORDER BY id
    `,
    [role, userId]
  );

  return res.json(ok(result.rows));
}

export async function getVehicle(req: Request, res: Response) {
  const result = await query(
    `
      SELECT
        v.*,
        str.market_value,
        str.accident_record,
        str.owner_count,
        str.heavy_damage,
        str.customs_problem,
        str.damage_history_text
      FROM vehicles v
      LEFT JOIN simulated_tramer_records str ON str.vehicle_id = v.id
      WHERE v.id = $1
        AND (
          $2::text IS NULL
          OR $2 <> 'customer'
          OR v.owner_customer_id IN (
            SELECT c.id
            FROM customers c
            WHERE c.user_id = $3
          )
        )
      LIMIT 1
    `,
    [req.params.id, req.authUser?.role ?? null, req.authUser?.id ?? null]
  );

  if (!result.rows[0]) {
    const message = req.authUser?.role === ROLES.CUSTOMER
      ? "Bu aracı görüntüleme yetkiniz bulunmuyor."
      : "Araç bulunamadı.";
    return res.status(req.authUser?.role === ROLES.CUSTOMER ? 403 : 404).json(fail(message));
  }

  return res.json(ok(result.rows[0]));
}
