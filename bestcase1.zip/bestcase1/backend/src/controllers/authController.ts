import type { Request, Response } from "express";
import bcrypt from "bcrypt";
import jwt, { type SignOptions } from "jsonwebtoken";
import { randomBytes } from "node:crypto";

import { query } from "../config/db.js";
import { env } from "../config/env.js";
import { fail, ok } from "../utils/apiResponse.js";

type LoginRow = {
  id: number;
  email: string;
  full_name: string;
  password_hash: string;
  role: string;
};

const DEMO_SMS_CODE = "1111";

export const login = async (req: Request, res: Response) => {
  const { email, password } = req.body as { email?: string; password?: string };

  if (!email || !password) {
    return res.status(400).json(fail("E-posta ve şifre zorunludur."));
  }

  const result = await query<LoginRow>(
    `
      SELECT
        u.id,
        u.email,
        u.full_name,
        u.password_hash,
        r.name AS role
      FROM users u
      JOIN roles r ON r.id = u.role_id
      WHERE u.email = $1
        AND u.is_active = TRUE
      LIMIT 1
    `,
    [email]
  );

  const user = result.rows[0];

  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    return res.status(401).json(fail("Geçersiz e-posta veya şifre."));
  }

  const token = jwt.sign(
    {
      sub: String(user.id),
      role: user.role,
      email: user.email
    },
    env.JWT_SECRET,
    { expiresIn: env.JWT_EXPIRES_IN as SignOptions["expiresIn"] }
  );

  return res.json(
    ok({
      token,
      user: {
        id: user.id,
        fullName: user.full_name,
        email: user.email,
        role: user.role
      }
    }, "Giriş başarılı.")
  );
};

export const registerCustomer = async (req: Request, res: Response) => {
  const { fullName, email, password, phone, district, city } = req.body as {
    fullName?: string;
    email?: string;
    password?: string;
    phone?: string;
    district?: string;
    city?: string;
  };

  if (!fullName || !email || !password || !phone || !district || !city) {
    return res.status(400).json(fail("Ad soyad, e-posta, şifre, telefon, ilçe ve şehir zorunludur."));
  }

  const existingUser = await query<{ id: number }>(
    `
      SELECT id
      FROM users
      WHERE email = $1
      LIMIT 1
    `,
    [email]
  );

  if (existingUser.rows[0]) {
    return res.status(409).json(fail("Bu e-posta adresiyle kayıtlı bir kullanıcı zaten var."));
  }

  const customerRole = await query<{ id: number }>(
    `
      SELECT id
      FROM roles
      WHERE name = 'customer'
      LIMIT 1
    `
  );

  if (!customerRole.rows[0]) {
    return res.status(500).json(fail("Müşteri rolü sistemde tanımlı değil."));
  }

  const passwordHash = await bcrypt.hash(password, 10);

  const userResult = await query<{ id: number; email: string; full_name: string }>(
    `
      INSERT INTO users (full_name, email, password_hash, phone, role_id, is_active)
      VALUES ($1, $2, $3, $4, $5, TRUE)
      RETURNING id, email, full_name
    `,
    [fullName, email, passwordHash, phone, customerRole.rows[0].id]
  );

  await query(
    `
      INSERT INTO customers (user_id, phone, address, city)
      VALUES ($1, $2, $3, $4)
    `,
    [userResult.rows[0].id, phone, district, city]
  );

  return res.status(201).json(
    ok(
      {
        id: userResult.rows[0].id,
        email: userResult.rows[0].email,
        fullName: userResult.rows[0].full_name
      },
      "Müşteri hesabınız oluşturuldu. Artık giriş yapabilirsiniz."
    )
  );
};

function maskPhoneNumber(phone: string) {
  const digitsOnly = phone.replace(/[^\d]/g, "");
  if (digitsOnly.length < 4) {
    return phone;
  }

  const visible = digitsOnly.slice(-4);
  return `*** *** ${visible}`;
}

export const forgotPassword = async (req: Request, res: Response) => {
  const { phone } = req.body as { phone?: string };

  if (!phone) {
    return res.status(400).json(fail("Telefon numarası zorunludur."));
  }

  const result = await query<{ id: number; phone: string | null }>(
    `
      SELECT id, phone
      FROM users
      WHERE phone = $1
        AND is_active = TRUE
      LIMIT 1
    `,
    [phone]
  );

  const user = result.rows[0];
  // Kullanıcı bulunamasa bile aynı cevap dönülür; böylece telefon numarası var/yok bilgisi dışarı sızmaz.
  if (!user) {
    return res.json(
      ok(
        {
          phone,
          maskedPhone: maskPhoneNumber(phone),
          resetToken: null,
          expiresInMinutes: 10
        },
        "Telefonunuza SMS gönderildi."
      )
    );
  }

  await query(
    `
      UPDATE password_reset_tokens
      SET used_at = NOW()
      WHERE user_id = $1
        AND used_at IS NULL
    `,
    [user.id]
  );

  const resetToken = randomBytes(24).toString("hex");

  // Demo akışında token response içinde döner; gerçek SMS entegrasyonunda ayrı kanaldan iletilmelidir.
  await query(
    `
      INSERT INTO password_reset_tokens (user_id, token, expires_at)
      VALUES ($1, $2, NOW() + INTERVAL '10 minutes')
    `,
    [user.id, resetToken]
  );

  return res.json(
    ok(
      {
        phone,
        maskedPhone: maskPhoneNumber(user.phone ?? phone),
        resetToken,
        expiresInMinutes: 10
      },
      "Telefonunuza SMS gönderildi."
    )
  );
};

export const resetPassword = async (req: Request, res: Response) => {
  const { token, smsCode, newPassword } = req.body as {
    token?: string;
    smsCode?: string;
    newPassword?: string;
  };

  // Demo ortamında gerçek SMS sağlayıcısı yerine sabit doğrulama kodu kullanılır.
  if (smsCode !== DEMO_SMS_CODE) {
    return res.status(400).json(fail("SMS doğrulama kodu geçersiz."));
  }

  const tokenResult = await query<{ id: number; user_id: number }>(
    `
      SELECT id, user_id
      FROM password_reset_tokens
      WHERE token = $1
        AND used_at IS NULL
        AND expires_at > NOW()
      LIMIT 1
    `,
    [token]
  );

  const resetRow = tokenResult.rows[0];
  if (!resetRow) {
    return res.status(400).json(fail("Şifre sıfırlama token'ı geçersiz veya süresi dolmuş."));
  }

  const passwordHash = await bcrypt.hash(String(newPassword), 10);

  await query(
    `
      UPDATE users
      SET
        password_hash = $2,
        updated_at = NOW()
      WHERE id = $1
    `,
    [resetRow.user_id, passwordHash]
  );

  await query(
    `
      UPDATE password_reset_tokens
      SET used_at = NOW()
      WHERE id = $1
    `,
    [resetRow.id]
  );

  return res.json(ok(null, "Şifreniz başarıyla güncellendi."));
};

export const me = async (req: Request, res: Response) => {
  if (!req.authUser) {
    return res.status(401).json(fail("Oturum bulunamadı."));
  }

  const result = await query<{
    id: number;
    email: string;
    full_name: string;
    phone: string | null;
    is_active: boolean;
    role: string;
  }>(
    `
      SELECT
        u.id,
        u.email,
        u.full_name,
        u.phone,
        u.is_active,
        r.name AS role
      FROM users u
      JOIN roles r ON r.id = u.role_id
      WHERE u.id = $1
      LIMIT 1
    `,
    [req.authUser.id]
  );

  const user = result.rows[0];

  if (!user) {
    return res.status(404).json(fail("Kullanıcı bulunamadı."));
  }

  return res.json(
    ok({
      id: user.id,
      email: user.email,
      fullName: user.full_name,
      phone: user.phone,
      isActive: user.is_active,
      role: user.role
    })
  );
};
