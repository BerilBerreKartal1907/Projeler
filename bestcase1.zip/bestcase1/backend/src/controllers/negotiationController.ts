import type { Request, Response } from "express";

import { query } from "../config/db.js";
import { ROLES } from "../constants/roles.js";
import { fail, ok } from "../utils/apiResponse.js";
import { createAuditLog } from "../utils/audit.js";
import { createNotification } from "../utils/notifications.js";
import {
  appendNegotiationMessage,
  evaluateCounterOffer,
  getNegotiationById
} from "../services/negotiation/negotiationService.js";

async function markAcceptedNegotiationAsAcquired(negotiationId: number) {
  const result = await query<{
    vehicle_id: number;
    current_dealer_offer: string;
  }>(
    `
      SELECT
        ar.vehicle_id,
        n.current_dealer_offer
      FROM negotiations n
      JOIN appraisal_requests ar ON ar.id = n.appraisal_request_id
      WHERE n.id = $1
      LIMIT 1
    `,
    [negotiationId]
  );

  const row = result.rows[0];
  if (!row) {
    return null;
  }

  await query(
    `
      UPDATE sales_listings
      SET status = 'cancelled', updated_at = NOW()
      WHERE vehicle_id = $1
        AND status <> 'sold'
    `,
    [row.vehicle_id]
  );

  const vehicleResult = await query<{ id: number; status: string }>(
    `
      UPDATE vehicles
      SET
        purchase_price = $2,
        owner_customer_id = NULL,
        status = 'acquired',
        updated_at = NOW()
      WHERE id = $1
      RETURNING id, status
    `,
    [row.vehicle_id, Number(row.current_dealer_offer)]
  );

  return vehicleResult.rows[0] ?? null;
}

async function ensureCustomerOwnsNegotiation(negotiationId: number, userId: number) {
  const result = await query<{ id: number }>(
    `
      SELECT n.id
      FROM negotiations n
      JOIN customers c ON c.id = n.customer_id
      WHERE n.id = $1
        AND c.user_id = $2
      LIMIT 1
    `,
    [negotiationId, userId]
  );

  return Boolean(result.rows[0]);
}

export async function listNegotiations(req: Request, res: Response) {
  const role = req.authUser?.role ?? null;
  const userId = req.authUser?.id ?? null;
  const result = await query(
    `
      SELECT
        n.id,
        n.appraisal_request_id,
        n.system_offer,
        n.customer_expected_price,
        n.current_dealer_offer,
        n.max_authorized_offer,
        n.increment_amount,
        n.auto_negotiation_enabled,
        n.status,
        n.result,
        u.full_name AS customer_name,
        v.brand,
        v.model,
        ar.calculated_offer
      FROM negotiations n
      JOIN appraisal_requests ar ON ar.id = n.appraisal_request_id
      JOIN customers c ON c.id = n.customer_id
      JOIN users u ON u.id = c.user_id
      JOIN vehicles v ON v.id = ar.vehicle_id
      WHERE (
        $1::text IS NULL
        OR $1 <> 'customer'
        OR u.id = $2
      )
      ORDER BY n.updated_at DESC
    `,
    [role, userId]
  );

  return res.json(ok(result.rows));
}

export async function getNegotiation(req: Request, res: Response) {
  const negotiationResult = await query(
    `
      SELECT
        n.*,
        u.full_name AS customer_name,
        v.brand,
        v.model,
        v.year,
        ar.calculated_offer,
        ar.requires_manager_approval
      FROM negotiations n
      JOIN appraisal_requests ar ON ar.id = n.appraisal_request_id
      JOIN customers c ON c.id = n.customer_id
      JOIN users u ON u.id = c.user_id
      JOIN vehicles v ON v.id = ar.vehicle_id
      WHERE n.id = $1
      LIMIT 1
    `,
    [req.params.id]
  );

  const negotiation = negotiationResult.rows[0];
  if (!negotiation) {
    return res.status(404).json(fail("Pazarlık kaydı bulunamadı."));
  }

  if (req.authUser?.role === ROLES.CUSTOMER) {
    const isOwner = await ensureCustomerOwnsNegotiation(Number(req.params.id), req.authUser.id);
    if (!isOwner) {
      return res.status(403).json(fail("Bu pazarlık kaydını görüntüleme yetkiniz bulunmuyor."));
    }
  }

  const historyResult = await query(
    `
      SELECT id, sender_type, message_type, offered_price, note, created_at
      FROM negotiation_messages
      WHERE negotiation_id = $1
      ORDER BY id
    `,
    [req.params.id]
  );

  return res.json(
    ok({
      ...negotiation,
      history: historyResult.rows
    })
  );
}

export async function createNegotiation(req: Request, res: Response) {
  const { appraisalRequestId } = req.body as { appraisalRequestId?: number };

  if (!appraisalRequestId) {
    return res.status(400).json(fail("appraisalRequestId zorunludur."));
  }

  const appraisalResult = await query<{
    id: number;
    customer_id: number;
    customer_user_id: number;
    status: string;
    calculated_offer: string | null;
    expected_selling_price: string | null;
  }>(
    `
      SELECT
        ar.id,
        ar.customer_id,
        c.user_id AS customer_user_id,
        ar.status,
        ar.calculated_offer,
        ar.expected_selling_price
      FROM appraisal_requests ar
      JOIN customers c ON c.id = ar.customer_id
      WHERE ar.id = $1
      LIMIT 1
    `,
    [appraisalRequestId]
  );

  const appraisal = appraisalResult.rows[0];
  if (!appraisal || !appraisal.calculated_offer) {
    return res.status(404).json(fail("Geçerli bir ekspertiz teklifi bulunamadı."));
  }

  if (req.authUser?.role === ROLES.CUSTOMER && Number(appraisal.customer_user_id) !== Number(req.authUser.id)) {
    return res.status(403).json(fail("Bu ekspertiz için pazarlık başlatma yetkiniz bulunmuyor."));
  }

  if (!["preliminary_offer_ready", "approved"].includes(appraisal.status)) {
    return res.status(409).json(fail("Pazarlık yalnızca hazır veya onaylanmış ön teklifler için başlatılabilir."));
  }

  const existing = await query<{ id: number }>(
    `SELECT id FROM negotiations WHERE appraisal_request_id = $1 LIMIT 1`,
    [appraisalRequestId]
  );

  if (existing.rows[0]) {
    return res.json(ok({ negotiationId: existing.rows[0].id }, "Pazarlık zaten mevcut."));
  }

  const systemOffer = Number(appraisal.calculated_offer);
  const initialExpectedPrice = appraisal.expected_selling_price ? Number(appraisal.expected_selling_price) : null;
  const maxAuthorizedOffer = Math.round(systemOffer * 2);
  const incrementAmount = Math.max(5000, Math.round(systemOffer * 0.015));

  const result = await query<{ id: number }>(
    `
      INSERT INTO negotiations (
        appraisal_request_id,
        customer_id,
        system_offer,
        customer_expected_price,
        current_dealer_offer,
        max_authorized_offer,
        increment_amount,
        auto_negotiation_enabled,
        status
      )
      VALUES ($1, $2, $3, $4, $3, $5, $6, TRUE, 'open')
      RETURNING id
    `,
    [appraisalRequestId, appraisal.customer_id, systemOffer, initialExpectedPrice, maxAuthorizedOffer, incrementAmount]
  );

  await appendNegotiationMessage({
    negotiationId: result.rows[0].id,
    senderType: "system",
    messageType: "initial_offer",
    offeredPrice: systemOffer,
    note: "Sistem ön teklif üzerinden pazarlık başlattı."
  });

  return res.status(201).json(ok({ negotiationId: result.rows[0].id }, "Pazarlık başlatıldı."));
}

export async function submitCustomerExpectation(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const { expectedPrice } = req.body as { expectedPrice?: number };
  if (typeof expectedPrice !== "number" || expectedPrice <= 0) {
    return res.status(400).json(fail("Geçerli bir expectedPrice zorunludur."));
  }

  const negotiation = await getNegotiationById(Number(req.params.id));
  if (!negotiation) {
    return res.status(404).json(fail("Pazarlık kaydı bulunamadı."));
  }

  const isOwner = await ensureCustomerOwnsNegotiation(Number(req.params.id), req.authUser.id);
  if (!isOwner) {
    return res.status(403).json(fail("Bu pazarlık kaydı üzerinde işlem yapma yetkiniz bulunmuyor."));
  }

  if (["accepted", "rejected", "cancelled"].includes(String(negotiation.status))) {
    return res.status(409).json(fail("Bu pazarlık tamamlandı. Yeni teklif gönderilemez."));
  }

  if (
    negotiation.customer_expected_price !== null
    && Number(negotiation.customer_expected_price) === expectedPrice
  ) {
    return res.status(400).json(fail("Aynı fiyatı tekrar gönderemezsiniz. Fiyatı indirmek istemiyorsanız Toplantı İste butonuna tıklayın."));
  }

  if (
    negotiation.customer_expected_price !== null
    && expectedPrice > Number(negotiation.customer_expected_price)
  ) {
    return res.status(400).json(fail("Beklenti fiyatınızı tekrar yükseltemezsiniz. Daha fazla inmek istemiyorsanız Toplantı İste butonuna tıklayın."));
  }

  if (
    negotiation.customer_expected_price !== null
    && expectedPrice > Number(negotiation.current_dealer_offer)
  ) {
    const previousExpectation = Number(negotiation.customer_expected_price);
    const systemOffer = Number(negotiation.system_offer);
    const currentDealerOffer = Number(negotiation.current_dealer_offer);
    const priceGap = Math.abs(previousExpectation - currentDealerOffer);
    const isCloseRange = priceGap <= Math.max(15_000, Math.round(currentDealerOffer * 0.01));
    const minimumDecreaseRate = systemOffer < 600_000 ? 0.01 : 0.005;
    const minimumDecrease = isCloseRange
      ? 750
      : Math.max(5000, Math.round(systemOffer * minimumDecreaseRate));
    const requiredMaximumExpectation = previousExpectation - minimumDecrease;

    if (expectedPrice > requiredMaximumExpectation) {
      return res.status(400).json(
        fail(
          `Bu turda en az ${minimumDecrease.toLocaleString("tr-TR")} TL indirim yapmanız gerekir. En fazla ${requiredMaximumExpectation.toLocaleString("tr-TR")} TL girebilirsiniz. Küçük fiyat değişiklikleri için Toplantı İste seçeneğini kullanın.`
        )
      );
    }
  }

  const decision = evaluateCounterOffer({
    systemOffer: Number(negotiation.system_offer),
    customerExpectedPrice: expectedPrice,
    currentDealerOffer: Number(negotiation.current_dealer_offer),
    maxAuthorizedOffer: Number(negotiation.max_authorized_offer),
    incrementAmount: Number(negotiation.increment_amount),
    autoNegotiationEnabled: negotiation.auto_negotiation_enabled
  });

  await query(
    `
      UPDATE negotiations
      SET
        customer_expected_price = $2,
        current_dealer_offer = $3,
        status = $4,
        updated_at = NOW()
      WHERE id = $1
    `,
    [req.params.id, expectedPrice, decision.nextDealerOffer, decision.nextStatus]
  );

  await appendNegotiationMessage({
    negotiationId: Number(req.params.id),
    senderUserId: req.authUser.id,
    senderType: "customer",
    messageType: "customer_expectation",
    offeredPrice: expectedPrice,
    note: "Müşteri beklenti fiyatını iletti."
  });

  if (decision.nextDealerOffer !== Number(negotiation.current_dealer_offer) || decision.nextStatus === "accepted") {
    await appendNegotiationMessage({
      negotiationId: Number(req.params.id),
      senderType: "system",
      messageType: decision.nextStatus === "accepted" ? "accepted_offer" : "counter_offer",
      offeredPrice: decision.nextDealerOffer,
      note: decision.resultMessage
    });
  }

  await createAuditLog({
    userId: req.authUser.id,
    action: "submit_customer_expectation",
    entityType: "negotiation",
    entityId: String(req.params.id),
    newValue: {
      expectedPrice,
      status: decision.nextStatus,
      currentDealerOffer: decision.nextDealerOffer
    },
    ipAddress: req.ip
  });

  if (decision.requiresManagerReview) {
    const managerResult = await query<{ id: number }>(
      `
        SELECT u.id
        FROM users u
        JOIN roles r ON r.id = u.role_id
        WHERE r.name = $1
        ORDER BY u.id
        LIMIT 1
      `,
      [ROLES.AUTHORIZED_MANAGER]
    );

    if (managerResult.rows[0]) {
      await createNotification({
        userId: managerResult.rows[0].id,
        title: "Pazarlık incelemesi gerekli",
        message: "Bir müşteri beklentisi yetkili teklif limitini aştı."
      });
    }
  }

  return res.json(
    ok({
      negotiationId: Number(req.params.id),
      customerExpectedPrice: expectedPrice,
      currentDealerOffer: decision.nextDealerOffer,
      status: decision.nextStatus,
      requiresManagerReview: decision.requiresManagerReview,
      resultMessage: decision.resultMessage
    })
  );
}

export async function acceptNegotiation(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const isOwner = await ensureCustomerOwnsNegotiation(Number(req.params.id), req.authUser.id);
  if (!isOwner) {
    return res.status(403).json(fail("Bu pazarlık kaydı üzerinde işlem yapma yetkiniz bulunmuyor."));
  }

  await query(
    `
      UPDATE negotiations
      SET
        status = 'accepted',
        result = 'sold',
        updated_at = NOW()
      WHERE id = $1
    `,
    [req.params.id]
  );

  const acquiredVehicle = await markAcceptedNegotiationAsAcquired(Number(req.params.id));

  await appendNegotiationMessage({
    negotiationId: Number(req.params.id),
    senderType: "customer",
    messageType: "accepted",
    note: "Müşteri mevcut bayi teklifini kabul etti."
  });

  await createAuditLog({
    userId: req.authUser?.id,
    action: "accept_negotiation",
    entityType: "negotiation",
    entityId: String(req.params.id),
    newValue: { status: "accepted", vehicleStatus: acquiredVehicle?.status ?? null },
    ipAddress: req.ip
  });

  return res.json(ok({ id: Number(req.params.id), status: "accepted", vehicleStatus: acquiredVehicle?.status ?? null }, "Pazarlık kabul edildi ve araç bayi stok adaylarına alındı."));
}

export async function rejectNegotiation(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const isOwner = req.authUser.role === ROLES.CUSTOMER
    ? await ensureCustomerOwnsNegotiation(Number(req.params.id), req.authUser.id)
    : true;
  if (!isOwner) {
    return res.status(403).json(fail("Bu pazarlık kaydı üzerinde işlem yapma yetkiniz bulunmuyor."));
  }

  await query(
    `
      UPDATE negotiations
      SET
        status = 'rejected',
        result = 'no_deal',
        updated_at = NOW()
      WHERE id = $1
    `,
    [req.params.id]
  );

  await appendNegotiationMessage({
    negotiationId: Number(req.params.id),
    senderUserId: req.authUser.id,
    senderType: req.authUser.role === ROLES.CUSTOMER ? "customer" : "manager",
    messageType: "rejected",
    note: req.authUser.role === ROLES.CUSTOMER
      ? "Müşteri mevcut teklifi reddetti."
      : "Yetkili yönetici pazarlığı iptal etti."
  });

  await createAuditLog({
    userId: req.authUser?.id,
    action: "reject_negotiation",
    entityType: "negotiation",
    entityId: String(req.params.id),
    newValue: { status: "rejected" },
    ipAddress: req.ip
  });

  return res.json(ok({ id: Number(req.params.id), status: "rejected" }, "Pazarlık reddedildi."));
}

export async function approveNegotiation(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const negotiation = await getNegotiationById(Number(req.params.id));
  if (!negotiation) {
    return res.status(404).json(fail("Pazarlık kaydı bulunamadı."));
  }

  if (["accepted", "rejected", "cancelled"].includes(String(negotiation.status))) {
    return res.status(409).json(fail("Tamamlanmış pazarlık üzerinde işlem yapılamaz."));
  }

  const customerExpectedPrice = negotiation.customer_expected_price
    ? Number(negotiation.customer_expected_price)
    : Number(negotiation.current_dealer_offer);
  const approvedOffer = Math.max(Number(negotiation.current_dealer_offer), customerExpectedPrice);

  await query(
    `
      UPDATE negotiations
      SET
        current_dealer_offer = $2,
        max_authorized_offer = GREATEST(max_authorized_offer, $2),
        status = 'accepted',
        result = 'sold',
        updated_at = NOW()
      WHERE id = $1
    `,
    [req.params.id, approvedOffer]
  );

  const acquiredVehicle = await markAcceptedNegotiationAsAcquired(Number(req.params.id));

  await appendNegotiationMessage({
    negotiationId: Number(req.params.id),
    senderUserId: req.authUser.id,
    senderType: "manager",
    messageType: "manager_approved",
    offeredPrice: approvedOffer,
    note: "Yetkili yönetici pazarlığı onayladı."
  });

  await createAuditLog({
    userId: req.authUser.id,
    action: "approve_negotiation",
    entityType: "negotiation",
    entityId: String(req.params.id),
    newValue: { status: "accepted", currentDealerOffer: approvedOffer, vehicleStatus: acquiredVehicle?.status ?? null },
    ipAddress: req.ip
  });

  return res.json(ok({ id: Number(req.params.id), status: "accepted", vehicleStatus: acquiredVehicle?.status ?? null }, "Pazarlık yönetici tarafından onaylandı ve araç bayi stok adaylarına alındı."));
}

export async function requestNegotiationMeeting(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const isOwner = await ensureCustomerOwnsNegotiation(Number(req.params.id), req.authUser.id);
  if (!isOwner) {
    return res.status(403).json(fail("Bu pazarlık kaydı üzerinde işlem yapma yetkiniz bulunmuyor."));
  }

  await appendNegotiationMessage({
    negotiationId: Number(req.params.id),
    senderType: "customer",
    messageType: "meeting_request",
    note: "Müşteri yüz yüze görüşme talep etti."
  });

  await createAuditLog({
    userId: req.authUser.id,
    action: "request_negotiation_meeting",
    entityType: "negotiation",
    entityId: String(req.params.id),
    newValue: { status: "meeting_requested" },
    ipAddress: req.ip
  });

  return res.json(ok({ id: Number(req.params.id) }, "Toplantı talebi kaydedildi."));
}

export async function updateNegotiationSettings(req: Request, res: Response) {
  const { maxAuthorizedOffer, incrementAmount, autoNegotiationEnabled } = req.body as {
    maxAuthorizedOffer?: number;
    incrementAmount?: number;
    autoNegotiationEnabled?: boolean;
  };

  const negotiationResult = await query<{ current_dealer_offer: string }>(
    `
      SELECT current_dealer_offer::text
      FROM negotiations
      WHERE id = $1
      LIMIT 1
    `,
    [req.params.id]
  );

  const negotiation = negotiationResult.rows[0];
  if (!negotiation) {
    return res.status(404).json(fail("Pazarlık kaydı bulunamadı."));
  }

  if (
    typeof maxAuthorizedOffer === "number"
    && maxAuthorizedOffer < Number(negotiation.current_dealer_offer)
  ) {
    return res.status(400).json(
      fail("Yeni üst limit mevcut bayi teklifinden düşük olamaz.")
    );
  }

  const result = await query(
    `
      UPDATE negotiations
      SET
        max_authorized_offer = COALESCE($2, max_authorized_offer),
        increment_amount = COALESCE($3, increment_amount),
        auto_negotiation_enabled = COALESCE($4, auto_negotiation_enabled),
        status = CASE WHEN status = 'pending_manager_review' THEN 'auto_negotiating' ELSE status END,
        updated_at = NOW()
      WHERE id = $1
      RETURNING id, max_authorized_offer, increment_amount, auto_negotiation_enabled, status
    `,
    [
      req.params.id,
      maxAuthorizedOffer ?? null,
      incrementAmount ?? null,
      autoNegotiationEnabled ?? null
    ]
  );

  await createAuditLog({
    userId: req.authUser?.id,
    action: "update_negotiation_settings",
    entityType: "negotiation",
    entityId: String(req.params.id),
    newValue: result.rows[0],
    ipAddress: req.ip
  });

  return res.json(ok(result.rows[0], "Pazarlık ayarları güncellendi."));
}
