import type { Request, Response } from "express";

import { query } from "../config/db.js";
import { fail, ok } from "../utils/apiResponse.js";

export async function listCustomers(_req: Request, res: Response) {
  const result = await query<{
    id: number;
    user_id: number;
    full_name: string;
    email: string;
    phone: string | null;
    address: string | null;
    city: string | null;
  }>(
    `
      SELECT
        c.id,
        c.user_id,
        u.full_name,
        u.email,
        c.phone,
        c.address,
        c.city
      FROM customers c
      JOIN users u ON u.id = c.user_id
      ORDER BY c.id
    `
  );

  return res.json(ok(result.rows));
}

export async function getCustomer(req: Request, res: Response) {
  const result = await query<{
    id: number;
    user_id: number;
    full_name: string;
    email: string;
    phone: string | null;
    address: string | null;
    city: string | null;
    national_id: string | null;
  }>(
    `
      SELECT
        c.id,
        c.user_id,
        u.full_name,
        u.email,
        c.phone,
        c.address,
        c.city,
        c.national_id
      FROM customers c
      JOIN users u ON u.id = c.user_id
      WHERE c.id = $1
      LIMIT 1
    `,
    [req.params.id]
  );

  if (!result.rows[0]) {
    return res.status(404).json(fail("Müşteri bulunamadı."));
  }

  return res.json(ok(result.rows[0]));
}

export async function getMyCustomerProfile(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const result = await query<{
    id: number;
    user_id: number;
    full_name: string;
    email: string;
    phone: string | null;
    address: string | null;
    city: string | null;
    national_id: string | null;
  }>(
    `
      SELECT
        c.id,
        c.user_id,
        u.full_name,
        u.email,
        c.phone,
        c.address,
        c.city,
        c.national_id
      FROM customers c
      JOIN users u ON u.id = c.user_id
      WHERE u.id = $1
      LIMIT 1
    `,
    [req.authUser.id]
  );

  if (!result.rows[0]) {
    return res.status(404).json(fail("Müşteri profili bulunamadı."));
  }

  return res.json(ok(result.rows[0]));
}

export async function updateMyCustomerProfile(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const { fullName, phone, address, city } = req.body as {
    fullName?: string;
    phone?: string | null;
    address?: string | null;
    city?: string | null;
  };

  await query(
    `
      UPDATE users
      SET
        full_name = COALESCE($2, full_name),
        phone = COALESCE($3, phone),
        updated_at = NOW()
      WHERE id = $1
    `,
    [req.authUser.id, fullName ?? null, phone ?? null]
  );

  const result = await query(
    `
      UPDATE customers
      SET
        phone = COALESCE($2, phone),
        address = COALESCE($3, address),
        city = COALESCE($4, city),
        updated_at = NOW()
      WHERE user_id = $1
      RETURNING id, user_id, phone, address, city
    `,
    [req.authUser.id, phone ?? null, address ?? null, city ?? null]
  );

  if (!result.rows[0]) {
    return res.status(404).json(fail("Müşteri profili bulunamadı."));
  }

  return res.json(ok(result.rows[0], "Profil güncellendi."));
}
