import type { Request, Response } from "express";

import { query } from "../config/db.js";
import { fail, ok } from "../utils/apiResponse.js";
import { createAuditLog } from "../utils/audit.js";

export async function listSystemParameters(_req: Request, res: Response) {
  const result = await query(
    `
      SELECT id, key, value, description, updated_by, updated_at
      FROM system_parameters
      ORDER BY key
    `
  );

  return res.json(ok(result.rows));
}

export async function updateSystemParameter(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const { value, description } = req.body as { value?: string; description?: string };
  if (value === undefined) {
    return res.status(400).json(fail("value zorunludur."));
  }

  const result = await query(
    `
      UPDATE system_parameters
      SET
        value = $2,
        description = COALESCE($3, description),
        updated_by = $4,
        updated_at = NOW()
      WHERE key = $1
      RETURNING id, key, value, description, updated_by, updated_at
    `,
    [req.params.key, value, description ?? null, req.authUser.id]
  );

  if (!result.rows[0]) {
    return res.status(404).json(fail("Sistem parametresi bulunamadı."));
  }

  await createAuditLog({
    userId: req.authUser.id,
    action: "update_system_parameter",
    entityType: "system_parameter",
    entityId: String(req.params.key),
    newValue: result.rows[0],
    ipAddress: req.ip
  });

  return res.json(ok(result.rows[0], "Sistem parametresi güncellendi."));
}
