import type { Request, Response } from "express";

import { query } from "../config/db.js";
import { calculateFinancing } from "../services/finance/creditCalculationService.js";
import { fail, ok } from "../utils/apiResponse.js";
import { createAuditLog } from "../utils/audit.js";

export async function listCreditCalculations(req: Request, res: Response) {
  const role = req.authUser?.role ?? null;
  const userId = req.authUser?.id ?? null;

  const result = await query(
    `
      SELECT
        cc.*,
        u.full_name AS customer_name,
        v.brand,
        v.model
      FROM credit_calculations cc
      JOIN customers c ON c.id = cc.customer_id
      JOIN users u ON u.id = c.user_id
      JOIN vehicles v ON v.id = cc.vehicle_id
      WHERE (
        $1::text IS NULL
        OR $1 <> 'customer'
        OR u.id = $2
      )
      ORDER BY cc.created_at DESC
    `,
    [role, userId]
  );

  return res.json(ok(result.rows));
}

export async function createCreditCalculation(req: Request, res: Response) {
  if (!req.authUser) {
    return res.status(401).json(fail("Giriş yapılması gerekiyor."));
  }

  const {
    vehicleId,
    vehiclePrice,
    downPayment,
    maturityMonths,
    monthlyInterestRate
  } = req.body as {
    vehicleId?: number;
    vehiclePrice?: number;
    downPayment?: number;
    maturityMonths?: number;
    monthlyInterestRate?: number;
  };

  if (
    typeof vehiclePrice !== "number" ||
    typeof downPayment !== "number" ||
    typeof maturityMonths !== "number" ||
    typeof monthlyInterestRate !== "number"
  ) {
    return res.status(400).json(fail("vehiclePrice, downPayment, maturityMonths ve monthlyInterestRate zorunludur."));
  }

  if (downPayment > vehiclePrice) {
    return res.status(400).json(fail("Peşinat araç fiyatını aşamaz."));
  }

  const customerResult = await query<{ id: number }>(
    `
      SELECT c.id
      FROM customers c
      JOIN users u ON u.id = c.user_id
      WHERE u.id = $1
      LIMIT 1
    `,
    [req.authUser.id]
  );

  const customer = customerResult.rows[0];
  if (!customer) {
    return res.status(403).json(fail("Bu işlem yalnızca müşteri hesabıyla yapılabilir."));
  }

  const resolvedVehicleId = vehicleId ?? (
    await query<{ id: number }>(
      `
        SELECT v.id
        FROM vehicles v
        WHERE v.status IN ('for_sale', 'active', 'in_appraisal')
        ORDER BY
          CASE WHEN v.status = 'for_sale' THEN 0 ELSE 1 END,
          v.id
        LIMIT 1
      `
    )
  ).rows[0]?.id;

  if (!resolvedVehicleId) {
    return res.status(404).json(fail("Finansman simülasyonu için kullanılabilecek araç kaydı bulunamadı."));
  }

  const computed = calculateFinancing({
    vehiclePrice,
    downPayment,
    maturityMonths,
    monthlyInterestRate
  });

  const result = await query(
    `
      INSERT INTO credit_calculations (
        customer_id,
        vehicle_id,
        vehicle_price,
        down_payment,
        down_payment_rate,
        maturity_months,
        monthly_interest_rate,
        financed_amount,
        monthly_payment,
        total_payment,
        total_interest
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING *
    `,
    [
      customer.id,
      resolvedVehicleId,
      vehiclePrice,
      downPayment,
      computed.downPaymentRate,
      maturityMonths,
      monthlyInterestRate,
      computed.financedAmount,
      computed.monthlyPayment,
      computed.totalPayment,
      computed.totalInterest
    ]
  );

  await createAuditLog({
    userId: req.authUser.id,
    action: "create_credit_calculation",
    entityType: "credit_calculation",
    entityId: result.rows[0].id,
    newValue: result.rows[0],
    ipAddress: req.ip
  });

  return res.status(201).json(ok(result.rows[0], "Finansman hesaplaması kaydedildi."));
}
