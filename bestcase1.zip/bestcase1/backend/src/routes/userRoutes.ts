import { Router } from "express";

import { createUser, getUser, listUsers, updateUser } from "../controllers/userController.js";
import { ROLES } from "../constants/roles.js";
import { requireAuth } from "../middleware/authMiddleware.js";
import { requireRoles } from "../middleware/roleMiddleware.js";
import { validate } from "../middleware/validateMiddleware.js";
import { idParamSchema } from "../validators/commonValidators.js";
import { createUserSchema, updateUserSchema } from "../validators/userValidators.js";

export const userRoutes = Router();

userRoutes.use(requireAuth, requireRoles(ROLES.ADMIN));
userRoutes.get("/", listUsers);
userRoutes.post("/", validate({ body: createUserSchema }), createUser);
userRoutes.get("/:id", validate({ params: idParamSchema }), getUser);
userRoutes.put("/:id", validate({ params: idParamSchema, body: updateUserSchema }), updateUser);
