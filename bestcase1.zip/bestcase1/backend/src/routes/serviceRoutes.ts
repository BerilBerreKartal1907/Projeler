import { Router } from "express";

import {
  approveOperation,
  assignTechnician,
  checkCapacity,
  getAvailabilitySlots,
  listAssignableTechnicians,
  completeApprovedOperations,
  createAppointment,
  createOperation,
  rescheduleAppointment,
  cancelAppointment,
  getTechnicianPerformance,
  listAppointments,
  listCriticalCases,
  listOperations,
  rejectOperation,
  reviewCriticalOperation
} from "../controllers/serviceController.js";
import { ROLES } from "../constants/roles.js";
import { requireAuth } from "../middleware/authMiddleware.js";
import { requireRoles } from "../middleware/roleMiddleware.js";
import { validate } from "../middleware/validateMiddleware.js";
import { appointmentIdParamSchema, idParamSchema } from "../validators/commonValidators.js";
import {
  assignTechnicianSchema,
  capacityQuerySchema,
  createAppointmentSchema,
  createOperationSchema,
  rescheduleAppointmentSchema,
  reviewCriticalOperationSchema
} from "../validators/serviceValidators.js";

export const serviceRoutes = Router();

serviceRoutes.use(requireAuth);
serviceRoutes.get("/appointments", listAppointments);
serviceRoutes.get(
  "/technicians",
  requireRoles(ROLES.SERVICE_MANAGER, ROLES.AUTHORIZED_MANAGER, ROLES.ADMIN),
  listAssignableTechnicians
);
serviceRoutes.get("/capacity/check", validate({ query: capacityQuerySchema }), checkCapacity);
serviceRoutes.get("/availability", getAvailabilitySlots);
serviceRoutes.post("/appointments", requireRoles(ROLES.CUSTOMER), validate({ body: createAppointmentSchema }), createAppointment);
serviceRoutes.patch(
  "/appointments/:id/assign-technician",
  requireRoles(ROLES.SERVICE_MANAGER),
  validate({ params: idParamSchema, body: assignTechnicianSchema }),
  assignTechnician
);
serviceRoutes.patch(
  "/appointments/:id/reschedule",
  requireRoles(ROLES.SERVICE_MANAGER, ROLES.AUTHORIZED_MANAGER),
  validate({ params: idParamSchema, body: rescheduleAppointmentSchema }),
  rescheduleAppointment
);
serviceRoutes.post(
  "/appointments/:id/cancel",
  requireRoles(ROLES.SERVICE_MANAGER, ROLES.AUTHORIZED_MANAGER),
  validate({ params: idParamSchema }),
  cancelAppointment
);
serviceRoutes.get(
  "/appointments/:appointmentId/operations",
  requireRoles(ROLES.CUSTOMER, ROLES.TECHNICIAN, ROLES.SERVICE_MANAGER, ROLES.AUTHORIZED_MANAGER, ROLES.ADMIN),
  validate({ params: appointmentIdParamSchema }),
  listOperations
);
serviceRoutes.post(
  "/appointments/:appointmentId/operations",
  requireRoles(ROLES.TECHNICIAN),
  validate({ params: appointmentIdParamSchema, body: createOperationSchema }),
  createOperation
);
serviceRoutes.post(
  "/operations/:id/customer-approve",
  requireRoles(ROLES.CUSTOMER),
  validate({ params: idParamSchema }),
  approveOperation
);
serviceRoutes.post(
  "/operations/:id/customer-reject",
  requireRoles(ROLES.CUSTOMER),
  validate({ params: idParamSchema }),
  rejectOperation
);
serviceRoutes.post(
  "/appointments/:appointmentId/complete-approved-operations",
  requireRoles(ROLES.TECHNICIAN),
  validate({ params: appointmentIdParamSchema }),
  completeApprovedOperations
);
serviceRoutes.get(
  "/critical-cases",
  requireRoles(ROLES.SERVICE_MANAGER, ROLES.AUTHORIZED_MANAGER),
  listCriticalCases
);
serviceRoutes.get(
  "/technician-performance",
  requireRoles(ROLES.SERVICE_MANAGER, ROLES.AUTHORIZED_MANAGER),
  getTechnicianPerformance
);
serviceRoutes.post(
  "/operations/:id/review",
  requireRoles(ROLES.SERVICE_MANAGER, ROLES.AUTHORIZED_MANAGER),
  validate({ params: idParamSchema, body: reviewCriticalOperationSchema }),
  reviewCriticalOperation
);
