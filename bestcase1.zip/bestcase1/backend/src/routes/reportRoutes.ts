import { Router } from "express";

import {
  exportSummaryExcel,
  exportSummaryCsv,
  getSalesReport,
  getServiceReport,
  getSummaryReport
} from "../controllers/reportController.js";
import { ROLES } from "../constants/roles.js";
import { requireAuth } from "../middleware/authMiddleware.js";
import { requireRoles } from "../middleware/roleMiddleware.js";

export const reportRoutes = Router();

reportRoutes.get("/reports/summary", requireAuth, requireRoles(ROLES.AUTHORIZED_MANAGER, ROLES.ADMIN), getSummaryReport);
reportRoutes.get("/reports/sales", requireAuth, requireRoles(ROLES.AUTHORIZED_MANAGER, ROLES.ADMIN), getSalesReport);
reportRoutes.get("/reports/service", requireAuth, requireRoles(ROLES.AUTHORIZED_MANAGER, ROLES.ADMIN), getServiceReport);
reportRoutes.get("/reports/export/csv", requireAuth, requireRoles(ROLES.AUTHORIZED_MANAGER, ROLES.ADMIN), exportSummaryCsv);
reportRoutes.get("/reports/export/excel", requireAuth, requireRoles(ROLES.AUTHORIZED_MANAGER, ROLES.ADMIN), exportSummaryExcel);
