import { Router } from "express";

import { createCreditCalculation, listCreditCalculations } from "../controllers/financeController.js";
import { ROLES } from "../constants/roles.js";
import { requireAuth } from "../middleware/authMiddleware.js";
import { requireRoles } from "../middleware/roleMiddleware.js";
import { validate } from "../middleware/validateMiddleware.js";
import { createCreditCalculationSchema } from "../validators/financeValidators.js";

export const financeRoutes = Router();

financeRoutes.get(
  "/credit-calculations",
  requireAuth,
  requireRoles(ROLES.CUSTOMER, ROLES.SALES_AGENT, ROLES.AUTHORIZED_MANAGER, ROLES.ADMIN),
  listCreditCalculations
);
financeRoutes.post("/credit-calculations", requireAuth, requireRoles(ROLES.CUSTOMER), validate({ body: createCreditCalculationSchema }), createCreditCalculation);
