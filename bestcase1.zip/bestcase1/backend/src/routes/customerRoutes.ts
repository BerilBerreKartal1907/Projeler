import { Router } from "express";

import {
  getCustomer,
  listCustomers,
} from "../controllers/customerController.js";
import { ROLES } from "../constants/roles.js";
import { requireAuth } from "../middleware/authMiddleware.js";
import { requireRoles } from "../middleware/roleMiddleware.js";

export const customerRoutes = Router();
customerRoutes.use(
  requireAuth,
  requireRoles(ROLES.ADMIN, ROLES.SALES_AGENT, ROLES.SERVICE_MANAGER, ROLES.AUTHORIZED_MANAGER)
);
customerRoutes.get("/", listCustomers);
customerRoutes.get("/:id", getCustomer);
