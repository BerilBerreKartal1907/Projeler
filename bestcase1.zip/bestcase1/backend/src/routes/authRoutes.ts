import { Router } from "express";

import { forgotPassword, login, me, registerCustomer, resetPassword } from "../controllers/authController.js";
import { requireAuth } from "../middleware/authMiddleware.js";
import { validate } from "../middleware/validateMiddleware.js";
import { forgotPasswordSchema, loginSchema, registerSchema, resetPasswordSchema } from "../validators/authValidators.js";

export const authRoutes = Router();

authRoutes.post("/login", validate({ body: loginSchema }), login);
authRoutes.post("/register", validate({ body: registerSchema }), registerCustomer);
authRoutes.post("/forgot-password", validate({ body: forgotPasswordSchema }), forgotPassword);
authRoutes.post("/reset-password", validate({ body: resetPasswordSchema }), resetPassword);
authRoutes.get("/me", requireAuth, me);
