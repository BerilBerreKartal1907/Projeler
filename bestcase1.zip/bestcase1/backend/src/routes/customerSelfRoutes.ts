import { Router } from "express";

import { getMyCustomerProfile, updateMyCustomerProfile } from "../controllers/customerController.js";
import { requireAuth } from "../middleware/authMiddleware.js";

export const customerSelfRoutes = Router();

customerSelfRoutes.get("/customers/me/profile", requireAuth, getMyCustomerProfile);
customerSelfRoutes.put("/customers/me/profile", requireAuth, updateMyCustomerProfile);
