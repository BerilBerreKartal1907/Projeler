import { Router } from "express";

import { getRolePermissions, listRoles } from "../controllers/roleController.js";
import { ROLES } from "../constants/roles.js";
import { requireAuth } from "../middleware/authMiddleware.js";
import { requireRoles } from "../middleware/roleMiddleware.js";

export const roleRoutes = Router();

roleRoutes.get("/", requireAuth, requireRoles(ROLES.ADMIN), listRoles);
roleRoutes.get("/permissions", requireAuth, requireRoles(ROLES.ADMIN), getRolePermissions);
