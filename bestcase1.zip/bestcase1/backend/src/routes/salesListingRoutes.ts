import { Router } from "express";

import {
  cancelSalesListing,
  createSalesListing,
  listSalesListingCandidates,
  listSalesListings,
  markListingSold
} from "../controllers/salesListingController.js";
import { ROLES } from "../constants/roles.js";
import { requireAuth } from "../middleware/authMiddleware.js";
import { requireRoles } from "../middleware/roleMiddleware.js";

export const salesListingRoutes = Router();

salesListingRoutes.get("/sales-listings", requireAuth, listSalesListings);
salesListingRoutes.get("/sales-listings/candidates", requireAuth, requireRoles(ROLES.SALES_AGENT, ROLES.ADMIN), listSalesListingCandidates);
salesListingRoutes.post("/sales-listings", requireAuth, requireRoles(ROLES.SALES_AGENT, ROLES.ADMIN), createSalesListing);
salesListingRoutes.post("/sales-listings/:id/mark-sold", requireAuth, requireRoles(ROLES.SALES_AGENT, ROLES.ADMIN), markListingSold);
salesListingRoutes.post("/sales-listings/:id/cancel", requireAuth, requireRoles(ROLES.SALES_AGENT, ROLES.ADMIN), cancelSalesListing);
