import { Router } from "express";

import {
  acceptNegotiation,
  approveNegotiation,
  createNegotiation,
  getNegotiation,
  listNegotiations,
  rejectNegotiation,
  requestNegotiationMeeting,
  submitCustomerExpectation,
  updateNegotiationSettings
} from "../controllers/negotiationController.js";
import { ROLES } from "../constants/roles.js";
import { requireAuth } from "../middleware/authMiddleware.js";
import { requireRoles } from "../middleware/roleMiddleware.js";
import { validate } from "../middleware/validateMiddleware.js";
import { negotiationIdParamSchema } from "../validators/commonValidators.js";
import {
  createNegotiationSchema,
  customerExpectationSchema,
  managerNegotiationDecisionSchema,
  updateNegotiationSettingsSchema
} from "../validators/negotiationValidators.js";

export const negotiationRoutes = Router();

negotiationRoutes.use(requireAuth);
negotiationRoutes.get("/", requireRoles(ROLES.CUSTOMER, ROLES.SALES_AGENT, ROLES.AUTHORIZED_MANAGER, ROLES.ADMIN), listNegotiations);
negotiationRoutes.post("/", requireRoles(ROLES.CUSTOMER, ROLES.SALES_AGENT, ROLES.AUTHORIZED_MANAGER), validate({ body: createNegotiationSchema }), createNegotiation);
negotiationRoutes.get("/:id", requireRoles(ROLES.CUSTOMER, ROLES.SALES_AGENT, ROLES.AUTHORIZED_MANAGER, ROLES.ADMIN), validate({ params: negotiationIdParamSchema }), getNegotiation);
negotiationRoutes.post("/:id/customer-expectation", requireRoles(ROLES.CUSTOMER), validate({ params: negotiationIdParamSchema, body: customerExpectationSchema }), submitCustomerExpectation);
negotiationRoutes.post("/:id/accept", requireRoles(ROLES.CUSTOMER), validate({ params: negotiationIdParamSchema }), acceptNegotiation);
negotiationRoutes.post("/:id/reject", requireRoles(ROLES.CUSTOMER, ROLES.AUTHORIZED_MANAGER), validate({ params: negotiationIdParamSchema, body: managerNegotiationDecisionSchema }), rejectNegotiation);
negotiationRoutes.post("/:id/manager-approve", requireRoles(ROLES.AUTHORIZED_MANAGER), validate({ params: negotiationIdParamSchema, body: managerNegotiationDecisionSchema }), approveNegotiation);
negotiationRoutes.post("/:id/request-meeting", requireRoles(ROLES.CUSTOMER), validate({ params: negotiationIdParamSchema }), requestNegotiationMeeting);
negotiationRoutes.patch(
  "/:id/settings",
  requireRoles(ROLES.SALES_AGENT, ROLES.AUTHORIZED_MANAGER),
  validate({ params: negotiationIdParamSchema, body: updateNegotiationSettingsSchema }),
  updateNegotiationSettings
);
