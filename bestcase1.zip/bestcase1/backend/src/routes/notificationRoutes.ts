import { Router } from "express";

import {
  listNotifications,
  markAllNotificationsRead,
  markNotificationRead
} from "../controllers/notificationController.js";
import { requireAuth } from "../middleware/authMiddleware.js";

export const notificationRoutes = Router();

notificationRoutes.get("/notifications", requireAuth, listNotifications);
notificationRoutes.patch("/notifications/:id/read", requireAuth, markNotificationRead);
notificationRoutes.patch("/notifications/read-all", requireAuth, markAllNotificationsRead);
