import { Router } from "express";

import { getVehicle, listVehicles } from "../controllers/vehicleController.js";
import { requireAuth } from "../middleware/authMiddleware.js";

export const vehicleRoutes = Router();

vehicleRoutes.use(requireAuth);
vehicleRoutes.get("/", listVehicles);
vehicleRoutes.get("/:id", getVehicle);
