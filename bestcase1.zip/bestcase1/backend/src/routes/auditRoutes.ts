import { Router } from "express";

import { listAuditLogs } from "../controllers/auditLogController.js";
import { ROLES } from "../constants/roles.js";
import { requireAuth } from "../middleware/authMiddleware.js";
import { requireRoles } from "../middleware/roleMiddleware.js";

export const auditRoutes = Router();

auditRoutes.get("/audit-logs", requireAuth, requireRoles(ROLES.ADMIN), listAuditLogs);
