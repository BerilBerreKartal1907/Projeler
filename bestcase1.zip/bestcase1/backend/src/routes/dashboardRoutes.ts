import { Router } from "express";

import {
  getAdminDashboard,
  getCustomerDashboard,
  getManagerDashboard,
  getSalesDashboard,
  getServiceManagerDashboard,
  getTechnicianDashboard
} from "../controllers/dashboardController.js";
import { ROLES } from "../constants/roles.js";
import { requireAuth } from "../middleware/authMiddleware.js";
import { requireRoles } from "../middleware/roleMiddleware.js";

export const dashboardRoutes = Router();

dashboardRoutes.use(requireAuth);
dashboardRoutes.get("/customer", requireRoles(ROLES.CUSTOMER), getCustomerDashboard);
dashboardRoutes.get("/sales", requireRoles(ROLES.SALES_AGENT, ROLES.AUTHORIZED_MANAGER, ROLES.ADMIN), getSalesDashboard);
dashboardRoutes.get("/technician", requireRoles(ROLES.TECHNICIAN), getTechnicianDashboard);
dashboardRoutes.get("/service-manager", requireRoles(ROLES.SERVICE_MANAGER, ROLES.AUTHORIZED_MANAGER, ROLES.ADMIN), getServiceManagerDashboard);
dashboardRoutes.get("/manager", requireRoles(ROLES.AUTHORIZED_MANAGER, ROLES.ADMIN), getManagerDashboard);
dashboardRoutes.get("/admin", requireRoles(ROLES.ADMIN), getAdminDashboard);
