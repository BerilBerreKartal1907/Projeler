import { Router } from "express";

import { listSystemParameters, updateSystemParameter } from "../controllers/systemController.js";
import { ROLES } from "../constants/roles.js";
import { requireAuth } from "../middleware/authMiddleware.js";
import { requireRoles } from "../middleware/roleMiddleware.js";
import { validate } from "../middleware/validateMiddleware.js";
import { keyParamSchema } from "../validators/commonValidators.js";
import { updateSystemParameterSchema } from "../validators/systemValidators.js";

export const systemRoutes = Router();

systemRoutes.get("/system-parameters", requireAuth, requireRoles(ROLES.ADMIN), listSystemParameters);
systemRoutes.put(
  "/system-parameters/:key",
  requireAuth,
  requireRoles(ROLES.ADMIN),
  validate({ params: keyParamSchema, body: updateSystemParameterSchema }),
  updateSystemParameter
);
