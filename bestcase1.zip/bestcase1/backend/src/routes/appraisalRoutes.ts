import { Router } from "express";

import {
  approveAppraisal,
  createAppraisal,
  getAppraisalCooldownStatus,
  getAppraisal,
  getPreliminaryOffer,
  listAppraisals,
  rejectAppraisal,
  reviseAppraisalPrice,
  saveDamageDetails,
  updateExpectedPrice
} from "../controllers/appraisalController.js";
import { ROLES } from "../constants/roles.js";
import { requireAuth } from "../middleware/authMiddleware.js";
import { requireRoles } from "../middleware/roleMiddleware.js";
import { validate } from "../middleware/validateMiddleware.js";
import {
  createAppraisalSchema,
  managerNoteSchema,
  revisePriceSchema,
  saveDamageDetailsSchema,
  updateExpectedPriceSchema
} from "../validators/appraisalValidators.js";
import { appraisalIdParamSchema } from "../validators/commonValidators.js";

export const appraisalRoutes = Router();

appraisalRoutes.use(requireAuth);
appraisalRoutes.get("/", requireRoles(ROLES.CUSTOMER, ROLES.SALES_AGENT, ROLES.AUTHORIZED_MANAGER, ROLES.ADMIN), listAppraisals);
appraisalRoutes.get("/cooldown/status", requireRoles(ROLES.CUSTOMER), getAppraisalCooldownStatus);
appraisalRoutes.post("/", requireRoles(ROLES.CUSTOMER), validate({ body: createAppraisalSchema }), createAppraisal);
appraisalRoutes.get("/:id", requireRoles(ROLES.CUSTOMER, ROLES.SALES_AGENT, ROLES.AUTHORIZED_MANAGER, ROLES.ADMIN), validate({ params: appraisalIdParamSchema }), getAppraisal);
appraisalRoutes.post("/:id/damage-details", requireRoles(ROLES.CUSTOMER), validate({ params: appraisalIdParamSchema, body: saveDamageDetailsSchema }), saveDamageDetails);
appraisalRoutes.get("/:id/preliminary-offer", requireRoles(ROLES.CUSTOMER, ROLES.SALES_AGENT, ROLES.AUTHORIZED_MANAGER, ROLES.ADMIN), validate({ params: appraisalIdParamSchema }), getPreliminaryOffer);
appraisalRoutes.patch("/:id/expected-price", requireRoles(ROLES.CUSTOMER), validate({ params: appraisalIdParamSchema, body: updateExpectedPriceSchema }), updateExpectedPrice);
appraisalRoutes.post(
  "/:id/approve",
  requireRoles(ROLES.AUTHORIZED_MANAGER),
  validate({ params: appraisalIdParamSchema, body: managerNoteSchema }),
  approveAppraisal
);
appraisalRoutes.post(
  "/:id/reject",
  requireRoles(ROLES.AUTHORIZED_MANAGER),
  validate({ params: appraisalIdParamSchema, body: managerNoteSchema }),
  rejectAppraisal
);
appraisalRoutes.post(
  "/:id/revise-price",
  requireRoles(ROLES.AUTHORIZED_MANAGER),
  validate({ params: appraisalIdParamSchema, body: revisePriceSchema }),
  reviseAppraisalPrice
);
