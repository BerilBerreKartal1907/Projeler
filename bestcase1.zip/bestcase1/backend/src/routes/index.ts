import { Router } from "express";

import { authRoutes } from "./authRoutes.js";
import { appraisalRoutes } from "./appraisalRoutes.js";
import { auditRoutes } from "./auditRoutes.js";
import { customerRoutes } from "./customerRoutes.js";
import { customerSelfRoutes } from "./customerSelfRoutes.js";
import { dashboardRoutes } from "./dashboardRoutes.js";
import { financeRoutes } from "./financeRoutes.js";
import { negotiationRoutes } from "./negotiationRoutes.js";
import { notificationRoutes } from "./notificationRoutes.js";
import { roleRoutes } from "./roleRoutes.js";
import { reportRoutes } from "./reportRoutes.js";
import { salesListingRoutes } from "./salesListingRoutes.js";
import { serviceRoutes } from "./serviceRoutes.js";
import { systemRoutes } from "./systemRoutes.js";
import { userRoutes } from "./userRoutes.js";
import { vehicleRoutes } from "./vehicleRoutes.js";

export const apiRouter = Router();

apiRouter.get("/health", (_req, res) => {
  res.json({
    success: true,
    message: "Smart-Appraisal Pro API ayakta.",
    timestamp: new Date().toISOString()
  });
});

apiRouter.use("/auth", authRoutes);
apiRouter.use("/appraisals", appraisalRoutes);
apiRouter.use("/", customerSelfRoutes);
apiRouter.use("/dashboard", dashboardRoutes);
apiRouter.use("/", financeRoutes);
apiRouter.use("/negotiations", negotiationRoutes);
apiRouter.use("/", notificationRoutes);
apiRouter.use("/", reportRoutes);
apiRouter.use("/", salesListingRoutes);
apiRouter.use("/service", serviceRoutes);
apiRouter.use("/", systemRoutes);
apiRouter.use("/", auditRoutes);
apiRouter.use("/roles", roleRoutes);
apiRouter.use("/users", userRoutes);
apiRouter.use("/customers", customerRoutes);
apiRouter.use("/vehicles", vehicleRoutes);
