import { z } from "zod";

export const updateSystemParameterSchema = z.object({
  value: z.string().min(1),
  description: z.string().max(1000).optional()
});
