import { z } from "zod";

export const loginSchema = z.object({
  email: z.string().email("Geçerli bir e-posta girin."),
  password: z.string().min(6, "Şifre en az 6 karakter olmalıdır.")
});

export const registerSchema = z.object({
  fullName: z.string().min(3, "Ad soyad en az 3 karakter olmalıdır."),
  email: z.string().email("Geçerli bir e-posta girin."),
  password: z.string().min(6, "Şifre en az 6 karakter olmalıdır."),
  phone: z.string().min(7, "Telefon numarası zorunludur."),
  district: z.string().min(2, "İlçe zorunludur."),
  city: z.string().min(2, "Şehir zorunludur.")
});

export const forgotPasswordSchema = z.object({
  phone: z.string().min(7, "Telefon numarası zorunludur.")
});

export const resetPasswordSchema = z.object({
  token: z.string().min(1, "Token zorunludur."),
  smsCode: z.string().length(4, "SMS kodu 4 haneli olmalıdır."),
  newPassword: z.string().min(6, "Yeni şifre en az 6 karakter olmalıdır."),
  confirmPassword: z.string().min(6, "Şifre tekrar alanı zorunludur.")
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Şifre alanları eşleşmiyor.",
  path: ["confirmPassword"]
});
