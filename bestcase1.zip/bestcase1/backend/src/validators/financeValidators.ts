import { z } from "zod";

export const createCreditCalculationSchema = z.object({
  vehicleId: z.coerce.number().int().positive().optional(),
  vehiclePrice: z.coerce.number().positive(),
  downPayment: z.coerce.number().min(0),
  maturityMonths: z.coerce.number().int().positive(),
  monthlyInterestRate: z.coerce.number().min(0)
});
