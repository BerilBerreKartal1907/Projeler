import { z } from "zod";

export const capacityQuerySchema = z.object({
  serviceType: z.string().min(1),
  date: z.string().min(10)
});

export const createAppointmentSchema = z.object({
  vehicleId: z.coerce.number().int().positive(),
  serviceType: z.string().min(1),
  appointmentDatetime: z.string().min(10),
  complaintDescription: z.string().max(1000).optional()
});

export const assignTechnicianSchema = z.object({
  technicianId: z.coerce.number().int().positive()
});

export const createOperationSchema = z.object({
  operationName: z.string().min(2),
  operationType: z.string().min(2),
  partPrice: z.coerce.number().min(0).optional(),
  laborPrice: z.coerce.number().min(0).optional(),
  isCriticalSafety: z.boolean().optional(),
  note: z.string().max(1000).optional()
});

export const reviewCriticalOperationSchema = z.object({
  decision: z.enum(["approved", "rejected", "pending"]),
  note: z.string().max(1000).optional()
});

export const rescheduleAppointmentSchema = z.object({
  appointmentDatetime: z.string().min(10, "Yeni randevu tarihi zorunludur.")
});
