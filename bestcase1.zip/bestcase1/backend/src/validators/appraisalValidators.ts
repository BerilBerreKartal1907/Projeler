import { z } from "zod";

const damageTypeEnum = z.enum(["original", "painted", "local_painted", "replaced", "damaged"]);

export const createAppraisalSchema = z.object({
  brand: z.string().min(1),
  model: z.string().min(1),
  package: z.string().min(1),
  year: z.coerce.number().int().min(1950).max(2100),
  mileage: z.coerce.number().int().min(0),
  plate: z.string().max(20).optional(),
  category: z.string().min(1),
  expectedSellingPrice: z.coerce.number().min(0).optional(),
  declaredTramerAmount: z.coerce.number().min(0).optional()
});

export const saveDamageDetailsSchema = z.object({
  damages: z.array(
    z.object({
      vehiclePart: z.string().min(1),
      damageType: damageTypeEnum,
      note: z.string().max(500).optional().nullable()
    })
  ).min(1)
});

export const updateExpectedPriceSchema = z.object({
  expectedSellingPrice: z.coerce.number().positive()
});

export const revisePriceSchema = z.object({
  revisedPrice: z.coerce.number().min(0),
  note: z.string().max(1000).optional()
});

export const managerNoteSchema = z.object({
  note: z.string().max(1000).optional()
});
