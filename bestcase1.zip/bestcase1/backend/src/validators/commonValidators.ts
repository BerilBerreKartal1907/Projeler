import { z } from "zod";

export const idParamSchema = z.object({
  id: z.coerce.number().int().positive()
});

export const appointmentIdParamSchema = z.object({
  appointmentId: z.coerce.number().int().positive()
});

export const appraisalIdParamSchema = z.object({
  id: z.coerce.number().int().positive()
});

export const negotiationIdParamSchema = z.object({
  id: z.coerce.number().int().positive()
});

export const keyParamSchema = z.object({
  key: z.string().min(1)
});
