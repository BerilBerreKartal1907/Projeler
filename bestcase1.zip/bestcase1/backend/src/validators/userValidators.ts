import { z } from "zod";

export const createUserSchema = z.object({
  fullName: z.string().min(3),
  email: z.string().email(),
  password: z.string().min(6),
  phone: z.string().min(5).optional(),
  roleId: z.coerce.number().int().positive(),
  isActive: z.boolean().optional()
});

export const updateUserSchema = z.object({
  fullName: z.string().min(3).optional(),
  phone: z.string().min(5).nullable().optional(),
  roleId: z.coerce.number().int().positive().optional(),
  isActive: z.boolean().optional()
});
