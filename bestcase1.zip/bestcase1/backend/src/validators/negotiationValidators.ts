import { z } from "zod";

export const createNegotiationSchema = z.object({
  appraisalRequestId: z.coerce.number().int().positive()
});

export const customerExpectationSchema = z.object({
  expectedPrice: z.coerce.number().positive()
});

export const updateNegotiationSettingsSchema = z.object({
  maxAuthorizedOffer: z.coerce.number().min(0).optional(),
  incrementAmount: z.coerce.number().min(0).optional(),
  autoNegotiationEnabled: z.boolean().optional()
});

export const managerNegotiationDecisionSchema = z.object({
  note: z.string().max(1000).optional()
});
