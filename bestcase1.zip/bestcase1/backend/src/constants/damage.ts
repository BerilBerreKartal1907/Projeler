export const DAMAGE_POINTS = {
  original: 0,
  painted: 2,
  local_painted: 5,
  replaced: 3,
  damaged: 10
} as const;

export const VEHICLE_PARTS = [
  "hood",
  "roof",
  "front_bumper",
  "rear_bumper",
  "right_front_door",
  "right_rear_door",
  "left_front_door",
  "left_rear_door",
  "trunk",
  "right_fender",
  "left_fender",
  "engine",
  "tires"
] as const;

export type DamageType = keyof typeof DAMAGE_POINTS;
export type VehiclePart = (typeof VEHICLE_PARTS)[number];
