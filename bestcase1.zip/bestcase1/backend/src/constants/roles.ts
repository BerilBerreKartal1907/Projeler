export const ROLES = {
  CUSTOMER: "customer",
  SALES_AGENT: "sales_agent",
  TECHNICIAN: "technician",
  SERVICE_MANAGER: "service_manager",
  AUTHORIZED_MANAGER: "authorized_manager",
  ADMIN: "admin"
} as const;

export type RoleName = (typeof ROLES)[keyof typeof ROLES];
