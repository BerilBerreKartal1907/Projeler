import type { RoleName } from "../constants/roles.js";

declare global {
  namespace Express {
    interface Request {
      authUser?: {
        id: number;
        email: string;
        role: RoleName;
      };
    }
  }
}

export {};
