export function calculateFinancing(input: {
  vehiclePrice: number;
  downPayment: number;
  maturityMonths: number;
  monthlyInterestRate: number;
}) {
  const financedAmount = Math.max(input.vehiclePrice - input.downPayment, 0);
  const monthlyRate = input.monthlyInterestRate / 100;

  let monthlyPayment = 0;
  if (input.maturityMonths > 0) {
    if (monthlyRate === 0) {
      monthlyPayment = financedAmount / input.maturityMonths;
    } else {
      // Standart eşit taksit formülü; faiz sıfır olduğunda yukarıdaki basit bölme kullanılır.
      monthlyPayment =
        financedAmount *
        monthlyRate *
        Math.pow(1 + monthlyRate, input.maturityMonths) /
        (Math.pow(1 + monthlyRate, input.maturityMonths) - 1);
    }
  }

  const totalPayment = monthlyPayment * input.maturityMonths;
  const totalInterest = totalPayment - financedAmount;

  return {
    financedAmount: Number(financedAmount.toFixed(2)),
    monthlyPayment: Number(monthlyPayment.toFixed(2)),
    totalPayment: Number(totalPayment.toFixed(2)),
    totalInterest: Number(totalInterest.toFixed(2)),
    downPaymentRate: input.vehiclePrice > 0 ? Number(((input.downPayment / input.vehiclePrice) * 100).toFixed(2)) : 0
  };
}
