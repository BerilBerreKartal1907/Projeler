import { query } from "../../config/db.js";

const defaultCapacity: Record<string, number> = {
  maintenance: 12,
  check_up: 8,
  accident_repair: 5,
  modification: 2
};

export async function getDailyCapacity(serviceType: string) {
  // Kapasite admin parametrelerinden gelir; parametre yoksa demo varsayılanları kullanılır.
  const keyMap: Record<string, string> = {
    maintenance: "daily_maintenance_capacity",
    check_up: "daily_checkup_capacity",
    accident_repair: "daily_accident_repair_capacity",
    modification: "daily_modification_capacity"
  };

  const parameterKey = keyMap[serviceType];
  if (!parameterKey) {
    return defaultCapacity[serviceType] ?? 0;
  }

  const result = await query<{ value: string }>(
    "SELECT value FROM system_parameters WHERE key = $1 LIMIT 1",
    [parameterKey]
  );

  return Number(result.rows[0]?.value ?? defaultCapacity[serviceType] ?? 0);
}

export async function countAppointmentsForDay(serviceType: string, appointmentDate: string) {
  const result = await query<{ count: string }>(
    `
      SELECT COUNT(*)::text AS count
      FROM service_appointments
      WHERE service_type = $1
        AND DATE(appointment_datetime) = DATE($2)
        AND status <> 'cancelled'
    `,
    [serviceType, appointmentDate]
  );

  return Number(result.rows[0]?.count ?? 0);
}
