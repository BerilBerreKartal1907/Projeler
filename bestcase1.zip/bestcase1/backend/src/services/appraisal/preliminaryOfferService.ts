import { DAMAGE_POINTS, VEHICLE_PARTS, type DamageType } from "../../constants/damage.js";
import { query } from "../../config/db.js";
import { evaluateAppraisalRules } from "./appraisalRuleEngine.js";

type SystemParameterRow = {
  key: string;
  value: string;
};

type TramerInput = {
  marketValue: number;
  accidentRecord: boolean;
  ownerCount: number;
  heavyDamage: boolean;
  customsProblem: boolean;
};

type DamageDetailInput = {
  vehiclePart: string;
  damageType: DamageType;
  note?: string | null;
};

export type OfferComputationResult = {
  damageScore: number;
  damagePercentage: number;
  tramerValue: number;
  calculatedOffer: number;
  requiresManagerApproval: boolean;
  approvalReasons: string[];
  suggestedAction: string;
  appliedDiscounts: string[];
};

async function getSystemParameters() {
  const result = await query<SystemParameterRow>(
    `
      SELECT key, value
      FROM system_parameters
      WHERE key IN (
        'minimum_profit_rate',
        'tramer_accident_discount_rate'
      )
    `
  );

  const map = new Map(result.rows.map((row) => [row.key, Number(row.value)]));

  return {
    minimumProfitRate: map.get("minimum_profit_rate") ?? 12,
    tramerAccidentDiscountRate: map.get("tramer_accident_discount_rate") ?? 20
  };
}

export async function computePreliminaryOffer(input: {
  mileage: number;
  expectedSellingPrice?: number | null;
  declaredTramerAmount?: number;
  tramer: TramerInput;
  damages: DamageDetailInput[];
}): Promise<OfferComputationResult> {
  const parameters = await getSystemParameters();

  const damageScore = input.damages.reduce((sum, item) => sum + DAMAGE_POINTS[item.damageType], 0);
  const maxPossibleDamage = VEHICLE_PARTS.length * DAMAGE_POINTS.damaged;
  const damagePercentage = Number(((damageScore / maxPossibleDamage) * 100).toFixed(2));

  let offer = input.tramer.marketValue * 0.88;
  const appliedDiscounts: string[] = [];

  // Teklif hesaplama, piyasa değerinden başlayıp hasar/TRAMER/risk etkilerini sırayla düşer.
  const damageDiscount = offer * (damagePercentage / 100) * 0.35;
  offer -= damageDiscount;
  appliedDiscounts.push(`Hasar indirimi: -${damagePercentage.toFixed(2)}%`);

  if (input.tramer.accidentRecord) {
    offer -= input.tramer.marketValue * (parameters.tramerAccidentDiscountRate / 100);
    appliedDiscounts.push(`TRAMER kaza indirimi: -${parameters.tramerAccidentDiscountRate}%`);
  }

  if (input.tramer.heavyDamage) {
    offer -= input.tramer.marketValue * 0.15;
    appliedDiscounts.push("Ağır hasar indirimi: -15%");
  }

  if (input.tramer.customsProblem) {
    offer -= input.tramer.marketValue * 0.1;
    appliedDiscounts.push("Gümrük problemi indirimi: -10%");
  }

  if (input.mileage > 200_000) {
    offer -= input.tramer.marketValue * 0.08;
    appliedDiscounts.push("Yüksek kilometre indirimi: -8%");
  }

  if ((input.declaredTramerAmount ?? 0) > 0) {
    const tramerClaimDiscount = Math.min((input.declaredTramerAmount ?? 0) * 0.55, offer * 0.18);
    offer -= tramerClaimDiscount;
    appliedDiscounts.push(`TRAMER tutarı etkisi: -${Math.round(tramerClaimDiscount).toLocaleString("tr-TR")} TL`);
  }

  offer = Math.max(0, offer);

  const minProfitGuard = input.tramer.marketValue * ((parameters.minimumProfitRate / 100) * 0.35);
  if (offer > 0) {
    offer = Math.max(offer - minProfitGuard, 0);
    appliedDiscounts.push(`Minimum kar koruması: -%${parameters.minimumProfitRate}`);
  }

  const roundedOffer = Math.min(Math.round(offer), Math.round(input.tramer.marketValue * 0.95));

  // Hesaplanan teklif kural motorundan geçirilerek yönetici onayı gerekip gerekmediği belirlenir.
  const ruleResult = evaluateAppraisalRules({
    mileage: input.mileage,
    damagePercentage,
    calculatedOffer: roundedOffer,
    tramerValue: input.tramer.marketValue,
    ownerCount: input.tramer.ownerCount,
    accidentRecord: input.tramer.accidentRecord,
    customerExpectedPrice: input.expectedSellingPrice ?? null
  });

  return {
    damageScore,
    damagePercentage,
    tramerValue: input.tramer.marketValue,
    calculatedOffer: roundedOffer,
    requiresManagerApproval: ruleResult.requiresApproval,
    approvalReasons: ruleResult.reasons,
    suggestedAction: ruleResult.suggestedAction,
    appliedDiscounts
  };
}
