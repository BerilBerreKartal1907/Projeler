type AppraisalRuleInput = {
  mileage: number;
  damagePercentage: number;
  calculatedOffer: number;
  tramerValue: number;
  ownerCount: number;
  accidentRecord: boolean;
  customerExpectedPrice?: number | null;
};

type AppraisalRuleOutput = {
  requiresApproval: boolean;
  reasons: string[];
  suggestedAction: string;
};

export function evaluateAppraisalRules(input: AppraisalRuleInput): AppraisalRuleOutput {
  const reasons: string[] = [];

  // Yönetici onayı için en kritik sinyal müşteri beklentisinin sistem teklifine göre aşırı yüksek olması.
  if (
    typeof input.customerExpectedPrice === "number" &&
    input.customerExpectedPrice > 0 &&
    input.calculatedOffer > 0
  ) {
    if (input.customerExpectedPrice > input.calculatedOffer * 2) {
      reasons.push("Müşteri beklentisi sistem teklifinin 2 katını aşıyor.");
    }
  }

  return {
    requiresApproval: reasons.length > 0,
    reasons,
    suggestedAction: reasons.length > 0 ? "Yetkili yönetici onayına gönder" : "Ön teklif müşteriye sunulabilir"
  };
}
