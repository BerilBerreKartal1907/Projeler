import { query } from "../../config/db.js";

type NegotiationRow = {
  id: number;
  appraisal_request_id: number;
  customer_id: number;
  system_offer: string;
  customer_expected_price: string | null;
  current_dealer_offer: string;
  max_authorized_offer: string;
  increment_amount: string;
  auto_negotiation_enabled: boolean;
  status: string;
  result: string | null;
};

export async function getNegotiationById(id: number) {
  const result = await query<NegotiationRow>(
    `
      SELECT
        id,
        appraisal_request_id,
        customer_id,
        system_offer,
        customer_expected_price,
        current_dealer_offer,
        max_authorized_offer,
        increment_amount,
        auto_negotiation_enabled,
        status,
        result
      FROM negotiations
      WHERE id = $1
      LIMIT 1
    `,
    [id]
  );

  return result.rows[0] ?? null;
}

export function evaluateCounterOffer(input: {
  systemOffer: number;
  customerExpectedPrice: number;
  currentDealerOffer: number;
  maxAuthorizedOffer: number;
  incrementAmount: number;
  autoNegotiationEnabled: boolean;
}) {
  // Eski düşük limit kayıtları için yönetici tavanını sistem teklifinin en az 2 katına tamamlarız.
  const effectiveMaxAuthorizedOffer = Math.max(input.maxAuthorizedOffer, Math.round(input.systemOffer * 2));

  if (input.customerExpectedPrice <= input.currentDealerOffer) {
    return {
      nextStatus: "accepted",
      nextDealerOffer: input.customerExpectedPrice,
      requiresManagerReview: false,
      resultMessage: "Müşteri beklentisi mevcut teklif aralığında karşılandı."
    };
  }

  if (!input.autoNegotiationEnabled) {
    return {
      nextStatus: "pending_manager_review",
      nextDealerOffer: input.currentDealerOffer,
      requiresManagerReview: true,
      resultMessage: "Otomatik pazarlık kapalı, yönetici incelemesi gerekli."
    };
  }

  if (input.customerExpectedPrice > effectiveMaxAuthorizedOffer) {
    return {
      nextStatus: "pending_manager_review",
      nextDealerOffer: input.currentDealerOffer,
      requiresManagerReview: true,
      resultMessage: "Müşteri beklentisi sistem teklifinin 2 katını aşıyor."
    };
  }

  const nextDealerOffer = Math.min(
    input.currentDealerOffer + input.incrementAmount,
    effectiveMaxAuthorizedOffer
  );

  if (nextDealerOffer >= input.customerExpectedPrice) {
    return {
      nextStatus: "accepted",
      nextDealerOffer: input.customerExpectedPrice,
      requiresManagerReview: false,
      resultMessage: "Müşteri beklentisine uygun teklif oluşturuldu."
    };
  }

  return {
    nextStatus: "auto_negotiating",
    nextDealerOffer,
    requiresManagerReview: false,
    resultMessage: "Karşı teklif oluşturuldu."
  };
}

export async function appendNegotiationMessage(input: {
  negotiationId: number;
  senderUserId?: number | null;
  senderType: string;
  messageType: string;
  offeredPrice?: number | null;
  note?: string | null;
}) {
  await query(
    `
      INSERT INTO negotiation_messages (
        negotiation_id,
        sender_user_id,
        sender_type,
        message_type,
        offered_price,
        note
      )
      VALUES ($1, $2, $3, $4, $5, $6)
    `,
    [
      input.negotiationId,
      input.senderUserId ?? null,
      input.senderType,
      input.messageType,
      input.offeredPrice ?? null,
      input.note ?? null
    ]
  );
}
