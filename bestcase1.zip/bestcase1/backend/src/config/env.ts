import dotenv from "dotenv";
import { z } from "zod";

dotenv.config();

const envSchema = z.object({
  PORT: z.coerce.number().default(4000),
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  FRONTEND_URL: z.string().default("http://localhost:5173"),
  DATABASE_URL: z.string().default("postgresql://postgres:postgres@localhost:5432/smart_appraisal_pro"),
  JWT_SECRET: z.string().min(16),
  JWT_EXPIRES_IN: z.string().default("1d")
}).superRefine((env, ctx) => {
  if (env.NODE_ENV === "production" && env.JWT_SECRET === "change-me") {
    ctx.addIssue({
      code: "custom",
      path: ["JWT_SECRET"],
      message: "Production JWT_SECRET must not use the default placeholder."
    });
  }
});

export const env = envSchema.parse(process.env);
