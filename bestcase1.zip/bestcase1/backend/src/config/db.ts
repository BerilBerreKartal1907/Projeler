import { Pool, type QueryResultRow } from "pg";

import { env } from "./env.js";

export const pool = new Pool({
  connectionString: env.DATABASE_URL,
  ssl: env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false
});

export const query = <T extends QueryResultRow>(text: string, params?: unknown[]) => pool.query<T>(text, params);
