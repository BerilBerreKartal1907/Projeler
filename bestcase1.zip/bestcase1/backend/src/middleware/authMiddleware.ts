import type { NextFunction, Request, Response } from "express";
import jwt from "jsonwebtoken";

import { query } from "../config/db.js";
import { env } from "../config/env.js";
import type { RoleName } from "../constants/roles.js";
import { fail } from "../utils/apiResponse.js";

type JwtPayload = {
  sub: string;
  email: string;
  role: string;
};

export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith("Bearer ") ? authHeader.slice(7) : null;

  if (!token) {
    return res.status(401).json(fail("Yetkilendirme token'ı bulunamadı."));
  }

  try {
    const payload = jwt.verify(token, env.JWT_SECRET) as JwtPayload;

    // Token geçerli olsa bile kullanıcı DB'de aktif değilse oturum kabul edilmez.
    const userResult = await query<{ id: number; email: string; role: string }>(
      `
        SELECT u.id, u.email, r.name AS role
        FROM users u
        JOIN roles r ON r.id = u.role_id
        WHERE u.id = $1
          AND u.is_active = TRUE
        LIMIT 1
      `,
      [payload.sub]
    );

    const user = userResult.rows[0];
    if (!user) {
      return res.status(401).json(fail("Kullanıcı pasif veya bulunamadı."));
    }

    req.authUser = {
      id: user.id,
      email: user.email,
      role: user.role as RoleName
    };

    return next();
  } catch {
    return res.status(401).json(fail("Geçersiz veya süresi dolmuş token."));
  }
}
