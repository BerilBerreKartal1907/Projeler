import type { NextFunction, Request, Response } from "express";

import { fail } from "../utils/apiResponse.js";

export function notFoundHandler(req: Request, res: Response) {
  return res.status(404).json(fail(`İstenen endpoint bulunamadı: ${req.method} ${req.originalUrl}`));
}

export function errorHandler(error: unknown, _req: Request, res: Response, _next: NextFunction) {
  const message = error instanceof Error ? error.message : "Beklenmeyen bir sunucu hatası oluştu.";

  return res.status(500).json(
    fail("Sunucu işlemi tamamlayamadı.", {
      message
    })
  );
}
