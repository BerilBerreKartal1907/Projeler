import type { NextFunction, Request, Response } from "express";
import type { ParamsDictionary } from "express-serve-static-core";
import type { ParsedQs } from "qs";
import { z, type ZodTypeAny } from "zod";

import { fail } from "../utils/apiResponse.js";

type ValidationSchemas = {
  body?: ZodTypeAny;
  params?: ZodTypeAny;
  query?: ZodTypeAny;
};

export function validate(schemas: ValidationSchemas) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      if (schemas.body) {
        req.body = schemas.body.parse(req.body);
      }

      if (schemas.params) {
        req.params = schemas.params.parse(req.params) as ParamsDictionary;
      }

      if (schemas.query) {
        req.query = schemas.query.parse(req.query) as ParsedQs;
      }

      return next();
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json(
          fail(
            "Doğrulama hatası.",
            error.issues.map((issue) => ({
              path: issue.path.join("."),
              message: issue.message
            }))
          )
        );
      }

      return res.status(400).json(fail("Geçersiz istek."));
    }
  };
}
