import type { NextFunction, Request, Response } from "express";

import type { RoleName } from "../constants/roles.js";
import { fail } from "../utils/apiResponse.js";

export function requireRoles(...allowedRoles: RoleName[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.authUser) {
      return res.status(401).json(fail("Giriş yapılması gerekiyor."));
    }

    if (!allowedRoles.includes(req.authUser.role)) {
      return res.status(403).json(fail("Bu işlem için yetkiniz bulunmuyor."));
    }

    return next();
  };
}
