import { query } from "../config/db.js";

export async function createNotification(input: {
  userId: number;
  title: string;
  message: string;
  type?: string;
}) {
  await query(
    `
      INSERT INTO notifications (user_id, title, message, type, is_read)
      VALUES ($1, $2, $3, $4, FALSE)
    `,
    [input.userId, input.title, input.message, input.type ?? "in_app"]
  );
}
