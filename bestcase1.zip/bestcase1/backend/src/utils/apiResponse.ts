export const ok = <T>(data: T, message = "Success") => ({
  success: true,
  message,
  data
});

export const fail = (message: string, details?: unknown) => ({
  success: false,
  message,
  details
});
