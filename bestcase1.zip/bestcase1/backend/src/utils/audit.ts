import { query } from "../config/db.js";

export async function createAuditLog(input: {
  userId?: number | null;
  action: string;
  entityType: string;
  entityId: string | number;
  oldValue?: unknown;
  newValue?: unknown;
  ipAddress?: string | null;
}) {
  // Audit kayıtları JSONB alanlarına sade nesne snapshot'ları olarak yazılır.
  await query(
    `
      INSERT INTO audit_logs (
        user_id,
        action,
        entity_type,
        entity_id,
        old_value,
        new_value,
        ip_address
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7)
    `,
    [
      input.userId ?? null,
      input.action,
      input.entityType,
      String(input.entityId),
      input.oldValue ? JSON.stringify(input.oldValue) : null,
      input.newValue ? JSON.stringify(input.newValue) : null,
      input.ipAddress ?? null
    ]
  );
}
