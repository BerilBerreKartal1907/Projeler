BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS roles (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS users (
  id BIGSERIAL PRIMARY KEY,
  full_name VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  phone VARCHAR(30),
  role_id BIGINT NOT NULL REFERENCES roles(id),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS customers (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  national_id VARCHAR(100),
  address TEXT,
  city VARCHAR(100),
  phone VARCHAR(30),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS vehicles (
  id BIGSERIAL PRIMARY KEY,
  owner_customer_id BIGINT REFERENCES customers(id) ON DELETE SET NULL,
  plate VARCHAR(20),
  vin VARCHAR(50) NOT NULL UNIQUE,
  brand VARCHAR(80) NOT NULL,
  model VARCHAR(80) NOT NULL,
  year INT NOT NULL CHECK (year BETWEEN 1950 AND 2100),
  mileage INT NOT NULL DEFAULT 0 CHECK (mileage >= 0),
  category VARCHAR(50) NOT NULL,
  package VARCHAR(80),
  color VARCHAR(50),
  purchase_price NUMERIC(12, 2) CHECK (purchase_price IS NULL OR purchase_price >= 0),
  list_price NUMERIC(12, 2) CHECK (list_price IS NULL OR list_price >= 0),
  status VARCHAR(50) NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS simulated_tramer_records (
  id BIGSERIAL PRIMARY KEY,
  vehicle_id BIGINT NOT NULL UNIQUE REFERENCES vehicles(id) ON DELETE CASCADE,
  market_value NUMERIC(12, 2) NOT NULL CHECK (market_value >= 0),
  accident_record BOOLEAN NOT NULL DEFAULT FALSE,
  owner_count INT NOT NULL DEFAULT 1 CHECK (owner_count >= 0),
  heavy_damage BOOLEAN NOT NULL DEFAULT FALSE,
  customs_problem BOOLEAN NOT NULL DEFAULT FALSE,
  damage_history_text TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS appraisal_requests (
  id BIGSERIAL PRIMARY KEY,
  customer_id BIGINT NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  vehicle_id BIGINT NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  status VARCHAR(50) NOT NULL DEFAULT 'draft',
  expected_selling_price NUMERIC(12, 2) CHECK (expected_selling_price IS NULL OR expected_selling_price >= 0),
  damage_score INT NOT NULL DEFAULT 0 CHECK (damage_score >= 0),
  damage_percentage NUMERIC(5, 2) NOT NULL DEFAULT 0 CHECK (damage_percentage BETWEEN 0 AND 100),
  tramer_value NUMERIC(12, 2) CHECK (tramer_value IS NULL OR tramer_value >= 0),
  calculated_offer NUMERIC(12, 2) CHECK (calculated_offer IS NULL OR calculated_offer >= 0),
  requires_manager_approval BOOLEAN NOT NULL DEFAULT FALSE,
  approval_reason TEXT,
  manager_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
  manager_decision VARCHAR(50),
  manager_note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS damage_details (
  id BIGSERIAL PRIMARY KEY,
  appraisal_request_id BIGINT NOT NULL REFERENCES appraisal_requests(id) ON DELETE CASCADE,
  vehicle_part VARCHAR(50) NOT NULL,
  damage_type VARCHAR(50) NOT NULL,
  damage_point INT NOT NULL CHECK (damage_point >= 0),
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS sales_listings (
  id BIGSERIAL PRIMARY KEY,
  vehicle_id BIGINT NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  customer_id BIGINT REFERENCES customers(id) ON DELETE SET NULL,
  price NUMERIC(12, 2) NOT NULL CHECK (price >= 0),
  damage_score INT NOT NULL DEFAULT 0 CHECK (damage_score >= 0),
  status VARCHAR(50) NOT NULL DEFAULT 'under_review',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS negotiations (
  id BIGSERIAL PRIMARY KEY,
  appraisal_request_id BIGINT NOT NULL REFERENCES appraisal_requests(id) ON DELETE CASCADE,
  customer_id BIGINT NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  system_offer NUMERIC(12, 2) NOT NULL CHECK (system_offer >= 0),
  customer_expected_price NUMERIC(12, 2) CHECK (customer_expected_price IS NULL OR customer_expected_price >= 0),
  current_dealer_offer NUMERIC(12, 2) NOT NULL CHECK (current_dealer_offer >= 0),
  max_authorized_offer NUMERIC(12, 2) NOT NULL CHECK (max_authorized_offer >= 0),
  increment_amount NUMERIC(12, 2) NOT NULL CHECK (increment_amount >= 0),
  auto_negotiation_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  status VARCHAR(50) NOT NULL DEFAULT 'open',
  result VARCHAR(50),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (max_authorized_offer >= current_dealer_offer)
);

CREATE TABLE IF NOT EXISTS negotiation_messages (
  id BIGSERIAL PRIMARY KEY,
  negotiation_id BIGINT NOT NULL REFERENCES negotiations(id) ON DELETE CASCADE,
  sender_user_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
  sender_type VARCHAR(50) NOT NULL,
  message_type VARCHAR(50) NOT NULL,
  offered_price NUMERIC(12, 2) CHECK (offered_price IS NULL OR offered_price >= 0),
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS service_appointments (
  id BIGSERIAL PRIMARY KEY,
  customer_id BIGINT NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  vehicle_id BIGINT NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  service_type VARCHAR(50) NOT NULL,
  appointment_datetime TIMESTAMPTZ NOT NULL,
  complaint_description TEXT,
  estimated_price NUMERIC(12, 2) CHECK (estimated_price IS NULL OR estimated_price >= 0),
  status VARCHAR(50) NOT NULL DEFAULT 'pending',
  assigned_technician_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS service_operations (
  id BIGSERIAL PRIMARY KEY,
  appointment_id BIGINT NOT NULL REFERENCES service_appointments(id) ON DELETE CASCADE,
  technician_id BIGINT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  operation_name VARCHAR(150) NOT NULL,
  operation_type VARCHAR(50) NOT NULL,
  part_price NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (part_price >= 0),
  labor_price NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (labor_price >= 0),
  total_price NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (total_price >= 0),
  is_critical_safety BOOLEAN NOT NULL DEFAULT FALSE,
  customer_approval_status VARCHAR(50) NOT NULL DEFAULT 'pending',
  manager_review_status VARCHAR(50) NOT NULL DEFAULT 'not_required',
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS service_operation_reviews (
  id BIGSERIAL PRIMARY KEY,
  service_operation_id BIGINT NOT NULL REFERENCES service_operations(id) ON DELETE CASCADE,
  reviewed_by BIGINT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  decision VARCHAR(50) NOT NULL,
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS credit_calculations (
  id BIGSERIAL PRIMARY KEY,
  customer_id BIGINT NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  vehicle_id BIGINT NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  vehicle_price NUMERIC(12, 2) NOT NULL CHECK (vehicle_price >= 0),
  down_payment NUMERIC(12, 2) NOT NULL CHECK (down_payment >= 0),
  down_payment_rate NUMERIC(5, 2) NOT NULL CHECK (down_payment_rate BETWEEN 0 AND 100),
  maturity_months INT NOT NULL CHECK (maturity_months > 0),
  monthly_interest_rate NUMERIC(5, 2) NOT NULL CHECK (monthly_interest_rate >= 0),
  financed_amount NUMERIC(12, 2) NOT NULL CHECK (financed_amount >= 0),
  monthly_payment NUMERIC(12, 2) NOT NULL CHECK (monthly_payment >= 0),
  total_payment NUMERIC(12, 2) NOT NULL CHECK (total_payment >= 0),
  total_interest NUMERIC(12, 2) NOT NULL CHECK (total_interest >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (down_payment <= vehicle_price)
);

CREATE TABLE IF NOT EXISTS system_parameters (
  id BIGSERIAL PRIMARY KEY,
  key VARCHAR(100) NOT NULL UNIQUE,
  value VARCHAR(255) NOT NULL,
  description TEXT,
  updated_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(100) NOT NULL,
  entity_id VARCHAR(100) NOT NULL,
  old_value JSONB,
  new_value JSONB,
  ip_address INET,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS notifications (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title VARCHAR(150) NOT NULL,
  message TEXT NOT NULL,
  type VARCHAR(50) NOT NULL DEFAULT 'in_app',
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token VARCHAR(255) NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL,
  used_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_users_role_id ON users(role_id);
CREATE INDEX IF NOT EXISTS idx_vehicles_owner_customer_id ON vehicles(owner_customer_id);
CREATE INDEX IF NOT EXISTS idx_vehicles_status ON vehicles(status);
CREATE INDEX IF NOT EXISTS idx_appraisal_requests_customer_id ON appraisal_requests(customer_id);
CREATE INDEX IF NOT EXISTS idx_appraisal_requests_vehicle_id ON appraisal_requests(vehicle_id);
CREATE INDEX IF NOT EXISTS idx_appraisal_requests_status ON appraisal_requests(status);
CREATE INDEX IF NOT EXISTS idx_damage_details_appraisal_request_id ON damage_details(appraisal_request_id);
CREATE INDEX IF NOT EXISTS idx_sales_listings_vehicle_id ON sales_listings(vehicle_id);
CREATE INDEX IF NOT EXISTS idx_sales_listings_status ON sales_listings(status);
CREATE INDEX IF NOT EXISTS idx_negotiations_appraisal_request_id ON negotiations(appraisal_request_id);
CREATE INDEX IF NOT EXISTS idx_negotiations_status ON negotiations(status);
CREATE INDEX IF NOT EXISTS idx_negotiation_messages_negotiation_id ON negotiation_messages(negotiation_id);
CREATE INDEX IF NOT EXISTS idx_service_appointments_customer_id ON service_appointments(customer_id);
CREATE INDEX IF NOT EXISTS idx_service_appointments_vehicle_id ON service_appointments(vehicle_id);
CREATE INDEX IF NOT EXISTS idx_service_appointments_datetime ON service_appointments(appointment_datetime);
CREATE INDEX IF NOT EXISTS idx_service_appointments_status ON service_appointments(status);
CREATE INDEX IF NOT EXISTS idx_service_operations_appointment_id ON service_operations(appointment_id);
CREATE INDEX IF NOT EXISTS idx_service_operations_approval_status ON service_operations(customer_approval_status);
CREATE INDEX IF NOT EXISTS idx_credit_calculations_customer_id ON credit_calculations(customer_id);
CREATE INDEX IF NOT EXISTS idx_system_parameters_key ON system_parameters(key);
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read);
CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_user_id ON password_reset_tokens(user_id);

COMMIT;
