import { rm } from "node:fs/promises";
import { build } from "esbuild";

await rm("dist", { recursive: true, force: true });

// Yerel TypeScript CLI Node compile cache ile takıldığı için backend build'i esbuild üzerinden alınır.
await build({
  entryPoints: ["src/app.ts", "src/server.ts"],
  outdir: "dist",
  bundle: true,
  packages: "external",
  platform: "node",
  format: "esm",
  target: "node20",
  sourcemap: false
});
