# Architecture

## Katmanlar

### Frontend

- `React + TypeScript + Vite`
- role-based route yapısı
- ortak layout:
  - sidebar
  - topbar
  - protected route
- modül bazlı sayfalar:
  - appraisal
  - negotiation
  - service
  - finance
  - admin

### Backend

- `Express + TypeScript`
- controller tabanlı REST API
- yardımcı servis katmanları:
  - appraisal rule engine
  - negotiation engine
  - capacity control
  - finance calculator
- middleware:
  - auth
  - role authorization

### Database

- `PostgreSQL`
- migration tabanlı tablo kurulumu
- seed ile demo kullanıcı ve örnek domain verileri

## Karar Notları

- gerçek TRAMER entegrasyonu yerine `simulated_tramer_records`
- gerçek AI yerine kural motoru
- kredi başvurusu yerine finansman simülasyonu
- mobil app yerine responsive web dashboard
