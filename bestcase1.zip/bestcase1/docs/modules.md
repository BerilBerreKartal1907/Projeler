# Modules

## Auth

- login
- forgot password
- reset password
- me
- JWT token doğrulama
- rol bazlı yönlendirme

## Appraisal

- araç oluşturma
- hasar detayları kaydetme
- damage score
- damage percentage
- preliminary offer
- manager approval

## Negotiation

- pazarlık oluşturma
- müşteri beklentisi
- sistem karşı teklifi
- yönetici limit güncellemesi

## Service

- randevu oluşturma
- kapasite kontrolü
- teknisyen atama
- randevu yeniden planlama
- randevu iptali
- operasyon kaydı
- müşteri onayı
- kritik güvenlik review
- teknisyen performansı

## Finance

- peşinat
- vade
- aylık faiz
- aylık ödeme
- toplam ödeme
- toplam faiz

## Dashboard

- rol bazlı KPI endpointleri
- frontend kartları canlı API'den beslenir

## Admin

- kullanıcı listesi
- kullanıcı düzenleme
- sistem parametreleri
- parametre düzenleme
- audit log
- raporlar
- bildirimler

## Reports

- özet KPI raporu
- tarih aralığı filtresi
- marka filtresi
- servis tipi filtresi
- toplam satış adedi
- toplam gelir
- ortalama kâr
- servis doluluk oranı
- en aktif teknisyen
- CSV export
- Excel export
