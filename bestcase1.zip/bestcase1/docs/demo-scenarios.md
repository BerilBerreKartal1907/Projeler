# Demo Scenarios

Bu doküman, sunum sırasında hangi rol ile hangi akışın gösterilmesinin en verimli olacağını özetler.

## Customer

- `customer@example.com / 123456`
- araç ekspertizi başlat
- hasar işaretle
- ön teklif sonucunu göster
- pazarlık ekranında beklenti fiyatı gir
- servis randevusu oluştur
- finansman hesaplama ekranını aç
- bildirimler ve profil ekranını göster

## Sales Agent

- `sales@example.com / 123456`
- ekspertiz taleplerini listele
- bir ekspertiz detayına gir
- pazarlık yönetimini aç
- araç stok ekranında satış listesi oluştur veya satıldı işaretle

## Technician

- `technician@example.com / 123456`
- atanmış randevuları aç
- servis operasyonu oluştur
- tamamlanabilir işleri bitir

## Service Manager

- `servicemanager@example.com / 123456`
- randevu yönetim ekranında teknisyen ata
- randevu güncelle veya iptal et
- teknisyen performans ekranını göster
- kritik güvenlik vakasını incele

## Authorized Manager

- `manager@example.com / 123456`
- ekspertiz onaylarını aç
- revize et / onayla / reddet akışını göster
- pazarlık onaylarını aç
- raporlarda filtre ve CSV export göster

## Admin

- `admin@example.com / 123456`
- kullanıcı oluştur veya düzenle
- sistem parametresi değiştir
- audit log ekranını aç
- rol yönetimi görünümünü göster

## Önerilen Sunum Sırası

- `Customer -> Sales Agent -> Authorized Manager -> Service Manager -> Admin`
- her rolde 2 veya 3 kritik aksiyon göstermek en akıcı sunumu verir
