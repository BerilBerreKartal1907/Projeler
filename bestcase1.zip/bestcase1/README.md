# Smart-Appraisal Pro

SRS'e uygun geliştirilen, rol bazlı otomotiv bayi yönetim sistemi.

## Genel Bakış

`Smart-Appraisal Pro`, ikinci el araç ekspertizi, ön teklif, pazarlık, servis süreçleri, finansman simülasyonu, dashboard KPI'ları ve yönetim ekranlarını tek bir responsive web uygulamada toplar.

## Projenin Amacı

Amaç, bir otomotiv bayisinin müşteri tarafındaki ekspertiz, servis ve finansman taleplerini; personel tarafındaki satış, teknik servis, yönetici onayı, raporlama ve admin operasyonlarıyla tek sistemde yönetebilmesidir. Uygulama, farklı rollerin aynı veritabanı üzerinde güvenli ve yetki kontrollü çalışmasını hedefler.

Sistemde yer alan ana roller:
- `customer`
- `sales_agent`
- `technician`
- `service_manager`
- `authorized_manager`
- `admin`

## Teknoloji Stack

- Frontend: `React + TypeScript + Vite`
- Backend: `Node.js + Express + TypeScript`
- Veritabanı: `PostgreSQL`
- Kimlik Doğrulama: `JWT`
- Şifreleme: `bcrypt`
- Excel export: `xlsx`

## Proje Yapısı

```text
backend/
frontend/
docs/
README.md
```

Detaylı katman özeti:
- [docs/architecture.md](docs/architecture.md)
- [docs/modules.md](docs/modules.md)
- [docs/demo-scenarios.md](docs/demo-scenarios.md)
- [docs/improvement-report.md](docs/improvement-report.md)

## Kurulum

### 1. Bağımlılıkları yükle

```bash
npm install
```

### 2. Ortam dosyasını oluştur

```bash
cp backend/.env.example backend/.env
```

Lokal PostgreSQL için örnek bağlantı:

```env
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/smart_appraisal_pro
```

### 3. Veritabanını hazırla

Eğer veritabanı yoksa:

```bash
createdb smart_appraisal_pro
```

Migration:

```bash
npm run db:migrate --workspace backend
```

Seed:

```bash
npm run db:seed --workspace backend
```

### 4. Uygulamayı çalıştır

Backend:

```bash
npm run dev:backend
```

Frontend:

```bash
npm run dev:frontend
```

Tüm servisleri tek komutla açmak için:

```bash
npm run dev
```

## Build Kontrolü

Backend:

```bash
npm run build --workspace backend
```

Frontend:

```bash
npm run build --workspace frontend
```

Repo seviyesinde tek komut doğrulama:

```bash
npm run verify
```

Temel smoke testi:

```bash
npm run smoke
```

Bu komut güncel backend build'ini geçici olarak ayağa kaldırır ve temel auth, dashboard, notification ve Excel export akışlarını doğrular.

Kapsamlı rol-akışı doğrulaması:

```bash
npm run e2e:verify
```

Bu komut müşteri, satış danışmanı, teknisyen, servis müdürü, yetkili yönetici ve admin rollerinin ana akışlarını uçtan uca test eder; veritabanına yazımı, rol yetkilerini ve rol geçişli görünürlüğü kontrol eder.

> Not: Şifre sıfırlama akışı telefon/SMS kodu üzerinden çalışır. Demo ortamında SMS doğrulama kodu `1111` olarak kullanılmaktadır.

## Ekran Görüntüleri

Teslim ve GitHub sunumu için ekran görüntüleri `screenshots/` klasöründe tutulur. Ana ekranlardan bazıları:

| Giriş ve rol yönlendirme | Müşteri operasyonları |
| --- | --- |
| <img src="screenshots/1.png" alt="Giriş ekranı" width="420"> | <img src="screenshots/2.png" alt="Müşteri ekranı" width="420"> |

| Ekspertiz ve satış akışı | Admin ve yönetim ekranları |
| --- | --- |
| <img src="screenshots/3.png" alt="Ekspertiz ve satış ekranı" width="420"> | <img src="screenshots/4.png" alt="Admin yönetim ekranı" width="420"> |

Diğer ekran görüntüleri aynı klasörde devam eder.

## Docker ile Çalıştırma

Projede `backend`, `frontend` ve `postgres` servislerini birlikte ayağa kaldırmak için hazır Docker dosyaları bulunur.

```bash
docker compose up --build
```

Varsayılan servisler:
- Frontend: `http://localhost:5173`
- Backend API: `http://localhost:4000/api/v1`
- PostgreSQL: `localhost:5432`

## Demo Kullanıcılar

- `customer@example.com / 123456`
- `sales@example.com / 123456`
- `technician@example.com / 123456`
- `servicemanager@example.com / 123456`
- `manager@example.com / 123456`
- `admin@example.com / 123456`

## Tamamlanan Modüller

### Auth ve Rol Yönetimi

- Login
- Forgot Password
- Reset Password
- `auth/me`
- JWT tabanlı korumalı route
- rol bazlı dashboard yönlendirmesi

### Appraisal

- araç ekspertiz başlangıcı
- hasar işaretleme
- hasar puanı / hasar yüzdesi
- simüle TRAMER verisi
- ön teklif hesaplama
- kural motoru ile yönetici onay kararı

### Negotiation

- pazarlık başlatma
- müşteri beklenti fiyatı girme
- otomatik karşı teklif
- max yetki limiti
- yönetici limit güncelleme
- pazarlık geçmişi

### Service

- servis randevusu oluşturma
- günlük kapasite kontrolü
- teknisyen atama
- randevu yeniden planlama
- randevu iptal
- operasyon ekleme
- müşteri onay / red
- kritik güvenlik incelemesi
- onaylı operasyonları tamamlama
- teknisyen performans görünümü

### Finance

- finansman simülasyonu
- standart ödeme formülü
- hesaplama kaydı

### Dashboard

- customer KPI
- sales KPI
- technician KPI
- service manager KPI
- manager KPI
- admin KPI

### Admin ve Yönetim

- kullanıcı listesi
- kullanıcı düzenleme
- sistem parametreleri
- parametre düzenleme
- audit log görüntüleme
- rapor özetleri
- bildirimler

### Reports

- özet KPI raporu
- satış raporu
- servis raporu
- tarih aralığı filtreleri
- marka ve servis tipi filtreleri
- toplam satış adedi
- toplam gelir
- ortalama kâr
- servis doluluk oranı
- en aktif teknisyen özeti
- CSV export
- Excel export

## Son Durum

- build doğrulaması temiz
- smoke testi temiz
- e2e doğrulama akışı güncel telefon/SMS şifre sıfırlama yapısına uyumlu
- demo kullanıcı verisi seed düzenine geri alındı
- ana roller ve ana iş akışları uçtan uca gösterilebilir durumda

## Ana Route Grupları

- `/api/v1/auth`
- `/api/v1/users`
- `/api/v1/roles`
- `/api/v1/customers`
- `/api/v1/vehicles`
- `/api/v1/appraisals`
- `/api/v1/negotiations`
- `/api/v1/service`
- `/api/v1/credit-calculations`
- `/api/v1/dashboard`
- `/api/v1/system-parameters`
- `/api/v1/audit-logs`
- `/api/v1/notifications`
- `/api/v1/reports`

## Proje Kapsamı

- TRAMER gerçek entegrasyon değil, simülasyon
- ekspertiz kararları rule-based karar mantığı ile çalışır
- finansman modülü kredi başvurusu yerine finansman hesaplama ve kayıt akışına odaklanır
- CRUD ekranları proje gereksinimlerini karşılayan temel yönetim işlemlerini kapsar
- audit log kayıtları kritik yönetim ve operasyon aksiyonlarını izlemek için kullanılır

## Sonraki Genişletme Alanları

- daha detaylı rol/permission matrisi
- daha ileri raporlama ve grafik bileşenleri
- gerçek SMS, ödeme veya harici servis entegrasyonları

Detaylı geliştirme ve iyileştirme listesi için [docs/improvement-report.md](docs/improvement-report.md) dosyasına bakabilirsiniz.
